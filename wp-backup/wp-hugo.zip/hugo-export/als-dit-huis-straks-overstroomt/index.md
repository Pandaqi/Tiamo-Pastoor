---
title: Als dit huis straks overstroomt
author: hetisdepanda
type: page
date: 2022-07-14T14:02:31+00:00

---
<div class="wp-block-image">
  <figure class="alignright size-full is-resized"><img decoding="async" loading="lazy" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2022/07/Cover-1.webp" alt="" class="wp-image-13277" width="369" height="521" /></figure>
</div>

**Als dit huis straks overstroomt** is een jongerenroman over klimaatverandering, angst, dromen, vechten voor je toekomst &#8230; en misschien wel je heden.

Het boek heeft een A5 formaat, telt ~300 pagina&#8217;s inhoud, en gebruikt een vernieuwende structuur: elk hoofdstuk begint met een belangrijke illustratie.

Koop hier het boek:

<p class="buy-button">
  <a href="https://www.mijnbestseller.nl/books/302216">Als dit huis straks overstroomt (fysiek; paperback)</a>
</p>

<p class="buy-button">
  <a href="https://www.mijnbestseller.nl/books/302168">Als dit huis straks overstroomt (digitaal; ebook)</a>
</p>

Deze links gaan naar de originele uitgever. Maar het boek is bijna overal te koop, dus ongetwijfeld ook in jouw favoriete boekenwinkel! Je hoeft alleen op de titel te zoeken.

## Wat is het idee? {#wat-is-het-idee}

_Maria woont langs het water. Hevige stormen en hittegolven dreigen de dijken te laten breken … maar niemand luistert. Hoewel ze vanwege haar angsten en verleden in de schaduw wil blijven, dwingt de aanstaande ramp haar om uit de schulp te kruipen en op radicale wijze aandacht te vragen. Kan ze haar dorp redden? En ten koste van wat?_

Op de verkooppagina is een inkijkexemplaar beschikbaar met de eerste paar hoofdstukken.

Ik begon dit boek uit frustratie over klimaatverandering en het feit dat vrijwel niemand er iets om lijkt te geven, maar wij — jongeren — er wel mooi mee zullen zitten. Als we het al overleven.

Ik schreef het af vanwege de vele grappen, emotionele verhaallijnen en spannende situaties die ik kon vinden met dit grote gevaar altijd op de achtergrond. (En omdat het op het moment van schrijven inderdaad veertig graden is in Nederland en veel meer dan mijn vingers langzaam bewegen over een toetsenbord zit er dan niet in.)

Het is _zéker_ niet bedoeld als een saaie spreekbeurt of een vervelend activistisch boek. Het is vooral een jongerenroman over dromen, angsten, toekomst, leiderschap, en meer, allemaal in een dorpje dat wel erg vlakbij het water ligt. (Het dorpje bestaat niet echt. Ik zeg het er maar bij, want de naam _Midden-Roeringdam_ had bijna iedereen overtuigd dat het een plek was waarvan ze wel eens hadden gehoord.)

## Feedback {#feedback}

Gek genoeg denk ik _niet_ dat ik perfect ben. Als je het boek leest, laat me dan weten wat je ervan vond!

Het boek doet veel nieuwe dingen: hoofdstukken beginnen met plaatjes (die daadwerkelijk belangrijk zijn en veel inhoud hebben), praten tegen de lezer, een grootser verhaal dan de gemiddelde jongerenroman, etcetera.

Het is de eerste _roman_ dat ik officieel afmaak en publiceer. Al mijn werk hiervoor is _non-fictie_ of _prentenboeken_.

Ik weet zeker dat ik het niet allemaal even goed heb uitgewerkt. Geef me feedback, en elk volgend boek wordt beter.

**Waarom is de voorkant van het ebook zwart-wit?** Omdat ik dom ben en niet door had dat het systeem automatisch de zwart-wit foto van de eerste pagina binnenin het boek had gepakt (en mijn kleurenfoto daarmee vervangen). Dus toen heb ik het gepubliceerd met deze voorkant en ik kan het niet meer veranderen. Dit overkomt mij dus altijd de eerste keer dat ik iets nieuws probeer.

## Het boek in het wild! {#het-boek-in-het-wild}

Zoals altijd, bij deze een paar foto&#8217;s van een fysiek exemplaar. Ja, deze zijn genomen op een piano, want het was een héle warme en zonnige dag en elke andere plek had te veel licht, of lag juist te diep in schaduw. Ironisch eigenlijk.

<div class="wp-block-jetpack-tiled-gallery aligncenter is-style-rectangular">
  <div class="tiled-gallery__gallery">
    <div class="tiled-gallery__row">
      <div class="tiled-gallery__col" style="flex-basis:34.71885%">
        <figure class="tiled-gallery__item"><img decoding="async" srcset="https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/07/IMG_20220720_124111_752.webp?strip=info&#038;w=600&#038;ssl=1 600w" alt="" data-height="800" data-id="13344" data-link="https://nietdathetuitmaakt.nl/boeken/als-dit-huis-straks-overstroomt/attachment/img_20220720_124111_752/" data-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2022/07/IMG_20220720_124111_752.webp" data-width="600" src="https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/07/IMG_20220720_124111_752.webp?ssl=1" data-amp-layout="responsive" /></figure>
      </div>
      
      <div class="tiled-gallery__col" style="flex-basis:30.56230%">
        <figure class="tiled-gallery__item"><img decoding="async" srcset="https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/07/IMG_20220720_124135_668.webp?strip=info&#038;w=600&#038;ssl=1 600w,https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/07/IMG_20220720_124135_668.webp?strip=info&#038;w=800&#038;ssl=1 800w" alt="" data-height="600" data-id="13345" data-link="https://nietdathetuitmaakt.nl/boeken/als-dit-huis-straks-overstroomt/attachment/img_20220720_124135_668/" data-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2022/07/IMG_20220720_124135_668.webp" data-width="800" src="https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/07/IMG_20220720_124135_668.webp?ssl=1" data-amp-layout="responsive" /></figure><figure class="tiled-gallery__item"><img decoding="async" srcset="https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/07/IMG_20220720_124148_327.webp?strip=info&#038;w=600&#038;ssl=1 600w,https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/07/IMG_20220720_124148_327.webp?strip=info&#038;w=800&#038;ssl=1 800w" alt="" data-height="600" data-id="13347" data-link="https://nietdathetuitmaakt.nl/boeken/als-dit-huis-straks-overstroomt/attachment/img_20220720_124148_327/" data-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2022/07/IMG_20220720_124148_327.webp" data-width="800" src="https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/07/IMG_20220720_124148_327.webp?ssl=1" data-amp-layout="responsive" /></figure>
      </div>
      
      <div class="tiled-gallery__col" style="flex-basis:34.71885%">
        <figure class="tiled-gallery__item"><img decoding="async" srcset="https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/07/IMG_20220720_124157_963.webp?strip=info&#038;w=600&#038;ssl=1 600w" alt="" data-height="800" data-id="13348" data-link="https://nietdathetuitmaakt.nl/boeken/als-dit-huis-straks-overstroomt/attachment/img_20220720_124157_963/" data-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2022/07/IMG_20220720_124157_963.webp" data-width="600" src="https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/07/IMG_20220720_124157_963.webp?ssl=1" data-amp-layout="responsive" /></figure>
      </div>
    </div>
  </div>
</div>