---
title: Capers of the Lonely Coast
author: hetisdepanda
type: page
date: 2023-04-01T09:18:01+00:00

---
**Capers of the Lonely Coast** is the first book of the <a href="https://nietdathetuitmaakt.nl/boeken/trilogy-of-neverold/" data-type="page" data-id="14267">Trilogy of Neverold</a>. It tells the story of the Capers, a mysterious place where you never grow up and stay young forever, and a few children who eagerly want to escape to that dream. But playing with the laws of time has consequences &#8230;

This book has **two versions.** (See explanation below.)

  * Capers of the Lonely Coast: Children @TODO (Link)
  * Capers of the Lonely Coast: Young Adult @TODO (Link)

## Two versions

The two books are completely different stories. But they&#8217;re aimed at different age groups, using this idea of growing up and playing with time in a different way.

  * **Children:** aimed at &#8220;middle grade&#8221; (and around it), with characters about to go to high school.
  * **Young Adult:** aimed at adolescents, with characters about to take their final exam and leave school altogether.

You can read both (in this order). Or you can read the one that you like the most.

_Why did you do this?_ The original stories for the Neverold Trilogy were all (Dutch) **musicals.** When I wrote this musical, I noticed I was basically writing two musicals. There were two very interesting stories to tell, depending on the target audience. The only logical conclusion? Split the story into two _separate_ books.

I&#8217;m not sure if this has ever been done before. Which makes it all the more enticing to me 😉 I love innovating, trying new concepts, experimenting. And this experiment has many advantages: I can offer the same story to more age groups, the reader gets a choice, and I get to implement more cool ideas around the concept.

With this project, I saw a chance to do this, and _do it well_. Once you&#8217;ve read the books, you&#8217;ll understand what I mean.

## What&#8217;s the idea?

### Children

Rax wants to escape his miserable life. The one he just made _more_ miserable by giving away their last food to somebody who needed it. But he&#8217;s told nobody that he received a Diamond in return.

He learns of the rumoured existence of many more Diamonds. With them, he would be able to create his own group of friends that never have to grow old, and never have to worry about food or shelter. A dangerous adventure to capture the Diamonds ensues, while more and more people seem interested in these valuable treasures &#8230;

### Young Adult

Milo and Anna are in their final year. But Milo just _cannot_ take another year of _stupid school_, while Anna doesn&#8217;t want to grow up yet. Both hear about a mysterious group called the &#8220;Capers&#8221;, where there&#8217;s no school, no adults, happiness forever, and you never grow up. Maybe it&#8217;s just a fairy tale. Nobody else has heard of them. When they leave home to find the Capers, it turns out that fairy tales and magic sometimes don&#8217;t work out like you expected &#8230;

## More information

Want to know more about me (the author)? Take a look at my [book page][1] (although many are in Dutch), or [my portfolio][2] (all projects, all English!). Or Google my name and see what happens.

Want to know more about the story? About how I wrote it, why I made certain decisions, etcetera? Read my **[Diary] Capers of the Lonely Coast**. @TODO (Link)

 [1]: https://nietdathetuitmaakt.nl/boeken/
 [2]: https://rodepanda.com