---
title: Contact
author: hetisdepanda
type: page
date: 2021-02-26T20:47:29+00:00

---
Hoe je mij het beste kan contacteren, hangt een beetje af van _waarom_ je mij wilt contacteren.

Als je specifiek wilt reageren op een artikel, heb je daarvoor natuurlijk de reacties onderaan.

Als je feedback wilt geven op iets van mij (bijvoorbeeld een boek dat je hebt gekocht), laat het vooral achter op de officiële pagina voor dat project! Er zijn veel te weinig mensen die mij vertellen wat ze vinden, terwijl ik kan zien dat mijn boeken wel degelijk veel worden gekocht (en niet geretourneerd). Vonden ze het leuk? Vonden ze het stom? Ik heb geen idee!

Als je mij werk wilt aanbieden als freelance kunstenaar, verwijs ik u graag naar mijn portfolio website: [Rode Panda][1] (Hier staat ook mijn werkwijze, alle gebieden waarin ik werk, mijn portfolio, alles!)

Als je mij wilt laten weten dat ik een domme kneus ben die rare dingen schrijft, of dat het misschien een beetje stom is dat ik dezelfde foto van mijzelf en een teddybeer werkelijk _overal_ gebruik (want ik heb geen andere foto van mezelf), dan mag je die mening lekker voor je houden :p

Als je mij om een andere reden wilt bereiken, kun je een mail te sturen naar: <a href="mailto:tiamo@rodepanda.com" data-type="mailto" data-id="mailto:tiamo@rodepanda.com" style="font-variant:normal;">tiamo@rodepanda.com</a>. 

Ik zal doorgaans binnen een week alles lezen en reageren. (Tenzij je hele lange verhalen stuurt. Dan beloof ik qua tijd niks.)

<p class="remark">
  Ik had vroeger een aparte mail voor dit blog, dus tiamo@nietdathetuitmaakt.nl. Maar toen ik steeds meer websites kreeg, werd het een beetje een chaos, dus nu loopt alles via mijn Rode Panda. Bovendien staat GMail niet toe dat je meer dan 6 accounts importeert, dus ik moest iets weghalen.
</p>

 [1]: https://rodepanda.com