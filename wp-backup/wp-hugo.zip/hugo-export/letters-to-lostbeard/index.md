---
title: Letters to Lostbeard
author: hetisdepanda
type: page
date: 2023-04-01T09:23:28+00:00

---
**Letters to Lostbeard** is the second book of the <a href="https://nietdathetuitmaakt.nl/boeken/trilogy-of-neverold/" data-type="page" data-id="14267">Trilogy of Neverold</a>. A story about treasure, adventure, pirates, dumb kings, smart kids, and a young woman trying to unravel the mystery around the disappearance of her dad.

Buy the book here: @TODO (link)

## What&#8217;s the idea?

When thieves break into Eva&#8217;s home to steal a valuable Diamond, she discovers that her father might still be alive. Her whole life, she was told that he died, but now everything seems different. Why do some people pretend he lives? And why are they afraid to speak his name? Could she really possess a powerful Diamond without knowing it?

She starts sending letters, trying to flee home and find him. But the closer she gets, the further away her sweet father seems &#8230;.

## More information

Want to know more about me (the author)? Take a look at my [book page][1] (although many are in Dutch), or [my portfolio][2] (all projects, all English!). Or Google my name and see what happens.

Want to know more about the story? About how I wrote it, why I made certain decisions, etcetera? Read my **[Diary] Letters to Lostbeard**. @TODO (Link)

 [1]: https://nietdathetuitmaakt.nl/boeken/
 [2]: https://rodepanda.com