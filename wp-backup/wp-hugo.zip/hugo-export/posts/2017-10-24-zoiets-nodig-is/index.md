---
title: Dat zoiets nodig is
author: hetisdepanda
type: post
date: 2017-10-24T16:00:12+00:00
url: /toverende-taal/genezende-gedichten/zoiets-nodig-is/
categories:
  - Genezende Gedichten

---
Dat zoiets nodig is  
om mensen samen te brengen  
dat zoiets nodig is  
voor de eerste knuffel van je beste vriend

Dat zoiets nodig is  
om een week niet meer hard te werken  
dat zoiets nodig is  
om je gevoel niet meer weg te stoppen  
maar te janken  
hard te janken  
oprecht te janken  
hard te knuffelen  
oprecht te knuffelen

Dat zoiets nodig is  
om liefde te ontdekken  
dat zoiets nodig is  
om verloren contacten te hervinden

Dat zoiets nodig is  
om te beseffen dat het alles waard is  
en dat zoiets nodig is  
om echt te voelen dat je leeft  
dat het pijn doet  
oprecht pijn doet  
maar dat het ook fijn is  
heel erg fijn is  
dat er mensen zijn die elke dag  
weer ietsje beter maken  
en die slechts met hun aanwezigheid  
elk vuurtje doen ontwaken

Dat zoiets nodig is,  
het zou niet nodig moeten zijn