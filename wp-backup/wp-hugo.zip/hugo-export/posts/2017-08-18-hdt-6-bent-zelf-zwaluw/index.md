---
title: '[HdT] #6 Je bent zelf een zwaluw'
author: hetisdepanda
type: post
date: 2017-08-18T20:35:56+00:00
url: /visuele-fratsen/hdt-6-bent-zelf-zwaluw/
categories:
  - Crappy Cartoons
  - Visuele Fratsen

---
<img decoding="async" src="http://res.cloudinary.com/nietdathetuitmaakt/image/upload/v1503088306/Henk-de-Tijdreiziger-_6.jpg" />