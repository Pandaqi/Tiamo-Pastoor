---
title: Donderdag.
author: hetisdepanda
type: post
date: 2016-10-14T15:00:12+00:00
url: /gewoon-een-gedachte/donderdag/
categories:
  - Gewoon een Gedachte

---
Als je langdurig elke week grotendeels hetzelfde doet &#8211; zoals naar school gaan, daar verveeld in de les zitten, naar huis gaan, en daar verveeld half huiswerk proberen te maken &#8211; begin je onbewust patronen te ontdekken die te maken hebben met de tijd. Misschien voel je je altijd op maandag ziek. Misschien heb je op woensdag altijd de minste motivatie om te studeren. Misschien krijg je op zaterdag nooit werk gedaan. Of misschien krijg je altijd de beste ideeën voor dingen om in je vrije tijd te doen op zondagavond.

Als we nog verder kijken dan dat, echter, valt mij op dat er vaak één specifieke dag is die er altijd bovenuit springt. Als er al iets speciaals gebeurt in je leven, is het op die dag. Als er ook maar de kleinste kans is dat iets wat je doet mis kan gaan, gaat het geheid mis op die dag. Voor mij is dat donderdag.<!--more-->

En dan kun je misschien denken: &#8220;maar, donderdag is zo ongeveer halverwege de week, is dat niet gewoon de dag waarop je het meest vermoeid bent? Of de dag dat er al veel is gebeurd in de week waar op gereageerd kan worden? Of is het misschien de dag waarop je weer zin krijgt in het leven, omdat het bijna vrijdag is, dus bijna weekend!&#8221;

Maar nee, dat is niet zo. Andere mensen hebben dit ook, maar dan met andere dagen. De ene ziet zijn leven elke maandag ingrijpend veranderen, de andere vreest met grote vrees voor wat hem of haar nu weer op zaterdag gaat overkomen.

Op donderdag wordt ik, terwijl ik gewoon netjes de verkeersregels volg, aangereden. Op donderdag verklaart iemand haar liefde voor mij. Op donderdag kom ik met een geweldig idee waar ik het komende halfjaar druk aan werk. Op donderdag zeg ik iets wat normaal gesproken onschuldig klinkt, maar ineens zijn heel veel mensen boos op mij. Op donderdag maak ik een toets waar ik beter voor heb geleerd dan alle andere toetsen bij elkaar &#8211; en toch haal ik hem niet. Op donderdag is mijn ziekte ineens voorbij. De hele week kan  ik nauwelijks praten of zingen, maar op donderdag zing ik ineens de sterren van de hemel. Ik ben normaal gesproken altijd op tijd, maar op donderdag wordt ik op magische wijze altijd nét te laat wakker.

Ik maak inmiddels geen plannen meer op donderdag, omdat ik niet wil weten waar het leven me dan heen brengt. Ik doe gewoon wat ik altijd doe, en ook al gaat het vrijwel altijd anders dan verwacht, dat is prima. Donderdag brengt nieuwe dingen in het leven, donderdag schudt iedereen weer even wakker. (Nouja, vooral ikzelf in de meeste gevallen.) Ik vrees voor donderdag, maar ik weet ook dat daar mijn kansen liggen.

Zou ik ooit uitgaan, of naar een feest gaan van iemand die ik niet heel goed ken, of zomaar een optreden geven in een drukke winkelstraat? Nee. Maar op donderdag wel, want misschien ontmoet ik wel de liefde van mijn leven.