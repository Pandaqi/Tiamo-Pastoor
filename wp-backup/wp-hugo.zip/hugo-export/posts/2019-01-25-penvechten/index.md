---
title: Penvechten
author: hetisdepanda
type: post
date: 2019-01-25T16:00:54+00:00
url: /toverende-taal/aardige-anekdotes/penvechten/
categories:
  - Aardige Anekdotes

---
Ik kan me weinig herinneren van de middelbare school. Maar wat ik wél herinner zijn doorgaans dezelfde soort momenten: rare, belachelijke, specifieke gewoontes of activiteiten die ik met vrienden had bedacht.

Eén van die activiteiten noemden wij **penvechten**.

Het werkt als volgt:

<!--more-->

  * Beide spelers pakken een pen.
  * Men tikt de pennen drie keer tegen elkaar. (Zoals de &#8220;aftrap&#8221; bij hockey, wat waarschijnlijk niet _aftrap_ heet, maar ik weet niet wat het echte woord is.) Daarna begint het gevecht!
  * Men moet proberen met de _punt van de_ _pen_ de _hand van de_ _tegenstander_ te raken.

Het waren strakke regels, want dit was een serieuze sport! Raakte je de pols van de tegenstander? Ongeldig. Raakte je de tegenstander met een ander deel van de pen? Ongeldig.

_Opmerking:_ de tactiek is dan ook om altijd je pen zo te positioneren dat je de vijandige pen kunt wegslaan/wegduwen &#8211; om vervolgens zelf héél snel de ander te steken! Het lijkt best wel op zwaardvechten. Het zou een officiële sport moeten worden.

Een jaar lang zat ik met een van mijn beste vrienden rechtsachter in de klas en kon doorgaans vrijuit penvechten. Het bleef ook nooit bij één potje. Het werd &#8220;beste uit 3&#8221;. En als mijn vriend dan aan het verliezen was, werd het ineens &#8220;beste uit 5&#8221;, daarna &#8220;beste uit 7&#8221;, en dat ging door totdat mijn vriend realiseerde dat ik gewoon veel beter was in penvechten.

Dat kwam deels doordat mijn vriend nooit fatsoenlijke pennen had. Hij vechtte altijd met afgebroken pennen, scheve potloden, en zelfs één keer met alleen de _penvulling_.

En toen ging het mis. De droom viel in duigen :p

Penvullingen zijn doorgaans van die dunne _flexibele_ buisjes. Als je er tegenaan duwt (met bijv. een pen), buigt hij mee, om vervolgens hard terug te veren.

Op een doodgewone dag waren wij aan het penvechten, terwijl onze docente bezig was iemand in het bankje direct voor ons te helpen. Ze zaten allebei met de rug naar ons toe. De perfecte gelegenheid voor een potje penvechten. We begonnen enthousiast! En het ging lang goed, totdat ik te hard tegen de penvulling drukte. Hij boog door, veerde keihard terug, vloog uit de hand van mijn vriend &#8230; en schoot in het haar van onze docente. (Weer een item dat ik van mijn &#8220;per ongeluk bucket list&#8221; af kan strepen: &#8220;een pen in het haar van een docente schieten&#8221;)

Godzijdank viel de pen meteen uit haar kapsel richting de grond. Maar ze keek ons wel héél teleurgesteld aan. Niet boos, gewoon teleurgesteld. Samen met de uitspraak: &#8220;nou, bedankt&#8221;

En dat is de legende van het penvechten. Van het begin van een geweldige sport, tot de val van dit machtige ritueel.