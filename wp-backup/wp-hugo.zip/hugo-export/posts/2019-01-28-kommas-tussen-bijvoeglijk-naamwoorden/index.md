---
title: Komma’s tussen bijvoeglijk naamwoorden
author: hetisdepanda
type: post
date: 2019-01-28T16:00:10+00:00
url: /gewoon-een-gedachte/kommas-tussen-bijvoeglijk-naamwoorden/
categories:
  - Gewoon een Gedachte
  - Toverende Taal

---
Mijn hele leven lang — dat is al meer dan 20 jaar — heb ik komma&#8217;s tussen bijvoeglijk naamwoorden geplaatst. Ik schreef over de _oude, lelijke tafel_ en de _kleine, boze dwerg_. Dat blijkt verkeerd te zijn. Mijn leven is een leugen. (Nou ja, mijn basisschooldocenten vertelden blijkbaar leugens, en alle docenten daarna hebben me nooit verbeterd.)

Er komt alleen een komma tussen bijvoeglijk naamwoorden als deze **gelijkwaardig** (ook wel **nevengeschikt**) zijn. Oftewel, beide bijvoeglijk naamwoorden vallen in dezelfde categorie.

<p style="padding-left: 30px;">
  <em>Voorbeeld:</em> Dit is een lelijke, afzichtelijke tafel.
</p>

<p style="padding-left: 30px;">
  <em>Voorbeeld:</em> Wat heb jij een flauwe, droge humor.
</p>

<!--more-->

In de voorbeelden hierboven zeggen beide bijvoeglijk naamwoorden iets over de (visuele) kwaliteit van het object.

Je kunt dit testen door de bijvoeglijk naamwoorden om te draaien. Als dat de betekenis niet veranderd, gebruik je dus een komma.

<p style="padding-left: 30px;">
  <em>Voorbeeld:</em> Dit is een afzichtelijke, lelijke tafel.
</p>

<p style="padding-left: 30px;">
  <em>Voorbeeld:</em> Wat heb jij een droge, flauwe humor.
</p>

In alle andere gevallen plaats je **géén komma** tussen bijvoeglijk naamwoorden.

<p style="padding-left: 30px;">
  <em>Voorbeeld:</em> De kleine boze dwerg liep door het grote enge woud.
</p>

De **volgorde**, echter, is wel belangrijk.

<p style="padding-left: 30px;">
  <em>Voorbeeld:</em> &#8220;De luid zingende man&#8221; betekent iets anders dan &#8220;de zingende luide man&#8221;
</p>

<p style="padding-left: 30px;">
  In het eerste geval is een doodnormale man luid aan het zingen. In het tweede geval is het een luide man die staat te zingen. Blijkbaar heeft men al vaker geluidsoverlast gehad van deze luide man. En nu staat ie weer te zingen.
</p>

Hoe meer een eigenschap inherent met een object verbonden is, hoe dichter deze bij het zelfstandig naamwoord staat. (Dat betekent doorgaans dat het bijvoeglijk naamwoord _specifieker_ is en vaker _samengaat_ met dit specifieke zelfstandig naamwoord.)

<p style="padding-left: 30px;">
  <em>Voorbeeld:</em> Dit is een authentieke akoustische langspeelplaat van de Beatles.
</p>

Een langspeelplaat is vaker akoustisch dan dat hij authentiek is. _Authentiek_ is een breed concept dat op veel dingen kan slaan, terwijl _akoustisch_ concreet is en niet op veel dingen kan slaan. (&#8220;Hé Fred, wat heb jij een leuke akoustische fiets!&#8221; &#8220;Dank je man, jouw benen zien er vandaag ook zéér akoustisch uit.&#8221;)

Zo, tot zover deze taalkundige mededeling. Hopelijk stopt dit de kommawaanzin van tegenwoordig!

_Opmerking:_ in het Engels bestaat een vaste volgorde van alle types bijvoeglijk naamwoorden die bestaan (volgens de Engelsen). Deze lijst is best interessant wanneer je onderzoekt of bijvoeglijk naamwoorden in dezelfde categorie vallen. De lijst luidt:

<p style="padding-left: 30px;">
  opinion + size + character/quality + age + shape + colour + origin /nationality + material + type/purpose
</p>

<p style="padding-left: 30px;">
  mooi + groot + duur + oud + rechthoekig + bruin + Nederlands + houten + &#8230;
</p>

Natuurlijk zitten er wat verschillen tussen de talen. Zo plakken wij in Nederland de laatste categorie (&#8220;type/purpose&#8221;) doorgaans aan het woord vast. In het Engels is het &#8220;country house&#8221; (bijvoeglijk naamwoord ervoor); in het Nederlands is dat gewoon &#8220;landhuis&#8221;.