---
title: Freds Wilde Wereld – Deel 5
author: hetisdepanda
type: post
date: 2017-08-12T12:45:41+00:00
url: /visuele-fratsen/freds-wilde-wereld-deel-5/
categories:
  - Crappy Cartoons
  - Visuele Fratsen

---
<img decoding="async" src="http://res.cloudinary.com/nietdathetuitmaakt/image/upload/v1502541843/Fred_s-Wilde-Wereld-_5.jpg" />