---
title: De Vloek van de Programmeur – Deel 1
author: hetisdepanda
type: post
date: 2016-10-01T14:00:36+00:00
url: /gewoon-een-gedachte/de-vloek-van-de-programmeur-deel-1/
categories:
  - Gewoon een Gedachte
  - Proberen Programmeren

---
Iedereen kent het wel: je bent in je vrije tijd lekker een spel aan het programmeren, of een website aan het designen (voor alle ontwerpers: nee, dat is geen woord, we zeggen het alleen omdat het dan klinkt alsof we professioneel zijn), en dan slaat de donder in de pan: _Je code werkt niet en je hebt geen idee waarom_.

Dus je gaat nog eens al je code na. En nog eens. Maar je vindt niks. Je gaat maar eens douchen. Of sporten. Of een aflevering van je favoriete serie kijken. Uren later kom je terug, maar je hebt nog steeds geen idee. Je gaat slapen. De volgende dag wordt je wakker, je kijkt naar je code, draait je scherm ondersteboven, start de computer weer opnieuw op (want dat lost altijd alles op), maar het werkt nog steeds niet.

<!--more-->

Opgejaagd door je mislukkingen, denk je een week lang alleen nog maar aan je project. Waarom werkt het niet? Waarom heeft de code-God jou benadeeld? Waarom zijn computers altijd tegen jou?

En dan schiet het je te binnen. Je bent de punt-komma vergeten.

<span style="color:#999999;">Voor geïnteresseerden: ik weet dat niet elke programmeertaal je verplicht je regels te eindigen met een <strong>;</strong>. (God zegene Python en haar aanverwanten.)</span>

<span style="color:#999999;">Eén van de meest populaire talen van het moment, JavaScript, heeft bijvoorbeeld ASI &#8211; Automatic Semicolon Insertion. Dat betekent zoveel als dat je geheugen en tijd kunt besparen door actief je punt-komma&#8217;s weg te laten. Omdat, ongeacht wat jij doet, JavaScript gaat toch lekker proberen om zelf te gokken waar de punt-komma&#8217;s zouden moeten staan.</span>