---
title: '[HdT] #8 Monster van Loch Ness'
author: hetisdepanda
type: post
date: 2019-01-22T16:00:53+00:00
url: /visuele-fratsen/hdt-8-monster-van-loch-ness/
categories:
  - Crappy Cartoons
  - Visuele Fratsen

---
<img decoding="async" src="https://res.cloudinary.com/nietdathetuitmaakt/image/upload/v1548079765/Henk-de-Tijdrijziger-_8.png" />

Als je denkt &#8220;Henks hoofd lijkt dikker dan alle andere lijnen&#8221;, dat klopt, want ik heb die achteraf groter gemaakt. Ik probeer Henk consistent te tekenen in al zijn cartoons, maar het is lastig.

Als je denkt &#8220;wat is Nesquik?&#8221;, dan kan ik je leven ook niet meer redden. (Hint: het is van dat cacaopoeder dat je in melk kunt gooien om chocomel te maken. Zoals het plaatje ook duidelijk probeert te maken.)