---
title: Rare Rokers
author: hetisdepanda
type: post
date: 2016-10-02T15:00:43+00:00
url: /gewoon-een-gedachte/rare-rokers/
categories:
  - Gewoon een Gedachte

---
Vaak fiets ik achter iemand die aan het roken is. Op de fiets. Dit brengt meteen een eerste vraag naar boven: maakt dat het niet verschrikkelijk lastig om te fietsen? Ik bedoel, om een beetje tempo te fietsen moet je ademhaling harder gaan en je meer lucht binnenkrijgen, maar tegelijkertijd roken maakt dat knap lastig.

(Aan de andere kant, als je dat vol moet houden moet je wel een hele goede conditie hebben, dus misschien zien zij het als conditietraining.)

Wat nog veel meer vragen opwekt, echter, is dat rokers vaak een nieuwe sigaret opsteken, er een halve minuut van genieten, en de peuk dan gewoon nonchalant op de grond werpen. Sigaretten zijn duur. In Nederland kosten ze zo&#8217;n €6,60 per 20 stuks, dus 33 cent per sigaret. Voor dat geld kun je een chocoladereep kopen. Of een klein zakje chips. Maar nee, zij beschadigen er een halve minuut hun longen mee.

<!--more-->

Niet alleen dat, het duurt ongeveer twee jaar voordat zo&#8217;n sigaret is &#8220;verteerd&#8221;. (Dat betekent zoveel als dat de sigaret voor een klein deel biologisch is afgebroken, en de overige rotzooi ergens in de natuur rondzwerft.) Dus rokers betalen 33 cent om zichzelf en de natuur op lange termijn lastig te vallen. En dat allemaal om en halve minuut zich een beetje beter te voelen.

In Parijs staat er een straf (van 68 euro) op het vervuilen van de straat met je peuken. Een groot deel van de bosbranden wordt aangestoken door iemand die een nog gloeiende peuk klakkeloos in het struikgewas dumpt. Mensen die vaak in de buurt van rokers staan (&#8220;meerokers&#8221;) hebben rond de 25% meer kans op hartziektes, beroertes of longkanker.

Als je het mij vraagt, mag roken een crimineel strafbare handeling worden.