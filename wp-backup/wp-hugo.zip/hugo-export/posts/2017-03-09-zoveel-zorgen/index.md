---
title: Zoveel zorgen
author: hetisdepanda
type: post
date: 2017-03-09T15:00:26+00:00
url: /toverende-taal/genezende-gedichten/zoveel-zorgen/
categories:
  - Genezende Gedichten

---
Ik maak me zorgen  
Ik maak me zoveel zorgen  
Over mijn gezondheid, mijn prestaties  
Mijn stem, geld, toekomst, en relaties

Ik maak me zorgen  
Zoveel zorgen  
Over de toestand van de wereld  
Of we over dertig jaar nog wel bestaan  
Of de natuur zijn schoonheid behoudt  
Of muziek en kunst blijven ontstaan

Of nemen computers alles over  
Neemt efficiëntie ons te grazen  
Groeit de haat alleen maar groter  
Ontploft de macht van corrupte bazen

Want wat houdt zo’n man tegen  
Om op een dwaze nacht  
Zijn grote vuurpijlen af te steken  
Wanneer niemand het verwacht?

Want wat houdt de samenleving tegen  
Alleen maar aan zichzelf te denken  
De medemens af te schrijven  
Omdat ze hen geen geld zullen schenken?

Want wat houdt mij tegen  
Om te doen wat iedereen zo duidelijk vraagt  
Educatie, geld, werk, een stabiele carrière  
Vriendin en vrienden, vroeg naar bed, een mentale barrière

Het zal mijn hoofd wel zijn  
Die niks beters kan verzinnen  
Kon het mijn hart maar zijn  
Zij doet altijd mooie dingen