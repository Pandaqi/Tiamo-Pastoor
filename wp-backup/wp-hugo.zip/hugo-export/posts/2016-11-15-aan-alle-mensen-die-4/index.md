---
title: Aan alle mensen die…
author: hetisdepanda
type: post
date: 2016-11-15T15:00:44+00:00
url: /gewoon-een-gedachte/aan-alle-mensen-die-4/
categories:
  - Gewoon een Gedachte

---
&#8230; zich altijd belangeloos opofferen voor anderen. De mensen die zich wegcijferen als iemand anders in de vriendenkring probleempjes heeft. De mensen die, als het voetpad smaller wordt, achter de rest moet gaan lopen. De mensen die om 11 uur &#8217;s avonds nog gevraagd worden om allerlei klusjes te doen, omdat mensen weten dat ze het zonder weerwoord zullen doen. De mensen die altijd zorgvuldig samenvattingen maakten voor school, vooral omdat ze daarmee anderen konden helpen. De mensen die als ze ziek zijn niet zielig gaan doen, maar lekker uitrusten zodat ze morgen weer klaar staan voor iedereen. De mensen die niet gaan zeiken als ze nog vijftien cent van iemand krijgen. De mensen die zonder reden anderen een knuffel geven, of iets leuks voor ze doen.

Jullie zijn geweldig. Ga zo door!

<!--more-->

Natuurlijk kun je denken dat mensen die zichzelf wegcijferen niet zelfverzekerd genoeg zijn, of dat ze meer voor zichzelf en hun belangen op moeten komen, maar dat is onzin. De huidige maatschappij wil dat iedereen een grote bek heeft, maar dat hoeft helemaal niet. Sterker nog, dat moet je helemaal niet willen. Zoals altijd, werkt balans het beste. Als wij voor school een groepsproject moesten doen, dan was altijd de helft heel aanwezig in vergaderingen en de andere helft deed achter de schermen het meeste werk. Beide groepen deden wat ze zelf het beste konden en het fijnste vonden, en het werkte vaak prima. Maar dan kwam de leraar die zeurde dat iemand niet genoeg bijdroeg in de vergaderingen, of dat ze iemand te weinig had gehoord, en maakte daarmee alles kapot.

(Je denkt misschien: maar, jij was ook zo iemand die niet veel liet horen, dus jij probeert dat gewoon recht te praten! En dan denk ik: ja, dat is zo. Ik vind vergaderingen vaak onzin, want ik heb niks te vertellen, en ik kan dat halfuur ook besteden aan _daadwerkelijk werk verrichten_. Natuurlijk, je moet communiceren wat iedereen doet, en een beetje team-bonding is leuk, maar dat kan ook gewoon tijdens het werk, of aan het begin/eind van de sessie.)

Desondanks, zijn er wel degelijk gevallen van mensen die zichzelf wegcijferen vanwege een te laag zelfbeeld. Ze denken dat hun eigen leven niet belangrijk genoeg is om aandacht aan te besteden. Nou kan ik natuurlijk niet voor iedereen spreken, maar ook dit zal niet waar zijn. Mocht jij jezelf hierin herkennen, of iemand tegenkomen die zo is, dan doet het denk ik wonderen als je gewoon zegt: wat jij doet voor al die mensen, is geweldig.

In een wereld waarin mensen vaak alleen aan zichzelf denken zijn er mensen nodig die anderen helpen en alles goed proberen te maken. En ja, dat vergt opoffering. Als je niks opoffert om anderen te helpen, dan is het vaak geen anderen helpen, maar een goede beurt maken voor jezelf en je reputatie. Echter, als die opoffering zo groot is dat je gezondheid er onder lijdt, of al je geld verdwijnt als sneeuw voor de zon, dan moet je gas terugnemen. Maar anders hoop ik dat je doorgaat, en dat je anderen inspireert hetzelfde te doen.

&nbsp;