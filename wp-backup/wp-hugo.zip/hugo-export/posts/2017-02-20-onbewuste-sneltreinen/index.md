---
title: Onbewuste Sneltreinen
author: hetisdepanda
type: post
date: 2017-02-20T15:00:27+00:00
url: /gewoon-een-gedachte/onbewuste-sneltreinen/
categories:
  - Gewoon een Gedachte

---
_Inception_ is een goede film. Maar het is ook een lange, ingewikkelde film, dus het enige wat me eigenlijk altijd bij blijft is dat in je onderbewustzijn de tijd langzamer gaat. (En, in de volgende laag, gaat de tijd nog langzamer, enzovoort.) In de film rijden ze bijvoorbeeld met een busje van een brug het water in, terwijl ze in het busje allemaal slapen en in elkaars dromen zitten, en in die dromen gaan uren voorbij voordat het busje het water raakt.

Nou is dit een grappig idee van de schrijvers, ware het niet dat ik sterk de indruk heb dat het gewoon waar is.

<!--more-->

Regelmatig wordt ik door mijn wekker gewekt (wat op zich niet raar is), om vervolgens de wekker uit te zetten en meteen weer in slaap te vallen. Blijkbaar ben ik wel wakker genoeg om de tijd te zien, want als ik dan later weer wakker schrik kan ik me altijd herinneren wanneer ik de wekker precies heb uitgezet. Dit zorgt er voor dat ik weet dat ik vaak nog even een kwartiertje extra slaap &#8217;s ochtends, _en_, wat vooral belangrijk is, is dat ik me herinner waar ik dan over heb gedroomd.

En dan niet in de zin van &#8220;oh ik had een droom met iets van een leeuw die een boom op at, super vaag&#8221;, maar ik bedenk _gigantische_ verhalen in dat kwartiertje. Als ik niet moet haasten voor een afspraak, schrijf ik die verhalen vaak op in kernwoorden en kan ze later moeiteloos uitbreiden tot enkele pagina&#8217;s, eventueel voor dit blog.

Dat is in principe fijn, maar het is ook raar. Want, als ik na dat kwartiertje blijf liggen, en dus klaarwakker nog zit te genieten van de warmte van mijn bed, dan kan ik makkelijk een uur verder zijn en nauwelijks ergens over na hebben gedacht. In dat kwartiertje doordromen (het is geen woord, maar dat zou het wel moeten zijn) los ik tien moeilijke problemen op waar ik mee zat, in een paar uur wakker liggen bedenk ik hoogstens wat ik voor ontbijt wil.

Ik denk dat ik niet de enige ben die dit fenomeen herkent, want vaak als andere mensen zo&#8217;n extra stukje slaap hebben gehad (van soms zelfs maar 5 minuten), komen ze daarna met hele verhalen over waar ze over hebben gedroomd. Als ze dat niet doen, en dus gewoon wakker worden en meteen uit bed moeten, kunnen ze zich niks herinneren van hun droom.

Dus waarom komt dit? Nou, ik heb een theorie, en die heet de _je hebt het niet zo druk-_theorie. Hij gaat als volgt: als jij in bed ligt, ogen dicht, je lichaam in ruststand, je hoofd leeg, je zintuigen ook zachtjes slapend, dan heeft jouw hoofd weinig te doen. Jouw hoofd hoeft niet constant beelden in zich op te nemen, of uit te kijken voor gevaar, of te stressen over de perikelen van het dagelijks leven, dus hij heeft alle tijd om in korte tijd hele epossen te schrijven. Wanneer je eenmaal wakker bent, heeft je hoofd het te druk met andere dingen, en kun je maar een paar dingen bedenken.

Daarnaast, maar dit is meer mijn ervaring misschien, word mensen vaak verteld dat het verkeerd is om te niksen, of te dagdromen, of je te vervelen. Maar, op dat soort momenten is je geest juist vrij en kun je snel en creatief nadenken! Natuurlijk, je moet in het verkeer bijvoorbeeld niet gaan dromen, en je kunt ook niet de hele dag niksen, maar als je ergens fatsoenlijk over wil nadenken heb ik maar één advies: ga lekker dagdromen.

_Maar, dat kost allemaal tijd! Waardevolle tijd!_ Ik denk het niet. Het gebeurt mij al te vaak dat ik met school bezig ben, zonder afgeleid te worden, en dat ik maar één opgave doe of maar een paar paragrafen aan het verslag typ, om vervolgens (tot mijn grote schrik en verbazing) te zien dat we al drie uur verder zijn. Mijn hoofd is vermoeid en/of wil ondertussen andere dingen te doen, en als ik dan doorzet en toch maar tegen mijn zin in door blijf werken, gaat alles veel te langzaam.

Dus, laat je leiden door onbewuste sneltreinen. Tenzij ze van de NS zijn, dan scheelt het je helemaal geen tijd.

&nbsp;