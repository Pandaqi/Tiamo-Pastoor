---
title: Bedankt voor uw geduld
author: hetisdepanda
type: post
date: 2017-08-22T20:43:04+00:00
url: /toverende-taal/aardige-anekdotes/bedankt-voor-uw-geduld/
categories:
  - Aardige Anekdotes

---
Enkele weken geleden besloot mijn tekentablet ineens niet meer aan te gaan. Geen error, geen waarschuwing — mijn gloednieuwe tekentablet deed gewoon niks meer. Gelukkig was het een Microsoft product met goede garantie, dus ik ging naar de website, registreerde het ding, en bevestigde mijn reparatieorder.

Maar er kwam geen mail binnen met instructies en bevestiging. Noodgedwongen besloot ik met support te chatten om te vragen of alles goed was gegaan. Ik belandde op de pagina en die meldde dat &#8220;de gemiddelde wachttijd is **1** minuten&#8221;. Aangezien de &#8220;1&#8221; in een andere kleur was, en &#8220;minuten&#8221; natuurlijk niet klopt, ging ik ervan uit dat dit getal automatisch werd berekend en geüpdatet.

Na 13 minuten wachten was ik aan de beurt. Ik vroeg of de mail herzonden (dat is officieel geen woord, maar ik vind dat het wel een woord moet zijn) kon worden. Dat kon niet, want mijn apparaat was commercieel geregistreerd. Blijkbaar had het bedrijf waarvan ik het had gekocht de apparaten geregistreerd als zijnde van een bedrijf, dus ik moest me voordoen als bedrijf.

Ik vond het onzin, dus ik opende een chat om te vragen of ze niet gewoon de hele reparatie order konden schrappen en een nieuwe voor mij plaatsen. _De gemiddelde wachttijd is **1** minuten._ Na 4 minuten wachten was ik aan de beurt, en het antwoord was: nee. Ze gaf mij een link naar de commerciële support. Pas toen ik de chat al had afgesloten en halverwege het proces was bleek die niet te kloppen.

<!--more-->

Ik opende een nieuwe chat om te vragen waar ik dan moest zijn, want de commerciële support was goed verborgen achter muren van vragen gericht aan particuliere support. (&#8220;Heb je al het volgende geprobeerd: apparaat opnieuw opstarten?&#8221; &#8220;Nee joh, ik probeer altijd eerst om het apparaat aan de geiten te voeren en van een hoge klif af te gooien.&#8221;)

_De gemiddelde wachttijd is **1** minuten. _Na 57 minuten wachten was ik aan de beurt. Hij gaf mij een link. Die link verwees terug naar particuliere support. (Overigens moest ik nog steeds een zin zien verschijnen van de support medewerkers die wél met een hoofdletter begon en interpunctie gebruikte.) Ik zei dat het niet werkte. Hij zei dat hij het ook niet wist.

Uiteindelijk heb ik maar gewoon gedaan alsof ik in mijn eentje een heel bedrijf was, een willekeurige bedrijfsnaam verzonnen, en het was gelukt om het apparaat voor een commerciële reparatieorder te plaatsen. Ze konden het echter nog niet uitvoeren. Waarom niet? OMDAT IK AL EEN PARTICULIERE REPARATIEORDER HAD GEPLAATST, EN DIE KONDEN ZE NIET VERWIJDEREN, WANT ZE WAREN COMMERCIEEL. AAAAH. AAAH.

Dus ik opende voor de laatste keer een chat om mijn order te laten annuleren. _De gemiddelde wachttijd is **1** minuten._ Na 23 minuten wachten was ik aan de beurt, en binnen een minuut was de order verwijderd en alles opgelost. Ik heb mijn apparaat opgestuurd, een week later had ik een gloednieuwe terug. (Blijkbaar, als ze denken dat je een bedrijf bent, krijg je ineens supergoede support aangeboden. Ik kreeg een _persoon_ toegewezen die dagelijks met mij mailcontact had over de stand van zaken. Geweldig!)

Hoe dan ook, volgens hen had ik gemiddeld **1** minuut moeten wachten. Ik heb gemiddeld (13 + 4 + 57 + 23) / 4 = **24.25** minuten gewacht. Ik hoop niet dat hun wiskundige (voorspellende) vaardigheden een afspiegeling zijn van hoe ze andere dingen regelen bij Microsoft.

_Bonus!_

Elke keer als de chat openstond verscheen, als je de gemiddelde wachttijd van 1 minuut overschreden had, &#8220;bedankt voor uw geduld&#8221;. Bedrijven denken dat ze hiermee sympathiek overkomen, maar ik heb niet het idee dat het werkt.

In plaats van &#8220;excuses voor het ongemak&#8221; of &#8220;even wachten aub&#8221;, proberen ze niet in een verontschuldigende houding te schieten maar juist de bezoeker te _bedanken_ voor het wachten. Misschien werkte het vroeger. Maar nu gebruiken alle bedrijven iets soortgelijks, en mijn eerste reactie is altijd &#8220;nope, het maakt ze geen reet uit of je wacht of niet&#8221;. Als ik stop met wachten, en dus bij de support wegga, scheelt dat hen juist werk, en tijd, en geld. Ze hebben liever dat je géén geduld hebt.

Als bedrijf iemand bedanken voor zijn geduld is alsof iemand je winkel binnenkomt om iets in te ruilen, jij geeft maar de helft van het verschuldigde bedrag terug, en bedankt vervolgens de klant voor zijn onoplettendheid. Waarom is klantenondersteuning altijd zo naar?

&nbsp;