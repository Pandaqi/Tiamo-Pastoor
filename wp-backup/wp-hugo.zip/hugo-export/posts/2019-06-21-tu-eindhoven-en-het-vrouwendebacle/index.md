---
title: TU Eindhoven en het vrouwendebacle
author: hetisdepanda
type: post
date: 2019-06-21T16:00:13+00:00
url: /gewoon-een-gedachte/tu-eindhoven-en-het-vrouwendebacle/
categories:
  - Gewoon een Gedachte

---
Ik opende onlangs de NOS website en las tot mijn verbazing een artikel over de TU Eindhoven. Mijn universiteit! Daar heb ik jarenlang gestudeerd! En ze staan op de voorpagina van het NOS!

Dit is het artikel in kwestie: [**TU Eindhoven neemt alleen vrouwen aan**][1]

De TU Eindhoven heeft besloten om, het komende anderhalf jaar, alle vacatures voor medewerkers alléén open te stellen aan vrouwen.

(Het artikel noemt vaak &#8220;het plan&#8221;, waardoor ik even twijfelde of ze het al hadden besloten of niet. Maar in de eerste regels van het artikel wordt vrij duidelijk dat ze het al hebben besloten.)

De reden voor deze maatregel is natuurlijk het feit dat er meer mannen werken dan vrouwen en dat deze maatregel poogt de diversiteit te bevorderen.

In dit artikel wil ik graag uitleggen waarom het een ronduit belachelijk idee is. Ik wil ook zoveel mogelijk diversiteit en gelijke kansen, maar met zo&#8217;n plan maak je de hele situatie alleen maar vervelender.

(Ik heb geen enkele intentie om zelf aan de universiteit te gaan werken. Ik schrijf dit artikel puur om de gegeven argumenten uiteen te zetten en hopelijk de discussie over dit soort thema&#8217;s de juiste kant op te sturen.)

## Een paar vraagjes vooraf

De eerste vraag is natuurlijk: _wat bedoelt men met &#8220;diversiteit&#8221;?_

<!--more-->

Hoewel niemand dat ooit specificeert, bedoelt men doorgaans dat er een representatieve verdeling van medewerkers is. In de wereld is ongeveer 50% man en 50% vrouw, dus diezelfde gelijke verdeling zou er moeten zijn op elke werkvloer.

Hiermee zijn al wat problemen. Waarom zou die verdeling gelijk moeten zijn? Er zijn vele andere factoren die bepalen hoe groot de hoeveelheid beschikbare medewerkers is. Het feit dat ergens meer mannen werken dan vrouwen (of andersom) hoeft niks te maken te hebben met (on)bewuste discriminatie. Denk aan: dit beroep trekt nou eenmaal meer van het ene geslacht dan het ander, in deze omgeving zijn meer potentiële werknemers van het ene geslacht beschikbaar, en medewerkers van verschillende geslachten nemen verschillende carrièrepaden.

<p style="padding-left: 30px;">
  Ik zeg niet dat ik zeker weet dat er <em>geen discriminatie</em> is, maar ik zeg vooral dat zij niet zeker weten <em>dat het wél zo is</em>.
</p>

<p style="padding-left: 30px;">
  (Zo was er ooit een interessant onderzoek naar vrouwelijke professoren. De meeste personen in hoge functies zijn richting de pensioenleeftijd en hebben hun hele leven aan de weg omhoog geplaveid. Het onderzoek concludeerde dat vrouwen eerder van carrière switchen óf stoppen vanwege moederschap, waardoor ze die hoge functie niet bereikten.)
</p>

Dan komt de tweede vraag: _waarom is diversiteit een begeerlijk goed?_

Hierover is gelukkig wat meer duidelijkheid. Zoals het artikel ook aangeeft, hebben meerdere onderzoeken aangetoond dat een divers team (qua geslacht, afkomst, studeerrichting, etc.) resultaten bevordert. Ik heb deze onderzoeken nagelezen, en zelf deze resultaten gemerkt in groepsprojecten, dus hier sta ik achter.

Dan komt de derde vraag: _wanneer is die diversiteit bereikt?_ Moet het precies 50/50 zijn? Daar is geen duidelijkheid over. Ze zeggen alleen:

<p style="padding-left: 30px;">
  &#8220;Je moet eerst even extreem je best doen om heel veel vrouwen binnen te krijgen, daarna ga je weer terug naar het midden.&#8221;
</p>

Wat is het midden? En als ze met deze 150 vacatures al over het midden gaan, dan lijkt me dat tekort qua vrouwelijke medewerkers ook enorm meevallen.

**Update:** in het _Eindhovens Dagblad_ van vandaag (19 Juni 2019) stond een groot artikel over dit onderwerp. Hierin stond dat het huidige percentage vrouwelijke werknemers 16% is en dat hun streefgetal 20% is. Dan weet ik niet wat men precies bedoelt met &#8220;het midden&#8221;. Het lijkt alsof ze al tien jaar lang proberen de 20% te halen, om vanuit daar door te stoten naar een hoger percentage. Maar dat lukte al niet, en dus proberen ze nu deze maatregel.

En dan komt de vierde vraag: _is dit geen discriminatie tegenover mannen?_ Ja. Maar het is _positieve discriminatie_, bedoelt om een aantoonbare minderheid te helpen, wat de enige uitzonderingssituatie is in de ogen van de wet. Hierover later meer.

## Het artikel

Het lijkt me handig gewoon even stuk voor stuk door het artikel te gaan en opmerkingen te geven.

<p class="text_1TQrL1WP" style="padding-left: 30px;">
  &#8220;&#8230; in ons onderbewustzijn hebben we nog altijd de voorkeur voor mannelijke kandidaten. [&#8230;] Die <em>bias </em>is aanwezig bij mannen en vrouwen.
</p>

Wie is &#8220;we&#8221;? Ik heb geen voorkeur voor mannelijke kandidaten. Sterker nog, ik kon het veel beter vinden met de vrouwelijke medewerkers van de TU/e. (Eén van hen had zelfs mijn prentenboek gekocht. Zij was echt heel aardig.) In persoonlijk opzicht kan ik dit besluit alleen maar aanmoedigen.

<p style="padding-left: 30px;">
  We plakken het label &#8216;excellent&#8217; makkelijker op een man dan een vrouw. Terwijl uit onderzoek blijkt dat er qua geslacht geen verschil is in het functioneren.&#8221;
</p>

&#8230; dan is dat toch het probleem? Ik mag toch hopen dat er een objectief sollicatieproces is waarbij meerdere mensen betrokken zijn. Dat sollicitanten worden beoordeeld op hun diploma, wat ze hebben bereikt, hun persoonlijkheid (en of ze passen binnen de universiteit), etc. Ik hoop niet dat er één iemand is die alle sollicitaties afhandelt en gewoon de hele tijd denkt &#8220;hmm, je bent een man &#8211; stop maar met praten, je bent aangenomen!&#8221;

<div class="article_block">
  <div class="textWrapper_1rUbmtI6" data-server-rendered="true">
    <p class="text_1TQrL1WP" style="padding-left: 30px;">
      &#8220;&#8230; er zijn soortgelijke programma&#8217;s, bijvoorbeeld bij de TU Delft, die goede resultaten hebben geboekt.&#8221; Zo stelde de universiteit in 2012 tien hogere wetenschappelijke functies alleen voor vrouwen open. &#8220;Daar zijn hele goede vrouwelijke wetenschappers aangenomen.&#8221;
    </p>
    
    <p>
      Eigenlijk is dit één grote belediging richting vrouwen. Als die vrouwelijke wetenschappers net zo goed of beter zijn dan mannelijke wetenschappers, dan zouden ze puur op basis van hun kwaliteiten die baan binnen moeten kunnen slepen. De baan alleen maar openstellen voor vrouwen is hetzelfde als zeggen: &#8220;kijk, je mag bij ons werken, maar alleen omdat we je een voordeeltje geven&#8221;
    </p>
  </div>
</div>

<div class="article_block">
  <div class="block_textbox">
    <p style="padding-left: 30px;">
      Uit onderzoek blijkt dat mensen graag sollicitanten aannemen die op henzelf lijken. Dit kan ervoor zorgen dat mensen die van de norm (vaak wit en mannelijk) afwijken, zoals vrouwen of mensen met een andere huidskleur, het moeilijker hebben tijdens het solliciteren.
    </p>
  </div>
</div>

&#8230; dan is dat toch het probleem? Leer die ene persoon die blijkbaar het sollicitatieproces doet op de TU/e om objectief en onbevooroordeeld te werk te gaan.

<p class="text_1TQrL1WP" style="padding-left: 30px;">
  Yuki Kho [&#8230;] vindt het een goede maatregel. &#8220;Om te kunnen veranderen, moet je even doorschieten. Als je sportief wil worden, ga je eerst ook heel veel sporten en kom je uiteindelijk ergens in het midden terecht.&#8221;
</p>

In principe ben ik het eens met het doorschietgedeelte. Als iets enorm krom is (zoals een ongelijkheid vanwege discriminatie), moet er een harde klap op komen om het weer recht te krijgen (zoals zo&#8217;n maatregel).

Het enige probleem is dat het niet enorm krom is (daarover later meer), dat er geen bewijs is dat het die harde klap nodig heeft, en dat het waarschijnlijk is dat de harde klap negatief doordreunt naar andere gebieden.

Ik hoop dat je doorhebt dat dit een metafoor is. We moeten niet echt klappen uitdelen.

Daarnaast, als men niks verandert aan die &#8220;gender bias&#8221; die blijkbaar al hun interviewers hebben, heeft dat doorschieten geen zin. Je haalt nu heel veel vrouwen binnen, maar binnen enkele jaren (nadat deze maatregel is stopgezet) gaat men weer terug naar het oude gemiddelde.

En nee. Je gaat niet heel veel sporten als je sportief wil worden. De meeste mensen beginnen rustig, bouwen het op, volgen een schema, worden begeleid door een coach. Ze kunnen niet eens heel veel sporten (omdat hun conditie en botten/spieren dat niet toelaten). En je moet natuurlijk tussendoor genoeg rust nemen.

_Waarom ga je zo diep in op deze vergelijking?_ Omdat het ironisch is. Deze maatregel is inderdaad hetzelfde als iemand die denkt dat hij ineens heel veel moet sporten. Onverstandig, je bereikt niet wat je wilt, niemand anders doet het _met een reden_, en er gaan ongelukken gebeuren.

<p class="text_1TQrL1WP" style="padding-left: 30px;">
  Wel moet de universiteit voor de sollicitaties duidelijk hebben op welke eigenschappen ze iemand willen selecteren. &#8220;Je hebt het gevaar dat je stoere vrouwen gaat aannemen omdat dat binnen je bedrijfscultuur met veel mannen past. Stel daarom van tevoren vast wat de waarden van je bedrijf zijn, welke eigenschappen je belangrijk vindt in een werknemer.&#8221; Kho raadt bedrijven aan om een scorekaart te maken en op die kaart eigenschappen aan te vinken als die terug te zien zijn in de sollicitant.
</p>

&#8230; dan is dat toch het probleem?

En: PRECIES! Dat zeg ik dus al de hele tijd. Objectief aannemen. Doe het, en je hebt nooit meer zulke slechte plannen nodig. Geef iedereen een gelijke kans, en de verdeling (qua geslacht) zal binnen de kortste keren precies zijn zoals hij hoort te zijn. Dat hoeft geen 50/50 te zijn. Zolang het maar op een natuurlijke en eerlijke manier tot stand komt.

<p style="padding-left: 30px;">
  Toch hoopt Kho dat de TU wel eerst goed naar de bedrijfscultuur heeft gekeken voordat deze beslissing is genomen. &#8220;Als de universiteit een supermasculiene bedrijfscultuur heeft, gaat een vrouw zich niet thuis voelen en gaan ze slechter functioneren.&#8221; Een organisatie moet altijd eerst intern alles op orde krijgen, zegt Kho. &#8220;Zoals we altijd zeggen hier: diversiteit is dat iedereen op je feestje mag komen. Inclusiviteit is dat je die mensen ook het gevoel geeft dat ze mogen dansen. Durven de vrouwen die in Eindhoven worden aangenomen wel te dansen?&#8221;
</p>

Wat is een mannelijke / supermasculiene bedrijfscultuur? Worden alle mannen nou in één hokje geduwd?! WAT IS DIT VOOR STEREOTYPERING!?

Misschien gebeuren er hele gekke dingen achter de schermen bij de TU/e. Maar alle mannelijke professoren die ik had zie ik er niet voor aan om ook maar enigszins problemen te veroorzaken of een vijandige cultuur te creeëren. Nogmaals, _het kan best_, maar kom dan met argumenten of bewijs. Maak het hard, maak het aannemelijk. Je kunt een groep met 9 mannen hebben en 1 vrouw, en die vrouw kan de baas zijn en de werkcultuur bepalen.

En nee, ik durfde ook niet te dansen op de universiteit. Dat vonden ze raar, zo tijdens de hoorcolleges.

<div class="article_block">
  <div class="textWrapper_1rUbmtI6" data-server-rendered="true">
    <p class="text_1TQrL1WP" style="padding-left: 30px;">
      Rik Peels is het helemaal niet eens met het plan van de TU Eindhoven. [&#8230;] &#8220;Ik ben helemaal voor meer vrouwen op de universiteit, maar niet voor deze maatregel. Allereerst is het ontzettend betuttelend voor vrouwen: je wordt niet langer meer erkend louter op basis van je kwaliteiten, en veel vrouwen zitten daar helemaal niet op te wachten.&#8221;
    </p>
    
    <p class="text_1TQrL1WP" style="padding-left: 30px;">
      Daarnaast is het discriminerend voor mannen, zegt Peels. &#8220;Stel nou dat dit een <em>once in a lifetime</em>-kans is voor een man, de perfecte leerstoel, en hij kan de baan nu niet krijgen. <strong>Je zet onrecht niet recht door nog meer onrecht</strong>. Je hebt veel meer aan andere, constructieve maatregelen, die verkeerde onderliggende mechanismes aanpakken.&#8221; (nadruk door mij)
    </p>
    
    <p>
      Ah, Rikkie Peels, een man naar mijn hart. En nog een hoogleraar filosofie ook.
    </p>
    
    <p>
      Lees die dikgedrukte zin maar eens goed. <em>Je zet onrecht niet recht door nog meer onrecht</em>. Naast het feit dat er iets te veel &#8220;recht&#8221; in deze zin voorkomt, staat hier heel duidelijk de waarheid.
    </p>
    
    <p>
      Zo&#8217;n maatregel als deze voegt extra onrecht toe, zonder enige zekerheid dat het bestaand onrecht wegneemt. (Zelfs zonder bewijs dat dit vermeende onrecht bestaat.)
    </p>
    
    <p>
      Is het geen idee om &#8230; onrecht gewoon weg te halen door het weg te halen?
    </p>
    
    <p class="text_1TQrL1WP" style="padding-left: 30px;">
      Maatregelen zoals de samenstelling van een sollicitatiecommissie veranderen, zegt Peels. &#8220;Zorg dat de helft uit vrouwen bestaat. Of externen. Dan neem je de <em>bias </em>ook weg. Of kun je het sollicitatietraject in een vroege fase anonimiseren.&#8221;
    </p>
    
    <p>
      Nou, het is alsof meneer Peels mijn gedachten kan lezen.
    </p>
    
    <p class="text_1TQrL1WP" style="padding-left: 30px;">
      Volgens TU-rector Baaijens hebben de &#8216;kleinere&#8217; maatregelen, zoals twee vrouwen in de adviescommissie, eerder niet geholpen. Ook zegt hij dat de universiteit wel openstaat voor uitzonderingen: als er echt een geweldig mannelijk talent solliciteert, mag die wel op gesprek komen. Rector Baaijens: &#8220;We hebben een <em>opt out</em>-regeling voor uitzonderlijke talenten. Maar daarvoor is er wel speciale toestemming nodig van een groep mensen.&#8221;
    </p>
    
    <p>
      The soap continues. Blijkbaar moet je nu dus een uitzonderlijk talent zijn om een vacature te krijgen, in plaats van dat je gewoon de kwaliteiten hebt en een eerlijke kans krijgt in het hele proces.
    </p>
    
    <p>
      En, het feit dat een maatregel niet helpt, betekent niet dat je nog forsere maatregelen moet nemen. Dat is vaak ook een hint dat er geen probleem is of dat je het probleem op de verkeerde manier probeert op te lossen.
    </p>
    
    <p>
      Bijvoorbeeld: stel ik kijk in de spiegel en vind mezelf te dik. Dan stel ik de maatregel in: minder eten. Het werkt niet, ik vind mezelf nog steeds te dik. Dus ik versterk de maatregel: nóg minder eten en echt <em>niks</em> met koolhydraten! Het werkt nog steeds niet. Op een dag val ik flauw, op de grond, met mijn veel te tengere lichaam. Als ik wakker word denk ik: ik eet nog steeds te ongezond, ik val er flauw van, ik moet nóg minder eten!
    </p>
    
    <p>
      Het probleem hier is natuurlijk dat ik in eerste instantie niet te dik was of ongezond at. De maatregel dan &#8220;verergen&#8221; kan alleen maar catastrofale gevolgen hebben.
    </p>
  </div>
</div>

<div class="article_block">
  <div class="textWrapper_1rUbmtI6" data-server-rendered="true">
    <p class="text_1TQrL1WP" style="padding-left: 30px;">
      Eigenlijk hebben die mannen, wat voor een uitzonderlijk talent ze ook hebben, nu gewoon even pech, zegt Gerard van Vliet. &#8220;Ik weet hoe stom het klinkt, maar eigenlijk wil ik zeggen: man, jij hebt altijd mazzel gehad. Nu is het even tijd voor de vrouw. Deze discussie over positief discrimineren is zo niet meer van deze tijd.&#8221;
    </p>
  </div>
</div>

Gerard, ga eens heel snel nadenken voordat je iets zegt. Laten we eens kijkje naar het lijstje argumenten.

  * Mannen hebben nu gewoon even pech
  * Mannen hebben altijd mazzel gehad
  * Nu is het tijd voor de vrouw
  * Deze discussie over positief discrimineren is zo niet meer van deze tijd.

Dit kun je werkelijk op alles toepassen.

<p style="padding-left: 30px;">
  &#8220;Vrouwen, hoe uitzonderlijk hun talent voor zwanger zijn ook, hebben nu gewoon even pech. Ik weet hoe stom het klinkt, maar eigenlijk wil ik zeggen: vrouwen, jullie hebben altijd mazzel gehad dat jullie baby&#8217;s konden krijgen. Nu is het tijd voor de man. Deze discussie over de biologische onmogelijkheid van mannen die kinderen baren vind ik zó niet meer van deze tijd.&#8221;
</p>

<p style="padding-left: 30px;">
  &#8220;Volwassenen, hoe uitzonderlijk hun talent voor lopen ook, hebben nu gewoon even pech. Ik weet hoe stom het klinkt, maar eigenlijk wil ik zeggen: volwassenen, jullie hebben altijd mazzel gehad dat jullie konden lopen. Nu is het tijd voor de baby&#8217;s. Deze discussie over dat lopen sneller en makkelijker is dan kruipen vind ik zó niet meer van deze tijd.&#8221;
</p>

Maar goed, ik dwaal af.

<div class="article_block">
  <div class="textWrapper_1rUbmtI6" data-server-rendered="true">
    <p class="text_1TQrL1WP" style="padding-left: 30px;">
      Ook Van Vliet denkt dat het een goede maatregel is van de TU. &#8220;Als niks helpt, is dit het enige wat je nog kan doen. Er zijn überhaupt weinig vrouwen die een technische opleiding kiezen. De kans dat ze dan ook nog eens bij jou werken, is heel klein. Daarom moet je zoveel mogelijk maatregelen nemen om dit te bevorderen.&#8221;
    </p>
    
    <p>
      Dit klinkt meer wanhopig. &#8220;Als niks helpt &#8230; dan &#8230; dan geef ik het op. Oh nee, wacht, dan gaan we lekker terugdiscrimineren!&#8221;
    </p>
    
    <p>
      Hierboven zijn al vele suggesties voorbijgekomen voor andere dingen die je kunt doen. Daarnaast is het waar dat er minder vrouwen dan mannen een technische opleiding kiezen, maar dat is niet consistent tussen studies. Sommige technische studies zijn overheersend vrouwelijk. Waarom hoor je daar niemand over? Waarom zegt niemand daarvan dat alle vacatures alleen nog maar voor mannen moeten zijn? Precies, omdat het onzin is.
    </p>
    
    <p class="text_1TQrL1WP" style="padding-left: 30px;">
      De <em>gender bias</em> zit heel diep in de maatschappelijke krochten, zegt Van Vliet. &#8220;We hebben een maatschappij gecreëerd waarbij bepaalde beelden als waarheid worden aangenomen. Vrouwen werken bijvoorbeeld niet in de techniek, mannen niet in de zorg.&#8221;
    </p>
    
    <p>
      Ik heb dat nooit gedacht. Mijn omgeving heeft dat nooit gedacht. Mijn vrienden hebben dat nooit gedacht. Dat is hetzelfde als die mensen die zeggen dat er een ongelijkheid is tussen mannen en vrouwen in het onderwijs. Iedereen denkt bij een basisschoolleraar aan een <em>juf</em> en niet aan een <em>meester</em>. Ik ken persoonlijk behoorlijk veel meesters. Niemand kijkt daar raar van op. Het is gewoon onzin om te zeggen dat &#8220;iedereen&#8221; of &#8220;de hele maatschappij&#8221; er zo over denkt. (Wederom, maak het hard, geef me wat onderzoek en/of statistieken.)
    </p>
  </div>
</div>

Daarnaast maakt het niet uit wat mensen _denken_ of _vinden_. Iedereen heeft een gelijke kans. Als iedereen tegen jou zegt dat het niet de bedoeling is dat je een technische studie doet, dan &#8230; kun je dat gewoon negeren en toch die studie gaan doen! Mensen zijn niet gelijk. Je moet geen precies gelijke verdeling verwachten in elk bedrijf of elke sector. Mensen moeten wél gelijke rechten en gelijke kansen krijgen. En alle vacatures alleen maar voor vrouwen openstellen, zou ik niet als gelijke kansen bestempelen.

<div class="article_block">
  <div class="textWrapper_1rUbmtI6" data-server-rendered="true">
    <p class="text_1TQrL1WP" style="padding-left: 30px;">
      Daarnaast zal de kwaliteit van de universiteit er niet op achteruitgaan, denkt Van Vliet. &#8220;Ik ga ervan uit dat er een minimale kwaliteit wordt verwacht van de sollicitanten. Als de TU alleen maar een excuustruus wil om de diversiteitscijfers omhoog te krijgen, zou ik daar niet achterstaan.&#8221;
    </p>
    
    <p>
      In het filmpje (bovenaan het artikel) zegt een professor dat het gaat om hele moeilijke, specifieke vacatures. Hij verwacht dat deze gewoon moeilijk gevuld kunnen worden en dat het eisen van een vrouw dit proces vertraagt en bemoeilijkt. Dus er is reden om te denken dat de kwaliteit er wel degelijk op achteruit gaat.
    </p>
    
    <p>
      Het woord <em>excuustruus</em> is leuk, dat moet ik hem nageven.
    </p>
    
    <p class="text_1TQrL1WP" style="padding-left: 30px;">
      Volgens docent Peels is er ook nog een andere vraag over voor de Technische Universiteit. &#8220;Misschien moet de universiteit zichzelf ook de vraag stellen: waarom lukt het op andere plekken wel, en niet bij ons? Dan voeren ze in de toekomst niet zo&#8217;n top-down, nietsontziend beleid als nu.&#8221;
    </p>
    
    <p>
      Nou, Peelsje van me, daar heb je weer een goede opmerking. (Ik ken die persoon trouwens helemaal niet. Ik merk gewoon dat ik zijn opmerkingen in dit artikel erg kan waarderen.)
    </p>
    
    <h2>
      De cijfers
    </h2>
    
    <p>
      Want op andere plekken lukt het wel.
    </p>
    
    <p>
      Deze link geeft <a href="https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Tertiary_education_statistics/nl#Deelname_naar_geslacht"><strong>cijfers voor het tertair onderwijs in Europa.</strong></a>
    </p>
    
    <p>
      Het aantal vrouwelijke <em>studenten</em> in het tertiair onderwijs is hoger dan mannelijke studenten.
    </p>
    
    <p>
      Het aantal vrouwelijke werknemers bij het tertiair onderwijs ligt inderdaad onder het aantal mannen, maar niet met een significant verschil.
    </p>
    
    <p>
      Specifiek gekeken naar technische gebieden, zijn er doorgaans twee keer zoveel mannelijke afgestudeerden dan vrouwelijke.
    </p>
    
    <p>
      De cijfers van de TU/e zijn dan inderdaad schrikbarend laag (met 16% vrouwelijke hoogleraar).
    </p>
    
    <p>
      Deze link geeft <strong><a href="https://duo.nl/open_onderwijsdata/databestanden/ho/ingeschreven/wo-ingeschr/ingeschrevenen-wo1.jsp">cijfers voor ingeschreven studenten in Nederland</a></strong>(van DUO)
    </p>
    
    <ul>
      <li>
        In Eindhoven is de verdeling man/vrouw (voor 2018) 8885 / 3081.
      </li>
      <li>
        In Delft is de verdeling man/vrouw (voor 2018) 17703 / 6805.
      </li>
    </ul>
    
    <p>
      Ja, dat is een verschil. Maar is dat een onnatuurlijk verschil, ontstaan uit discriminatie? Is dat een afschrikkende cultuur waardoor vrouwen niet gelijke kansen krijgen? Zorgt dit ervoor dat jonge vrouwen geen &#8220;rolmodel&#8221; hebben met een hoge functie aan de universiteit?
    </p>
    
    <p>
      Ik betwijfel het. Mijn studie, <em>Technische Wiskunde</em>, heeft (het afgelopen jaar) 161 mannen en 76 vrouwen toegelaten. Dan kun je niet zeggen dat je de enige vrouw was, of dat er slechts een handjevol vrouwen was. Toen ik er studeerde was dit ook helemáál niet aan de orde. Er heerste geen &#8220;supermasculiene cultuur&#8221;. (Andere studies kennen dus een meerderheid aan vrouwen, of een gelijke hoeveelheid, zoals <em>Industrial Design</em> met 266/270.)
    </p>
    
    <p>
      Mijn vriendenkring heeft altijd iets meer vrouwen gekend dan mannen en veel van die vrouwen werken nu in deze technische gebieden. Niemand heeft daar ooit raar over gedaan, waarom zou je? Voor zover ik weet zijn zij niet tegengehouden of benadeeld. Voor zover ik weet hadden ze genoeg steun en genoeg rolmodellen.
    </p>
    
    <p>
      Daarnaast, als je kijkt naar de cijfers over tijd, zie je dat de kloof tussen mannen en vrouwen in deze studies langzaam dichtgaat, en dat vooruitgang gelijkop gaat. (Als het aantal mannelijke studenten verdubbelt, bijvoorbeeld doordat de universiteit meer toelaat of een breder aanbod heeft, verdubbelt het aantal vrouwelijke studentes net zo goed.)
    </p>
    
    <p>
      Als er al een probleem is, zal deze dus binnen 5-10 jaar opgelost zijn, als een groot deel van deze studentes gaat werken in deze gebieden.
    </p>
    
    <h2>
      De conclusie
    </h2>
    
    <p>
      Er is niet bewezen dat er een probleem is of dat deze moet worden opgelost.
    </p>
    
    <p>
      Ik ben ook voor diversiteit, gelijke behandeling, gelijke rechten, en alle voordelen die daarbij komen kijken.
    </p>
    
    <p>
      Daarom is het juist scheef om vermeend onrecht te bevechten met onrecht. Om extra discriminatie erbovenop te gooien.
    </p>
    
    <p>
      Ze doen alsof dit de enige methode is, maar ze noemen zelf al vele andere methodes en potentiële oorzaken.
    </p>
    
    <p>
      Dit plan is symptoombestrijding. Het is iemand die zegt: &#8220;ik heb koorts, dus ik moet wel een zware ziekte onder de leden hebben&#8221; en vervolgens veel te veel pillen slikt. De echte oorzaken worden niet gevonden of bestreden en de &#8220;ziekte&#8221; wordt slechts verergerd.
    </p>
    
    <p>
      Ik weet het, misschien is dit een overdreven reactie op een simpel besluit van de TU/e. Maar ik vind dat een universiteit, die hopelijk probeert om iedereen kritisch, logisch en wetenschappelijk denken aan te leren, een veel beter voorbeeld moet geven. Ik wil feiten, argumenten, statistieken, logica. Ik wil geen &#8220;mannen hebben gewoon pech&#8221;, &#8220;iedereen heeft vooroordelen&#8221;, en &#8220;deze discussie vind ik zoooo passé&#8221;.
    </p>
    
    <p>
      Ik hoop dat dit verhelderend was. Zo niet, laat het vooral weten, want ik heb hier veel tijd in gestoken :p
    </p>
  </div>
</div>

 [1]: https://nos.nl/artikel/2289609-tu-eindhoven-neemt-alleen-vrouwen-aan-goed-idee-je-moet-even-doorschieten.html