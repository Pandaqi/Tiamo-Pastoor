---
title: Het Keerpunt.
author: hetisdepanda
type: post
date: 2016-10-13T15:00:23+00:00
url: /gewoon-een-gedachte/het-keerpunt/
categories:
  - Gewoon een Gedachte

---
Elk jaar komt er onverbiddelijk weer _Het Keerpunt_. Dat heeft hoofdletters nodig, omdat mensen niet beseffen hoeveel impact het heeft op ons leven. Mensen haten Het Keerpunt, maar toch zijn ze er aan gehecht.Mensen veranderen tijdens Het Keerpunt, mensen worden gedwongen keuzes te maken.

In de zomer is het heet. Je brandt je bed uit, wil &#8217;s ochtends niet te lang blijven liggen. Je trekt meteen je korte broek en shirtje aan, en springt zonder jas de fiets op. De zon schijnt buiten en je wil niet te lang binnen zitten. Genieten van het mooie weer, want dat vinden we zeldzaam in Nederland.

En dan eindigt de vakantie. Je moet misschien eerder opstaan, of langer doorwerken, en kunt minder slapen of buiten in de zon hangen. Het is nog eventjes warm, maar dan breekt toch echt de herfst aan. Waar het vorige week nog lekker 22 graden was, is het nu ineens omgeslagen tot 12 graden. Je bibbert en je beeft ineens, en Het Keerpunt is bereikt.

<!--more-->

In plaats van dat je &#8217;s ochtends uit bed springt en &#8217;s avonds niet kan slapen, wil je kostte wat kost in bed blijven liggen. Het liefst spring je zelfs zo vroeg als je kan je bed in, of je werkt en doet alles onder een warme deken. De korte broek wordt een lange broek, geen jas wordt getwijfel &#8211; winterjas of &#8220;tussenjas&#8221;? In plaats van liever buiten zijn, snel je zo gauw mogelijk naar binnen. Je doet je handen rond de warme chocomel, en wil alleen maar niks doen en in de warmte uitrusten van de kou.

Onbewust verandert Het Keerpunt niet alleen je fysieke gesteldheid (gesnotter, dikke truien en opgekruld in bed liggen), maar zeker ook je mentale gesteldheid. In plaats van dat je denkt &#8220;ja, dat is leuk, moet ik doen!&#8221;, denk je &#8220;het is zo koooud, en het is nu al donker, en ik heb er geen ziiin iiin&#8221;. In plaats van dat je wakker wordt bij een fijne temperatuur en mooie opkomende zon, kijk je naar buiten en denk je &#8220;nee, vandaag even niet&#8221;. In plaats van dat je aan nieuwe dingen begint, probeer je gewoon alles in je leven te overleven en tot een goed einde te brengen. In de zomer begint iedereen aan nieuwe projectjes, carrières en andere avonturen. In de winter wil iedereen vooral dat alles hetzelfde blijft en dat het maar weer snel warmer wordt.

Maar toch, vindt men altijd manieren om er naar uit te kijken. Als het in de zomer bloedje heet is snakt men naar wat verkoeling en &#8220;gezellig binnen zitten&#8221;. Wanneer in een lamme zomer niks gebeurt, wil men Kerst en Oud & Nieuw. Wanneer je na maanden van de hak op de tak gekke dingen doen moe en uitgeblust bent, wil je weer gewoon wat structuur en wat werk voor elkaar krijgen.

Het Keerpunt is voor iedereen anders. Misschien voel jij haar het meest als het weer wintertijd wordt (wat overigens wel betekent dat je een uur extra slaap hebt, dus we zijn toch weer een beetje blij). Of wanneer je, na wekenlang stug te hebben doorgezet, toch je lange broek en dikke kleding van achteruit de kast moet halen. Of wanneer je, na met goede moed te zijn begonnen aan het schooljaar, toch weer achter begint te lopen met alles en geen motivatie meer hebt om naar school te komen, en het liefst gewoon liggend op de bank je studieboeken doorbladert.

Vecht niet tegen Het Keerpunt, maar gebruik het waar het voor bedoelt is: om je leven weer een nieuwe impuls te geven, en een nieuw pad in te slaan om weer het donkerste deel van het jaar te overleven. Ook al is het koud en nat, en heb je er geen zin meer in :p

&nbsp;