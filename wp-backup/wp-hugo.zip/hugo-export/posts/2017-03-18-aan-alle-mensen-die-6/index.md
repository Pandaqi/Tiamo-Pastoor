---
title: Aan alle mensen die…
author: hetisdepanda
type: post
date: 2017-03-18T15:00:30+00:00
url: /gewoon-een-gedachte/aan-alle-mensen-die-6/
categories:
  - Gewoon een Gedachte

---
&#8230; sneaky hun lievelingsvoedsel zo ver mogelijk achterin de kast zetten, zodat niemand anders het pakt. Dat werkt niet, ik heb jullie wel door! Meestal gaat het namelijk als volgt: ik weet dat er iets lekkers in huis is, ik doe de kast open, ik zie het niet, dus ik schuif dingen aan de kant, en als ik het nog niet zie, kijk ik in de prullenbak of het op is, zo niet, zoek ik het verder tot ik het vind.

(Tenzij het niet dermate lekker is dat ik het nodig vind zoveel moeite te doen. Dan loop ik nog liever zelf naar de supermarkt om chips te halen. En dan verstop ik die chips voor de anderen, want zo ben ik dan ook wel weer. Geen voor allen, alles voor mij.)

Wat veel beter werkt, is je naam er op zetten. Maakt niet uit of het daadwerkelijk van jou is, maakt niet uit of je het gekocht hebt of niet &#8211; pak een mooie zwarte stift, watervast bij voorkeur, en schrijf in koeieletters aan alle kanten je naam, gecombineerd met een vriendelijk &#8216;AFBLIJVEN&#8217; en &#8216;NIET AANKOMEN&#8217;. Want dat betekent niet hetzelfde natuurlijk.

Dit is mijn gratis tip. Weet alleen wel dat als je dit gebruikt, en ik ben in de buurt, ik alsnog expres je eten ga opeten, want ik heb je door!