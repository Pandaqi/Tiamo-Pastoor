---
title: Wie is de Trol?
author: hetisdepanda
type: post
date: 2020-09-05T12:00:21+00:00
url: /gewoon-een-gedachte/wie-is-de-trol/
featured_image: https://nietdathetuitmaakt.nl/wp-content/uploads/2020/08/Naamlogo-verkleind_result.webp
categories:
  - Gewoon een Gedachte
  - Superieure Spellen

---
Vandaag begint het nieuwe, speciale jubileumseizoen van _Wie is de Mol?_ (5 September 2020).

Een perfect moment om te vertellen dat ik een eigen bordspelversie heb gemaakt!

Na anderhalf jaar verschillende ideeën proberen, mooie trollen tekenen, en bijna honderd unieke opdrachten bedenken, presenteer ik: **Wie is de Trol?**

<p class="through-link">
  Bezoek de officiële pagina hier: <a href="https://pandaqi.com/wie-is-de-trol"><strong>Wie is de Trol? &#8211; een WIDM bordspel</strong></a>
</p>

Het spel blijft zo veel mogelijk trouw aan het _echte_ Wie is de Mol. Elke ronde zijn er 3 opdrachten, vervolgens maak je een test, en de ronde eindigt met een executie.

Om het spel te spelen hoef je slechts enkele blaadjes te printen (en knippen), de spelregels te lezen, en een digitaal apparaat erbij te pakken. Waarom? Zowel de opdrachten als de test worden geregeld door de website!

Zie hieronder wat actiefoto&#8217;s (klik om te vergroten):<figure class="is-layout-flex wp-block-gallery-55 wp-block-gallery columns-3">

<ul class="blocks-gallery-grid">
  <li class="blocks-gallery-item">
    <figure><a href="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/wie-is-de-trol-3_result-scaled.webp"><img decoding="async" loading="lazy" width="2560" height="1436" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/wie-is-de-trol-3_result-scaled.webp" alt="" data-id="10985" data-full-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/wie-is-de-trol-3_result-scaled.webp" data-link="https://nietdathetuitmaakt.nl/gewoon-een-gedachte/wie-is-de-trol/attachment/wie-is-de-trol-3_result/" class="wp-image-10985" /></a></figure>
  </li>
  <li class="blocks-gallery-item">
    <figure><a href="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/wie-is-de-trol-2_result-scaled.webp"><img decoding="async" loading="lazy" width="2560" height="1436" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/wie-is-de-trol-2_result-scaled.webp" alt="" data-id="10984" data-full-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/wie-is-de-trol-2_result-scaled.webp" data-link="https://nietdathetuitmaakt.nl/gewoon-een-gedachte/wie-is-de-trol/attachment/wie-is-de-trol-2_result/" class="wp-image-10984" /></a></figure>
  </li>
  <li class="blocks-gallery-item">
    <figure><a href="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/wie-is-de-trol-1_result-scaled.webp"><img decoding="async" loading="lazy" width="2560" height="1436" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/wie-is-de-trol-1_result-scaled.webp" alt="" data-id="10983" data-full-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/wie-is-de-trol-1_result-scaled.webp" data-link="https://nietdathetuitmaakt.nl/gewoon-een-gedachte/wie-is-de-trol/attachment/wie-is-de-trol-1_result/" class="wp-image-10983" /></a></figure>
  </li>
</ul></figure> 

<span style="opacity: 0.5;">(Ja, dat is een eeuwenoude iMac die Windows 10 draait, want de Apple kant heeft het al <em>lang geleden</em> opgegeven. En als je goed kijkt, kan je mijn konijn zien.)</span>

Ik wilde een bordspel maken dat leek op het echte spel, maar tegelijkertijd toegankelijk was, grote en kleine groepen aankon, en zelfs enkele nieuwe elementen kon introduceren.

Uiteindelijk besloot ik unieke kaarten te maken voor dit spel en daarmee alle opdrachten uit te voeren. De computer kiest willekeurig opdrachten uit een gigantische lijst, vervolgens doet iedereen hun beurt (door kaarten te spelen, speciale acties uit te voeren, geld in te zetten, _whatever_ de opdracht van je vraagt), en aan het einde van de dag hoop je een beetje geld te hebben verdiend. En informatie te hebben over wie de trol is.

Hieronder een plaatje (uit de spelregels). Deze gebruikt de meest simpele opdracht uit de hele lijst om het idee uit te leggen.

<div class="wp-block-image">
  <figure class="aligncenter size-large"><a href="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/wie-is-de-trol-4_result.webp"><img decoding="async" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/wie-is-de-trol-4_result.webp" alt="" /></a></figure>
</div>

Als je afvalt (bij de executie) ben je niet volledig uit het spel, want dat zou saai zijn. (Zit je net tien minuten te spelen, ben je de rest van het uur gewoon compleet uit het spel.) In plaats daarvan krijg je enkele nadelen en handicaps waardoor je iets meer moeite moet doen om nog goed te spelen en de trol te ontmaskeren.

Ik heb het basisspel zo _simpel mogelijk_ gehouden, zodat je snel kunt beginnen met spelen en ervaren hoe het spel in elkaar steekt. Maar ik ken de echte molloten, en die willen natuurlijk altijd meer! Dus ik heb vier uitbreidingen gemaakt die veelvoorkomende onderdelen uit het echte spel toevoegen en het spel nog véél interessanter maken.

<p class="example">
  Deze uitbreidingen zijn <em>bondjes</em>, <em>addertjes onder het gras</em>, <em>eigenschappen</em> en <em>speciale krachten</em>.<br /><br />Bijvoorbeeld, in het echte spel doen kandidaten vaak niet mee (of niet hun best) omdat ze een bepaalde eigenschap hebben, zoals <em>hoogtevrees</em> of <em>dyslexie</em>. Nou, dat heb ik dus toegevoegd middels een uitbreiding en wat slimme spelelementen.
</p>

Kortom, probeer het spel! En als je het hebt geprobeerd, laat me weten wat je ervan vond (zowel de goede als slechte dingen).

Al mijn medespelers zijn (tot nog toe) enthousiast geweest over het spel, het werkt goed, de plaatjes zijn mooi geworden, dus ik vind het een groot succes. Hoewel het spel af is, zal ik waarschijnlijk nog hier en daar meer opdrachten toevoegen, uitbreidingen bedenken en kleine dingen verbeteren.

<p class="indented">
  Als je dit blog regelmatig bekijkt, denk je nu misschien: <em>hoe heb je in korte tijd twee gigantische spellen gemaakt?</em> Nou, dat was inderdaad een slecht idee. Ik werd langzamerhand een beetje gek van de hoeveelheid werk en problemen die ik elke dag moest oplossen. De komende projecten die ik doe worden sowieso ietsje kleiner. En misschien moet ik er niet twee tegelijkertijd doen.<br /><br />Maar ach, dit <em>Wie is de Trol?</em> spel is ook een beetje speciaal voor mij, omdat het ik het al zó lang wil maken en probeer voor elkaar te boksen. Ik ben gewoon blij dat het uiteindelijk gelukt is. En dat dit project niet — in tegenstelling tot veel andere projecten — gewoon voorgoed onafgemaakt is gebleven :p
</p>