---
title: Herhaalhulp
author: hetisdepanda
type: post
date: 2019-10-28T16:00:13+00:00
url: /gewoon-een-gedachte/herhaalhulp/
categories:
  - Gewoon een Gedachte
  - Toverende Taal

---
Mensen zijn soms best wel eigenaardig. Als ze proberen te communiceren, maar iemand verstaat iets niet, dan vraagt diegene &#8220;wat zei je?&#8221; en dan is het antwoord van diens gesprekspartner 50% van de tijd &#8220;of je worst lust&#8221;.

De andere 50% van de tijd gebeurt iets bijzonders. Ik noem het de _herhaalhulp_ (of _herhaalcorrecties_, maar dat vond ik weer onnodig formeel klinken).

<p style="padding-left: 30px;">
  Persoon 1: &#8220;Hé, we gaan dus met de groep op stap vanavond. Je weet wel, Isabella en Anna en Peter enzo. Zin om te komen?&#8221;
</p>

<p style="padding-left: 30px;">
  Persoon 2: &#8220;Wat?&#8221;
</p>

<p style="padding-left: 30px;">
  Persoon 1: &#8220;Ik zei: Isabella, Anne en Peter gaan op stap. Wil je mee?&#8221;
</p>

In plaats van simpelweg te herhalen wat je net hebt gezegd, hebben veel mensen de neiging om zichzelf te verbeteren. De tweede keer dat ze iets zeggen is het vaak korter, duidelijker, maar nog steeds precies dezelfde informatie.

Soms heeft men zelfs ineens het woord gevonden waarnaar ze zochten:

<!--more-->

<p style="padding-left: 30px;">
  Persoon 1: &#8220;Wat kijk je?&#8221;
</p>

<p style="padding-left: 30px;">
  Persoon 2: &#8220;Voetbal&#8221;
</p>

<p style="padding-left: 30px;">
  Persoon 1: &#8220;Wie tegen wie?&#8221;
</p>

<p style="padding-left: 30px;">
  Persoon 2: &#8220;Oh, bekerwedstrijd van Ajax. PSV is het &#8230; eh &#8230; tegenspeeleleftal.&#8221;
</p>

<p style="padding-left: 30px;">
  Persoon 1: &#8220;Wat?&#8221;
</p>

<p style="padding-left: 30px;">
  Persoon 2: &#8220;PSV is de tegenstander.&#8221;
</p>

(Dit is een gesprek dat ik laatst had. Je denkt misschien: wat dom dat je het woord _tegenstander_ vergeet. Maar ik zeg liever: ik heb het woord _tegenspeelelftal_ uitgevonden.)

Ik vind dit interessant. Het laat zien dat gesproken communicatie vaak behoorlijk inefficiënt is en barst van de fouten, maar tegelijkertijd dat mensen maar een halve seconde extra nodig hebben om het wél goed te doen. In de tijd dat iemand &#8220;huh, wat zei je?&#8221; heeft gemompeld, hebben mensen hun vorige zin helemaal geanalyseerd en verbeterd, waardoor hij er de tweede keer véél beter uit komt.

Maar het laat ook iets anders zien: de wil om de ander te helpen jou te begrjipen. Het zou &#8220;makkelijker&#8221; zijn om gewoon je zin te herhalen. Of in een soort telegramstijl te gaan werken: &#8220;Op stap. Met vrienden. Jij?&#8221; Het zou nog makkelijker zijn om stil te blijven: meestal heeft die ander je wel gehoord, maar is de boodschap gewoon nog niet binnengekomen. In plaats daarvan hebben onze hersenen binnen een seconde onze eigen zinnen verbeterd en klaargezet om als versie 2.0 te worden uitgesproken. Helemaal onbewust!

Soms is die herhaling zelfs de enige begrijpelijke communicatie. Dikwijls is iemands eerste zin zó incorrect dat die persoon zelf niet eens weet wat hij aan het zeggen is.

<p style="padding-left: 30px;">
  Persoon 1: *moet hoesten*
</p>

<p style="padding-left: 30px;">
  Persoon 2: &#8220;Hé, doe eens je mand voor de hond!&#8221;
</p>

<p style="padding-left: 30px;">
  Persoon 1: &#8220;Wat?&#8221;
</p>

<p style="padding-left: 30px;">
  Persoon 2: &#8220;Eh hand voor je mond, natuurlijk.&#8221;
</p>

Je denkt misschien: dit komt niet zo vaak voor. In dat geval nodig ik je uit om er eens op te letten. Soms komen er ook hele leuke woordgrappen uit.

(Ik heb persoonlijk heel vaak dat ik mensen vol overtuiging aanspreek met een COMPLEET verkeerde naam. Ik weet niet hoe dat gebeurt, maar het kan niet anders dan een hele rare eerste indruk achterlaten. De namen lijken vaak niet eens op elkaar. Ik spreek Daan aan met Nick, ik spreek Laura aan met Merel, ik snap het ook niet. Gelukkig heb ik vaak mijn herhaalzin om de naam van die ander wél goed te krijgen.)

Maar de kerst op de taart is het feit dat bijna alle mensen die ik ken _onbewust_ deze herhaalhulp aanbieden, zonder er verder aandacht aan te besteden of te doen alsof ze &#8220;iets extra&#8217;s&#8221; voor die ander doen. Maar als je diezelfde mensen ook maar één keer corrigeert op hun grammatica &#8230; dan breekt de hel los. (&#8220;Nee, die film duurt langer als die ander.&#8221; &#8220;Langer dan?&#8221; &#8220;Ja hou jij je mond maar.&#8221;) Ik ken mensen die serieus kwaad kunnen worden als je vraagt om opheldering na een incorrecte zin van hun kant, terwijl ze er zelf als de kippen bij zijn om hun zinnen te verbeteren.

Hopelijk zie je nu waar ik heen wil met dit stuk: we kunnen beide werelden combineren!

Ik gebruik deze truc nu al een tijdje. Soms hebben mensen door wat je aan het doen bent, maar meestal niet. Het werkt als volgt: stel iemand zegt iets wat incorrect is of gewoon onduidelijk. Dan _herhaal_ je de zin van die ander, maar dan op de correcte manier of de manier waarop jij het interpreteert. Het lijkt alsof je om opheldering vraagt, maar eigenlijk verbeter je die ander.

Ik zal het voordoen:

<p style="padding-left: 30px;">
  &#8220;Die film is langer als die andere.&#8221;<br /> &#8220;Oh? Is die film langer DAN die andere? Ik dacht van niet.&#8221;
</p>

&nbsp;

<p style="padding-left: 30px;">
  &#8220;Ik zal het dadelijk aan hun vragen.&#8221;<br /> &#8220;Top! Het zou echt heel fijn zijn als je het voor vijf uur nog aan HEN kunt vragen.&#8221;
</p>

&nbsp;

<p style="padding-left: 30px;">
  &#8220;Wil jij die laatste koekje?&#8221;<br /> &#8220;Ik wil DAT laatste koekje wel hoor.&#8221;
</p>

&nbsp;

Het zijn maar kleine dingen, ik weet het. Maar ik vond het interessant. En er komt behoorlijk veel rotzooi voort uit miscommunicatie, dus je kunt aleynu maet ej ej je dok!

Wat?

Oh, ik zei: je kunt altijd maar beter je best doen.