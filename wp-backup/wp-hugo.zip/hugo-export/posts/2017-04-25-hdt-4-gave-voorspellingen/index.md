---
title: '[HdT] #4 Gave voorspellingen'
author: hetisdepanda
type: post
date: 2017-04-25T11:03:40+00:00
url: /visuele-fratsen/hdt-4-gave-voorspellingen/
categories:
  - Crappy Cartoons
  - Visuele Fratsen

---
<img decoding="async" src="http://res.cloudinary.com/nietdathetuitmaakt/image/upload/v1499279395/Henk-de-Tijdreiziger-_4.jpg" />