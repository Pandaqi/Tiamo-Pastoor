---
title: Arthur – Deel 1
author: hetisdepanda
type: post
date: 2017-08-03T13:37:54+00:00
url: /toverende-taal/vluchtig-verhaal/arthur-deel-1/
categories:
  - Vluchtig Verhaal

---
Hij moest het zijn. Kon niet anders. Hetzelfde postuur, dezelfde kleine oren, dezelfde grote neus. Zijn haar was anders, dat wel. Waar het vroeger kort was en ondergedompeld in de gel, liet hij het nu golvend lang. Een zonnebril bedekte zijn ogen, en de kleren die hij droeg herkende ik niet, maar ik wist het toch al zeker. Dat was Arthur, daar in het gras, onder de boom, met iemand aan het picknicken. Zijn vriendin, hoogstwaarschijnlijk. Ik was blij voor hem. Ik kon haar gezicht niet goed zien, maar ze leken vrolijk gestemd, gelukkig samen. Misschien moest ik dan maar even wachten. Ik wil zijn leuke middag niet verstoren, en voor hetzelfde geld is hij het niet en kom ik ineens hun romantische picknick dwarsbomen. Ik twijfelde. Arthur zei altijd dat dit één van zijn favoriete plekjes was. Het was té toevallig dat iemand die als twee druppels water op hem leek nou net hier deze mooie zomernamiddag doorbrengt.

Aan de andere kant, misschien was hij wel veranderd. Het was twee jaar geleden dat ik hem voor het laatst had gezien. Het was twee jaar geleden dat ook maar iemand iets van hem had gehoord of gezien. Mijn beste vriend, kameraad door dik en dun, geliefd binnen de vriendenkring en vol in het leven — plotsklaps was hij verdwenen. Hij had zijn studie afgemaakt, maar nooit zijn diploma opgehaald. Hij had grootse plannen bedacht voor de zomervakantie, gesolliciteerd bij meerdere grote bedrijven, maar daar nooit iets van waargemaakt.

<!--more-->

De eerste maanden was er angst. Het zou toch niet? Hij zou toch niet op het verkeerde moment op de verkeerde plek zijn geweest, en iets naars zijn overkomen? Hij was wel vaker een paar dagen spontaan weg, en de eerste week maakten we ons dan ook weinig zorgen. Maar toen na twee weken elk teken van leven uitbleef, schakelden zijn ouders de politie in en werd een grootste zoektocht opgezet. Maandenlang werd op en af gezocht naar Arthur. Er werd nooit iets gevonden. Zelfs op plekken waar hij vaak kwam, of waarschijnlijk die dag nog was geweest, vond men geen spoor. De enige hoop die we al die jaren hadden was dat ze dus ook geen lichaam vonden. Hij moest nog in leven zijn, en ik zou hem vinden.

Toen het wat rustiger werd in het park besloot ik op ze af te stappen. Uit nervositeit liep het uit op een soort snelwandelen, terwijl ik de man geconcentreerd en intens recht aankeek. Eigenlijk sloeg het nergens op. Arthur was mijn beste vriend. Ik heb jaren van mijn leven met hem gedeeld, mijn diepste geheimen zonder twijfeling blootgelegd, maar jaren van afstand tussen ons deed het voelen alsof we elkaar weer voor de eerste keer gingen ontmoeten. De man moet mijn gestreste loopje aan hebben zien komen, want ik moest nog tientallen meters lopen toen hij zich al naar me omdraaide en zijn zonnebril langzaam afzette. Ja, de ogen klopten ook, al leken ze groter en lichter dan ik ze kon herinneren.

&#8211; &#8220;Arthur, ben jij dat? Ben jij dat echt? Ik ben het &#8211; &#8221;  
&#8211; &#8220;Het spijt me, vriend, maar mijn naam is Bert. Dit is Larifa, een vriendin van me. Wie is Arthur?&#8221;  
&#8211; &#8220;Oh. Sorry. Het spijt me zeer, je lijkt enorm veel op Arthur. Hij was mijn beste vriend. Twee jaar geleden verdween hij, en sindsdien reis ik door heel Nederland om hem te vinden. Hij kwam hier altijd graag. Hij at graag broodjes ham, en ik zie dat jullie dat ook eten, dus ik ging er vanuit &#8230; &#8221;  
&#8211; &#8220;Ah, begrijpelijk. Nee, het spijt me, dat is dan geheel toevallig. Al moet ik zeggen dat ik inderdaad onlangs iemand tegenkwam die verdomd veel op mij leek.&#8221;  
&#8211; &#8220;Echt? Had hij kort haar? Weet je waar hij heen ging? Zag hij er gezond uit? En blij? Wacht, nee, dat zijn wel erg veel vragen.&#8221;  
&#8211; &#8220;Maakt niet uit, maakt niet uit. Jazeker, hij zag er gezond en gelukkig uit, en kort haar was zo&#8217;n beetje het enige verschil tussen ons. Ik sprak hem aan, omdat je natuurlijk niet elke dag een dubbelganger tegenkomt. Hij zei dat hij het weer in Nederland een beetje zat was, en al dat gezeur van de mensen. Hij was op weg naar warmere oorden, misschien Frankrijk, of Spanje. Ik wenste hem veel geluk in het leven, en ben doorgelopen.&#8221;  
&#8211; &#8221; &#8230; ik had op een iets specifiekere locatie gehoopt, maar dit is beter dan niets. Nogmaals, het spijt me dat ik jullie picknick onderbreek. Ik heb mijn vriend al zo lang niet meer gezien, ik mis hem enorm. Ik kon deze kans niet laten lopen.&#8221;  
&#8211; &#8220;Begrijpelijk, begrijpelijk. Geen probleem, man. Sterker nog, ik moet naar mijn werk, en ik ben al tien minuten te laat, dus ik moet me haasten.&#8221;

Bert stond op, gooide snel wat afval in de picknickmand, en veegde de restjes van zijn broek. Ook Larifa stond op, vouwde het kleed in elkaar, en legde het op de mand. Bert gaf haar een knuffel, en beloofde haar snel weer te spreken. Ook mij gaf hij een knuffel &mdash; wat ik toch bizar vond voor iemand die je pas net hebt ontmoet &mdash; en wenste me succes met mijn zoektocht. Hij gooide zijn rugtas om zijn schouders, en rende het park uit. Een roos en een notitieblokje vielen bij het wegrennen uit zijn tas, en landden vlak naast de mand op het gras. Zijn vriendin had het waarschijnlijk niet gezien, en liep weg.

&#8211; &#8220;Wacht! Hij heeft iets laten vallen, ik ren achter hem aan.&#8221;  
&#8211; &#8220;Wat? Oh. Nee joh, hij laat zo vaak dingen slingeren. Pak het maar, geef ik het later wel aan hem terug.&#8221;

Ik pakte de spullen op. Ik bladerde even in het notitieblokje, tot ik me bedacht dat het niet gepast zou zijn. Die Bert vertrouwde mij zomaar met zijn spullen, en in de buurt van zijn vriendin, ik moet niet zomaar mijn neus in zijn zaken steken. Ik gaf haar de spullen, en twijfelde. Ik wilde zo snel mogelijk mijn zoektocht verder plannen, maar het is ook zo raar om nu gewoon weg te lopen. Gelukkig brak zij de stilte.

&#8211; &#8220;Woon je hier in de buurt?&#8221;  
&#8211; &#8220;Nee, ik woon eigenlijk nergens. De eerste paar jaar heb ik mijn zoektocht vanuit huis gedaan, maar toen ik steeds verder ging besloot ik elke avond een andere slaapplek te zoeken. Ik slaap vooral in hotels, of bij vrienden en kennissen.&#8221;  
&#8211; &#8220;Dat klinkt als een spannend bestaan! Jij ziet nog eens wat van de wereld. Je ontmoet vast heel veel leuke mensen.&#8221;  
&#8211; &#8220;Nou, ja, deels wel. Ik ken denk ik heel ons land van binnen en van buiten, en ik heb overal wel een soort van vriend om me op te vangen. Maar het is ook zwaar, en jarenlang zoeken naar iets en niks vinden werkt niet heel motiverend. Ik moet elke dag weer vechten om een slaapplek te vinden, en genoeg eten te krijgen. Soms denk ik dat ik het gewoon op moet geven en naar huis moet gaan. Een vaste baan vinden en mijn vriend vergeten.&#8221;  
&#8211; &#8220;Je moet niet zo negatief denken. Natuurlijk, zekerheid en veel geld zijn fijne dingen, maar straks ben je zestig jaar oud en zit je een beetje ongelukkig thuis, met als enige troost dat je altijd veel geld hebt gehad. Nee, geef mij maar het vrije leven, elke dag een nieuw avontuur. Zo heb ik Bert ontmoet, en samen met hem heb ik ongelofelijk veel leuke dingen gedaan. Zeg nou eerlijk, zijn al die mensen die je hebt ontmoet je niet meer waard dan al het geld van de wereld?&#8221;  
&#8211; &#8220;Nou, ja, ik weet niet hoor. Ik ben vaak blij met mijn ervaringen, maar misschien nog wel vaker zit ik oververmoeid in mijn hotelkamer. Soms heb ik te weinig gegeten, soms ben ik die dag beroofd door een stel klootzakken, soms &mdash;&#8221;  
&#8211; &#8220;Oké, ik heb een idee.&#8221;

Larifa trok me abrupt een zijstraat in, en enkele stappen later stonden we samen op het terras van een schattige, klein cafeetje. Ze zocht een ronde tafel in een rustig hoekje, en trok er twee stoelen naartoe. Ze gebaarde dat ik moest gaan zitten, en na enige aarzeling liet ik me toch maar op de stoel vallen. Zelf ging ze recht tegenover mij zitten, en schoof de menukaart die tussen ons stond aan de kant. Ze deed haar hoed af, en legde die op haar kleine, schattige rugtas. Eindelijk kwamen haar mooie blonde lokken tevoorschijn. Een serveerster liep naar haar toe.  
&#8211; &#8220;Is het goed als we hier zitten zonder te bestellen?&#8221;  
&#8211; &#8220;Voor deze keer Larifa, omdat je een trouwe klant bent. Maar weet dat ik niet eeuwig voor je op kan komen. Ik hoop snel een betere baan te vinden, op een betere plek.&#8221;  
&#8211; &#8220;Komt wel goed.&#8221;

De serveerster liep naar het tafeltje naast ons, en Larifa keek haar glimlachend na. Mijn aandacht dwaalde af naar luidruchtige fietsers in de straat, totdat Larifa me ineens strak aankeek.

&#8211; &#8220;Vertel mij je hele verhaal. Alle plekken die je hebt bezocht, mensen die je hebt ontmoet, avonturen die je hebt beleefd. Ik weet zeker dat jij je dan realiseert wat ik je probeer te vertellen.&#8221;  
&#8211; &#8220;Hoe lang heb je de tijd? Dit kan even duren.&#8221;  
&#8211; &#8220;Ik heb alle tijd, maak je daar nou maar geen zorgen over. Vrij leven, weet je nog?&#8221;  
&#8211; &#8220;Goed dan. Eerst ging ik naar Eindhoven. Daar staat de universiteit, daar woonde een paar van zijn vrienden. Daar hadden de meeste hem het laatst zien lopen. Maar niemand had hem toen de afgelopen dagen gezien, niemand had enig idee waar hij heen was. Ik heb twee dagen lang de hele binnenstad afgespeurd. Geen teken. Hij woonde in een dorpje onder Eindhoven, maar ik zag er geen heil in om daar te zoeken &mdash; daar had de politie al meer dan genoeg gedaan. Dus toen lag de wereld open, waar kon hij heen zijn? Ik ben maar gewoon stad na stad, dorp na dorp, afgegaan.&#8221;  
&#8211; &#8220;Maar dat zijn er duizenden!&#8221;  
&#8211; &#8220;Inderdaad. Als wiskundige dacht ik dat ik wel een goede manier kon vinden om ze allemaal af te gaan, maar uiteindelijk was ik zo hopeloos dat ik maar wat rond ben gaan zwerven. In Tilburg dacht ik op een spoor te zijn, maar toen ik het achterna ging raakte ik verdwaald. Gelukkig kwam er een groep studenten langs die terugkwamen van een borrel, en ik heb de dagen daarna bij één van hen gelogeerd. Het was hartstikke gezellig. Hij heeft me de hele stad laten zien en een aantal nieuwe kaartspelletjes geleerd. Hij heeft me nog geholpen met zoeken als hij eens een weekend vrij had, tot aan Den Bosch zelfs, maar geen enkel resultaat.&#8221;  
&#8211; &#8220;Ik heb nu echt zo&#8217;n beeld in mijn hoofd van jij die onder struiken en achter prullenbakken aan het zoeken bent naar die vriend van je. Als een soort ninja spion. Of, zoals je in films ziet, dat je een of andere totaal niet charmante foto uitprint van je vriend en die op alle lantaarnpalen hangt.&#8221;

We moesten allebei lachen. Ook al was het gesprek pas net op gang, het voelde alsof we elkaar al kenden. Het voelde vertrouwd. Mijn eerdere sceptische insteek was verdwenen, en ik had er eigenlijk wel zin in om eens een dagje rustig aan te doen en gewoon mijn verhaal te vertellen.

Soms als ik iets vertelde begon ze daarna druk te schrijven. Ik had haar ergens horen noemen dat ze schrijfster was of wilde worden, en ik probeerde een goed moment te vinden om daar naar te vragen. Dat zou wat zijn, als ze ooit een boek schrijft over wat ik nu vertel. Dat was vast ook de reden dat ze hier met mij was gaan zitten. Ze was lief, ze wilde me vast en zeker ook helpen, maar ze zocht waarschijnlijk gewoon een goed verhaal. Dus ik deed mijn best dat haar te geven. Ze had mij immers ook al iets gegeven &mdash; de volgende aanwijzing in mijn zoektocht.

&#8211; &#8220;Niets van dat alles, ben ik bang. Bij elke nieuwe stad ga ik langs het gemeentehuis, politiebureau, langs grote winkels en uitgaansplekken in de binnenstad. Vaak spreek ik café-eigenaren aan of ze iets hebben gezien of gehoord, of ik ga langs voetbalclubs, omdat Arthur altijd graag naar voetbal keek. Als ik een grote stad heb gehad, zoek ik in de dorpjes er omheen. Dan ga ik langs alle huizen waar nog licht brandt, vragen of ze iets weten, en ongeacht het antwoord vragen of ik de nacht daar mag doorbrengen. Dat vraag ik niet aan iedereen, natuurlijk, alleen de mensen die aardig en betrouwbaar overkomen. Daarnaast wil ik mensen ook niet lastigvallen. Een tijdje geleden was ik voor langere tijd in een dorpje onder Breda, en voor ik het wist kende iedereen me als de jongen die ongevraagd je huis binnendringt. Maar goed, dat maakt niet zoveel uit, er zijn wel ergere dingen gebeurd.&#8221;  
&#8211; &#8220;Zoals?&#8221;  
&#8211; &#8220;Er zijn nachten geweest dat ik buiten in de regen sliep. Alles bij elkaar opgeteld ben ik vier keer overvallen en beroofd. Ik heb een cursus zelfverdediging moeten oppakken, en zelfs dat is soms niet genoeg. Ik ben twee keer achtervolgd door mensen die boos op mij waren, en beide keren wist ik niet te ontsnappen. Ik heb zelfs een keer eten gestolen. Iets waarvan ik niet dacht dat ik het in me had, en ik ben er niet trots op, maar het kon niet anders. Je werkt toch niet stiekem voor de politie, hè?&#8221;  
&#8211; &#8220;Nee nee nee, ik werk voor niemand!&#8221;  
&#8211; &#8220;Dat zeg jij steeds wel mooi, maar hoe kom jij aan inkomen dan? Hoe heb jij een dak boven je hoofd?&#8221;  
&#8211; &#8220;Bijbaantjes, en een paar dingen die ik heb geschreven waren soort van succesvol. Daarnaast, Bert zorgt goed voor me. Hij is ook zo goed als de enige vriend die ik heb. Dat kan ook niet anders. Je kunt niet heel lang een vaste vriendenkring hebben als je steeds wat anders doet en ergens anders uithangt.&#8221;  
&#8211; &#8220;Dat is waar. Toen ik pas net was begonnen met mijn zoektocht had ik mijn gitaar bij, en besloot ik &#8217;s avonds op een mooi plekje wat te spelen. Gewoon, voor mijn eigen plezier. Voor ik het wist begonnen mensen zich om me heen te verzamelen, gooiden mensen munten in mijn gitaarhoes. Sindsdien speel ik voor mijn geld, al is het lang niet altijd even succesvol. Mensen denken dat gitaarspelen een laatste redmiddel is, dat ik een zwerver ben zonder diploma of talent, en kijken op je neer. Ze hebben geen idee dat er jaren van professionele training achter zit, en ze geven er ook niks om. Behalve in Amsterdam. Daar wilde het toeval dat ik vlak naast een stel muzikanten in opleiding begon te spelen, die me vervolgens een paar weken lang veel hebben bijgeleerd. Misschien ga ik dat wel doen, later.&#8221;  
&#8211; &#8220;Dat moet vast veel meisjes aantrekken, een jongen die &#8217;s avonds zwoele gitaarnummers speelt op het gras.&#8221;  
&#8211; &#8220;Dat valt tegen. Echt. Het is een valse mythe dat meisjes direct vallen op jongens die gitaar kunnen spelen. Sterker nog, volgens mij vallen meisjes niet eens op knappe jongens. Je moet echt een klik hebben, de persoonlijkheden moeten goed op elkaar passen.&#8221;  
&#8211; &#8220;Nee? Geen succes in de liefde? Helemaal niets?&#8221;  
&#8211; &#8220;Zoals je net al zei, iemand zonder thuis kent niemand lang genoeg om verder te gaan dan vriendschap. Daarnaast heb ik het idee dat ik eerst mijn vriend moet vinden voordat ik verder kan met mijn leven. Hij was gewoon een groot onderdeel van mijn leven, ik ga hem niet zomaar opgeven.&#8221;  
&#8211; &#8220;Ik denk dat je vriend juist had gewild dat je iets moois van je leven ging maken. God weet waar hij nu uithangt, of wat er is gebeurt, je kunt je leven niet stopzetten. Kijk, ik vind je aardig. Als je wil mag je vannacht bij mij en Bert overnachten, maar alleen als je me belooft dat je daarna jezelf niet meer tegenhoudt en er iets moois van maakt.&#8221;  
&#8211; &#8220;Dat &#8230; vind ik een hartstikke lief aanbod. Ik zou graag met jou slapen. Ik bedoel, bij jou logeren. Als in, in aparte bedden, toevallig in hetzelfde huis. Vriendschappelijk. Gewoon, gewoon.&#8221;

Larifa moest weer lachen. Ze sloeg het notitieblokje dicht, en reikte over tafel om kort mijn hand vast te pakken. Voor het eerst verschenen er pretoogjes, en ze zette opgewekt haar hoed weer op. Ze sprong snel van haar stoel, en ik volgde onmiddellijk.

&#8211; &#8220;Ik weet wat je bedoelt. Wat is er met je gitaar gebeurd, eigenlijk?&#8221;  
&#8211; &#8220;Die heb ik moeten verkopen. Zo&#8217;n ding brengt in één keer meer geld op dan ik met een jaar spelen zou kunnen verdienen. Ik had echt verwacht dat ik binnen een jaar wel mijn vriend zou hebben gevonden, of zou hebben opgegeven. Ik dacht verkeerd. Vriendschap is dus toch sterker dan wat dan ook.&#8221;  
&#8211; &#8220;Misschien. Vergeet niet dat jarenlang bijna constant met elkaar doorbrengen iets speciaals is. Die andere persoon zit dan als het ware in jou geschreven. Ik snap wel dat je achter hem aan moet, echt, maar je moet jezelf niet vergeten. Anders dan vind je hem misschien terug, maar ben jij zijn vriend niet meer.&#8221;

Die nacht spookten haar woorden door mijn hoofd. We hadden bij haar thuis nog lang nagepraat. Het is ongelofelijk hoe veel iemand kan beleven, en hoe veel je kunt leren van iemand. Zij had een heel leven geleefd waar ik niks vanaf wist, meer dan twintig jaar aan ervaringen. Ik wilde ze allemaal weten, maar ik wilde ook achter mijn vriend aan. Ik dacht altijd dat een paar mensen heel goed kennen beter was dan heel veel mensen eventjes spreken. Beter een goede buur dan een verre vriend. Hier, daarentegen, was het ook gewoon prima. Ik zou bij haar kunnen blijven, Bert zou een soort goed-gelukte vervanging van Arthur zijn. Ik twijfelde. Tegelijkertijd zei Bert dat hij Arthur onlangs nog zag, dus hij kan niet ver zijn.

Wat had ik de afgelopen twee jaar nou bereikt? Ik had mezelf losgerukt van de wetenschappelijke en formele wereld, ik had voor mezelf leren zorgen, ik was op avontuur gegaan. Toch werd ik steeds teruggehouden door twijfels. Twijfel is de grootste vijand van actie. Maar ik had een duidelijk doel. Dat is goed toch, één heel duidelijk doel hebben in je leven? Zie je, weer die twijfels.

Ik stond op &mdash; slapen was niet aan mij besteed vanavond. Ik liep naar Larifa&#8217;s kamer, en liep heel voorzichtig naar binnen. Bert moest overuren werken, had ze gezegd, en zou niet voor het middaguur thuiskomen, dus ze lag alleen. Ik hurkte naast haar bed, en probeerde haar wakker te schudden. Enkele seconden later deed ze verveeld haar ogen open, en kreunde zachtjes terwijl ze zich omdraaide.

&#8211; &#8220;Wat is er aan de hand?&#8221; fluisterde ze.  
&#8211; &#8220;Ik moet naar het toilet, maar ik weet niet waar die is.&#8221;

Ik wist heus wel waar die was. Één van de dingen die ik had geleerd van mijn vele avonturen was dat je veel mensen leert kennen door vragen te stellen waar je het antwoord toch al van weet. Weet je waar het station is? Waar kan ik deze winkel vinden? Hoe laat is het? Wat voor weer wordt het morgen? Zo, dat waren weer vier nieuwe vrienden. Alhoewel, vriend is dus een groot woord. Kennis, eerder. Iemand die toevallig mijn levenspad kruist.

&#8211; &#8220;Serieus? Maar je bent al twee keer naar het toilet geweest.&#8221;  
&#8211; &#8220;Ik heb een slecht geheugen.&#8221;  
&#8211; &#8220;Oké, dat is dan ook iets waar je aan moet werken. Het helpt op zich wel om dat soort dingen te onthouden.&#8221;  
&#8211; &#8220;Ik &#8230; wilde je eigenlijk ergens anders over spreken.&#8221;  
&#8211; &#8220;En dat kon niet wachten tot morgen?&#8221;  
&#8211; &#8220;Nee. Ik vond het fijn vandaag, met jou praten. Ik vond het lief dat ik hier mocht blijven. Maar, hoe langer ik blijf, hoe moeilijker het weer wordt om weg te gaan. Ik heb al zoveel lieve mensen achter moeten laten. Ik pak mijn spullen en ga meteen weer verder. &#8221;

Uit automatisme gaf ik haar een vluchtig kusje op de wang, stond resoluut op, en liep de kamer uit. Larifa wilde nog iets zeggen, maar meer dan losse zinsfragmenten kreeg ze er niet uit. Ze wist waarschijnlijk ook niet meer wat ze met mij aan moest. Ik wist niet eens wat ik met mij aan moest. In de deuropening stond ik al de zachte zomerwind in te ademen, toen Larifa me op de schouder tikte. Ik draaide na enige aarzeling om.

&#8211; &#8220;Hier, neem op z&#8217;n minst wat eten en wat geld mee. Oh, en, deze gitaar. Bert vind het vast niet erg.&#8221;  
&#8211; &#8220;Het lijkt me sterk dat Bert zomaar honderden euro&#8217;s weggeeft aan een vreemdeling.&#8221;  
&#8211; &#8220;Geloof me, hij vind het niet erg. Als je maar genoeg geeft, komt er op den duur wel iets voor terug. Althans, dat is zijn filosofie. Dus, zoals ik het begrijp, beloof mij dat je jouw vriend vindt, en dat je dan hier terug komt, en hem de gitaar terug geeft.&#8221;

Ik pakte de grote hoop spullen aan, duwde het vlug in mijn rugtas, en keek haar nog één keer in de ogen aan. Ik begon achteruit te lopen, en ze zwaaide me voorzichtig uit. Enkele plukken haren vlogen zachtjes voor haar gezicht, maar ze haalde ze niet weg. Ze bleef me aankijken; niet blij, niet droef, vooral alsof ze iets bij mij zag dat ik niet kon zien. Toen ik de voortuin had verlaten en de straat had bereikt, draaide ik van haar af. Ik koos een willekeurige richting, en zette het op een lopen.

* * *

Deel 2: [Arthur &#8211; Deel 2][1]

Deel 3: [Arthur &#8211; Deel 3][2]

 [1]: http://nietdathetuitmaakt.nl/vluchtig-verhaal/arthur-deel-2/
 [2]: http://nietdathetuitmaakt.nl/vluchtig-verhaal/arthur-deel-3/