---
title: Freds Wilde Wereld – Deel 6
author: hetisdepanda
type: post
date: 2017-10-06T14:03:00+00:00
url: /visuele-fratsen/freds-wilde-wereld-deel-6/
categories:
  - Crappy Cartoons
  - Visuele Fratsen

---
<img decoding="async" src="http://res.cloudinary.com/nietdathetuitmaakt/image/upload/v1507298474/Fred_s-Wilde-Wereld-_6.jpg" />