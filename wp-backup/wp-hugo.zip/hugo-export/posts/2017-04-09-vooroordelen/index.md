---
title: Vooroordelen
author: hetisdepanda
type: post
date: 2017-04-09T15:00:03+00:00
url: /toverende-taal/genezende-gedichten/vooroordelen/
categories:
  - Genezende Gedichten

---
Waar niemand het nog verwachtte  
Landde slome Japie plotsklaps op hun rug  
Hij had zijn horizon al meermalen verzet  
Stapte omhoog, en keek nooit meer terug