---
title: 'Privé: [Speldagboek] “In hetzelfde schuitje” #9'
author: hetisdepanda
type: post
date: 2019-08-12T13:50:00+00:00
draft: true
private: true
url: /?p=9008
categories:
  - Superieure Spellen

---
Welkom bij het negende speldagboek (&#8220;devlog&#8221;) van mijn spel &#8220;in hetzelfde schuitje&#8221;.

De vorige keer vertelde ik over het ontwikkelen van een &#8220;geschiedenis&#8221; of &#8220;backstory&#8221; voor de wereld. In eerste instantie was mijn plan om dit hele systeem af te maken en dan pas verder te gaan met de volgende stap — schatkisten verstoppen en aanwijzingen bedenken

Het duurde, echter, iets te lang voordat deze &#8220;backstory simulatie&#8221; af was. Toen realiseerde ik: &#8220;hey, ik heb die hele simulatie niet perse nodig om schatkisten uit te proberen! Ik kan voor nu op willekeurige plekken een schatkist plaatsen en dat alvast uitproberen!&#8221;

En zo geschiedde het dat ik mijn werkzaamheden voor de simulatie even staakte en alvast met schatkisten ging werken.

In dit artikel leg ik uit hoe ik willekeurige hints/aanwijzingen/clues naar de locatie van schatkisten genereer.

## Een schatkist

Elke schatkist heeft de volgende eigenschappen:

  * x-coördinaat
  * y-coördinaat
  * eigenaar ( = naam van de piraat die deze schat heeft verborgen)

Voor nu, om dit systeem uit te testen, heb ik deze eigenschappen willekeurig gemaakt. De schatkist wordt ergens in de oceaan gedropt, inclusief willekeurige piratennaam.

(Hiervoor combineer ik gewoon één of twee piraat-achtige termen. Zo heb je piraat &#8220;Thunderbird&#8221;, &#8220;Fingerdance&#8221;, &#8220;Blackblack&#8221;, en nog vele anderen :p)

<!--more-->

Deze eigenschappen zijn het enige dat ik nodig heb om aanwijzingen te bedenken.

  * De locatie is natuurlijk nodig, want elke aanwijzing wijst naar deze locatie :p
  * De naam is nodig om verschillende aanwijzingen aan elkaar te verbinden. In eerste instantie was ik dit vergeten, en waren alle aanwijzingen dus &#8220;een schat ligt in sector 3!&#8221; en &#8220;een schat kan je vinden onder eiland X&#8221;, waar je natuurlijk niet veel wijzer van werd.

## Aanwijzingen

Elke soort aanwijzing is natuurlijk van tevoren door mij bedacht. Ik typ een zin waarin ik gaten laat zitten, die opgevuld moeten worden met info over deze specifieke schatkist.

**Voorbeeld 1:**

<p style="padding-left: 30px;">
  &#8220;Oh yeah, __&#8217;s treasure can be found near __&#8221;
</p>

In het eerste gat moet ik de naam van de eigenaar invullen (&#8220;Blackbeard&#8217;s treasure&#8221;), in het tweede gat moet ik een locatie invullen (zoals een haven of een eiland).

<p style="padding-left: 30px;">
  &#8220;Oh yeah, <em>Blackbeard</em>&#8217;s treasure can be found near <em>Port Royal</em>&#8220;
</p>

**Voorbeeld 2:**

<p style="padding-left: 30px;">
  &#8220;__&#8217;s treasure? I heard there are __ docks within a radius of __ tiles&#8221;
</p>

Het eerste gat is weer de eigenaar, het tweede gat is een getal, en het derde gat is weer een getal.

<p style="padding-left: 30px;">
  &#8220;Thunderbird&#8217;s treasure? I heard there are 3 docks within a radius of 5 tiles.&#8221;
</p>

Nu weet je dat de schat is omringd door drie (dichtbijzijnde) havens.

**Aanwijzingen bedenken:** Het bedenken van deze aanwijzingen was niet zo makkelijk als ik dacht. Je zoekt naar iets dat informatie geeft, maar het niet té makkelijk maakt.

Zoiets als &#8220;de schat is precies 3 tegels verwijderd van haven X&#8221; voelt te makkelijk. Aangezien een haven aan de rand van een eiland zit, en schatten (voor dit moment) alleen op de bodem van de zee liggen, is de kans groot dat er maar een handjevol tegels zijn die in aanmerking komen.

Maar iets in de richting van &#8220;de schat is in het zuiden&#8221; is weer te vaag. Met een beetje pech betekent &#8220;in het zuiden&#8221; hetzelfde als &#8220;ongeveer 95% van de kaart&#8221;.

Al snel merkte ik dat ik vastliep met de aanwijzingen. Het enige interessante wat ik had, was juist een hele bijzondere soort aanwijzing: een _dynamische aanwijzing_.

<PLAATJE> (gewoon om alvast visuele upgrades te laten zien, en de tekst een beetje op te breken)

## Statische & Dynamische Info

Aangezien een schatkist op dezelfde plek blijft liggen, is er informatie die nooit veranderd. Als een schatkist op dit moment in _ondiep water_ ligt, zal die het hele spel in _ondiep water_ liggen.

Dit is **statische informatie**. Veel van de aanwijzingen hebben minstens één onderdeel dat statisch is. Dit maakt de code lekker snel en makkelijk, maar de aanwijzingen saai en voorspelbaar.

Dit zijn voorbeelden van statische aanwijzingen:

  * &#8220;De schat is __ tegels van het dichtstbijzijnde eiland&#8221; => aangezien eilanden niet kunnen lopen, zal de schat altijd even ver blijven liggen
  * &#8220;De schat ligt in sector __&#8221; => aangezien schatten niet verplaatsen, verandert deze informatie ook niet

Op zich is dit prima, maar ze voelen niet organisch en interessant. Stel jij zou onderzoek doen naar de plaats van een beroemde schat. Hoe groot is de kans dat iemand op je afloopt en zegt &#8220;Hé, zoek eens in sector 4&#8221;? Of dat een willekeurig persoon zegt &#8220;Joh, ik hoorde dat je op zoek bent naar die schat. Ik weet er verder niks van af, maar ik weet wel dat hij precies 13 kilometer van de kust ligt.&#8221;?

Nee, het voelt oppervlakkig.

Toen kreeg ik een idee.

Spelers mogen veel dingen in het spel een naam geven: eilanden, havens, steden, hun eigen schip, etc.

Wat nou &#8230; als deze dingen in de aanwijzingen terugkomen? Als iemand ze een naam heeft gegeven, dan komt die naam in de aanwijzing te staan. Maar als niemand dit specifieke ding heeft ontdekt, dan blijft de aanwijzing vaag.

<p style="padding-left: 30px;">
  &#8220;Hmm, I heard that treasure sunk within 6 tiles of <em>Port Royal</em>&#8221; => haven al ontdekt
</p>

<p style="padding-left: 30px;">
  &#8220;Hmm, I heard that treasure sunk within 6 tiles of <em>some dock</em>&#8221; => haven nog niet ontdekt
</p>

De aanwijzing verandert op basis van hoe de wereld verandert. Als je deze aanwijzing aan het begin van een potje krijgt, kun je er minder mee dan wanneer je hem later krijgt. Dit geeft zelfs goede reden om dezelfde plek meerdere keren te bezoeken en dat onderdeel van je strategie te maken.

Dit noem ik **dynamische informatie.**

En ik dacht: als ik dit systeem toch ga gebruiken, kan ik er net zo goed het meeste uithalen. Dus hieronder staan andere voorbeelden van dynamische hints.

  * &#8220;Het schip __ is op dit moment het meest dichtbij de schat&#8221; => in het gat wordt de naam van een _spelersschip_ ingevuld
  * &#8220;De schat wordt bewaakt door monster __&#8221; => in het gat wordt de naam/soort van het meest dichtbijzijnde monster ingevuld

_Opmerking:_ mijn excuses voor de inconsistentie qua taal :p Sommige zinnen zijn ineens Engels omdat ik ze rechtstreeks uit mijn code/notities kopieer, terwijl andere Nederlands zijn omdat ik ze ter plekke schrijf. Ik denk dat het geen probleem is.

## Efficiëntie

Dit gaat een groot systeem worden in het spel, dus efficiëntie is van belang.

De eerste regel is natuurlijk: ik moet niet de hele aanwijzing over het internet gaan sturen. Elke 60 seconden misschien wel honderd stukken tekst heen en weer sturen, is niet iets waar de server blij van wordt.

In plaats daarvan stuur ik slechts het **soort aanwijzing** en de nodige **variabelen** (wat ik moet invullen op de gaten).

Aan de spelerskant wordt de aanwijzing dan &#8220;gereconstrueerd&#8221;. Zij hebben als enige de grote lijst van aanwijzingen, en kiezen simpelweg de juiste aanwijzing en vullen de gaten in.

De tweede regel qua efficiëntie is wat onduidelijker. Ik heb namelijk stiekem drie soorten informatie: statisch, dynamisch, en statisch-dynamisch.

_Wat betekent statisch-dynamisch in vredesnaam?_ Nou, stel we willen de meest dichtbijzijnde haven gebruiken in een aanwijzing. Welke haven dit is, verandert niet. Havens kunnen niet weglopen. Als haven nummertje 4 het dichtstbij is, zal dat het hele spel zo blijven. Maar, de _naam_ van de haven kan dus wel veranderen. Deze informatie is dus enerzijds statisch, anderzijds dynamisch.

Ik kan het statische deel alvast opslaan ( = &#8220;het nummer van de haven&#8221;), en het dynamische deel markeren als iets wat nog moet worden ingevuld ( = &#8220;de naam van de haven&#8221;), maar dat is lastiger dan je denkt.

Vind je dit verwarrend? Ik ook.

Mijn eerste plan was om zoveel mogelijk informatie _voor het begin van het spel_ te berekenen en op te slaan. Maar, zoals je hierboven ziet, zou de code hiervoor nogal dramatisch zijn. Daarnaast is de eerste beurt van het spel al veruit de langste (50-100 ms, tegen 0-5 ms voor de andere beurten).

Daarom besloot ik om alle soorten informatie op één hoop te gooien en _ter plekke_ uit te rekenen. Alleen als een speler informatie opvraagt, worden de gaten ingevuld en de juiste informatie teruggestuurd.

Zo &#8220;verspreid&#8221; je de lasten. Aan het begin van het spel, worden de schatkisten geplaatst en aanwijzingen uitgedeeld. Maar pas tijdens het spel worden de aanwijzingen aangevuld en compleet gemaakt. Zodoende duurt geen enkele beurt te lang.

Ook is de kans groot dat sommige aanwijzingen nooit (of pas laat) worden gelezen. Op deze manier voorkom je veel rekenwerk dat uiteindelijk zinloos blijkt.

## Werkt dit?

Ja en nee.

Ja, de aanwijzingen worden netjes gemaakt en op het juiste moment weergegeven.

Ja, elke keer als je een stad bezoekt, krijg je weer een beetje extra informatie.

Maar nee, het is té lastig om de locatie van een schatkist te bepalen, en daardoor te saai en frustrerend.

Waardoor komt dit? Nou, op dit moment heeft een gemiddelde wereld zo&#8217;n 60-70 steden (aan de rand van een eiland). Ook bevat de wereld drie maal zoveel schatkisten als dat er spelersboten zijn. Zeg even dat we 2 boten hebben en dus 6 schatkisten.

Zie jij wat ik zie? Elke schatkist heeft 10 vage hints, verspreid over de hele wereld. Als je een stad bezoekt, hopend op informatie over schatkist X, is de kans slechts 1/6 dat je iets daarover te horen krijgt. De kans is 5/6 dat je informatie krijgt over een schatkist waar je totáál niet in geïnteresseerd bent.

Waar een schatkaart je normaal gesproken rechtstreeks naar één schat leidt, zorgt het huidige systeem ervoor dat je niet gericht kunt zoeken. Dat is vervelend.

Hoe los je dat op? Nou, door de spelers gericht te laten zoeken!

<PLAATJE> (wederom om de boel op te breken)

## Gericht zoeken

Op dit moment krijgen spelers een bericht &#8220;Do you want to ask around town?&#8221;, waarna ze op een grote knop &#8216;EXPLORE!&#8217; drukken. De volgende beurt krijgen ze de hint terug die op deze locatie is opgeslagen.

Ik wil dat veranderen naar de volgende drie onderdelen

  * &#8220;The people in <your town> might know something. What do you want to ask?&#8221;
  * **Een tekstvak waarin je iets kunt typen**
  * Een grote knop met daarop &#8216;ASK AROUND!&#8217;

In dit tekstvak kun je hetgeen typen waarin je geïnteresseerd bent. Ben je op zoek naar de schatkist van Blackbeard? Dan typ je &#8220;Blackbeard&#8221;!

  * Als de stad een hint heeft over deze schat, krijg je deze terug
  * Zo niet, dan krijg je een error message terug (zo van &#8220;Blackbeard? Never heard of &#8216;em!&#8221;)

Als je dit tekstvak leeg laat, krijg je een willekeurige hint. Op die manier kun je altijd nieuwe informatie krijgen en nieuwe &#8220;namen&#8221; te weten komen.

Nu vraag je misschien: _maar, wat bepaalt of een stad bepaalde aanwijzingen kent?_ Hiervoor kies ik het meest logische antwoord: steden dichterbij de schatkist hebben meer informatie daarover. Dus, zolang een stad binnen een straal van X tegels is van een schatkist, zal deze informatie krijgen daarover.

**Opmerking:** in de uiteindelijke versie van het spel spelen _relaties_ een rol. Als jij een slechte relatie hebt met speler 2, en je komt bij een stad die in het bezit is van die speler, dan kunnen ze je voor de gek houden. Dan krijg je een &#8220;foute&#8221; aanwijzing, om je op een dwaalspoor te brengen.

**Opmerking:** op dezelfde manier krijgt de uiteindelijke versie meer soorten hints. In plaats van dat een hint naar een _schatkist_ leidt, kan een hint ook naar een _scheepswrak_ leiden. Als je dit wrak ontdekt, kun je daar weer nieuwe informatie vinden. Op die manier speelt de historie en opbouw van de wereld een grotere rol én krijg je meer interessante hints.

## Werkt dit dan?

Joah. Met dit systeem kon ik tenminste een volgende werkende versie maken en die uitproberen met verschillende mensen!

Mensen vinden het heel leuk om de schatkisten op te sporen en de aanwijzingen te verzamelen.

Maar, als dadelijk de backstory erbij komt, dan wordt het pas interessant! Dan kan ik namelijk een hoop interessante aanwijzingen toevoegen, omdat ik ook weet _waarom_ een schatkist is begraven, of _wanneer_, of andere info.

Maar voor nu is men tevreden met droge aanwijzingen als &#8220;de schatkist ligt binnen 10 tegels van deze stad&#8221; en &#8220;speler 1 is het dichtste bij&#8221;, en dat is al heel wat.

## Een technische opmerking

Als je niet geïnteresseerd bent in de technische kant van programmeren, kan je dit stuk overslaan!

In eerste instantie gebruik ik altijd de meest &#8220;naïeve&#8221; manier om iets te programmeren. Soms werkt dat prima, soms blijkt dat veel te sloom.

Deze keer was het veel te sloom :p

Ik deed namelijk het volgende:

  * Ga door de lijst van steden heen
  * Bepaal voor elke stad welke schatkisten binnen een straal van 10 tegels liggen.
  * Sla voor al deze schatkisten een willekeurige aanwijzing op.

Met een stuk of 30-40 steden, en gemiddeld 5-10 schatkisten, betekende dit dat ik HEEL VEEL afstanden mocht gaan uitrekenen. (En behoorlijk wat informatie op de server moest opslaan.)

Dat vond ik niet zo leuk, dus ik liet het systeem andersom werken. Steden beginnen zonder aanwijzingen, maar bouwen gedurende het spel informatie op.

  * Aan het begin van het spel heeft geen enkele stad een aanwijzing opgeslagen.
  * Pas als een speler een aanwijzing opvraagt, wordt er het een en ander uitgerekend.
  * Vraagt de speler om een willekeurige aanwijzing? 
      * Dan pakt de stad letterlijk een willekeurige aanwijzing, en slaat deze op.
  * Vraagt de speler om een specifieke aanwijzing (&#8220;Blackbeard&#8221;)? 
      * Eerst kijkt de stad of deze een aanwijzing heeft opgeslagen voor deze naam.
      * Zo niet, dan reken ik uit of de stad binnen 10 tegels van de genoemde schat ligt.
      * Als de stad binnen het bereik ligt, kiest de stad een willekeurige aanwijzing en slaat deze op (onder de juiste naam)
      * Als de stad buiten het bereik ligt, krijgt de speler gewoon een bericht dat ze geen informatie hebben.

Op die manier worden dingen pas uitgerekend (en opgeslagen) als daarom wordt gevraagd.

_Opmerking:_ per schat wordt wel opgeslagen welke aanwijzingen al zijn &#8220;vergeven&#8221;. Anders heb je kans dat alle steden precies dezelfde informatie hebben (&#8220;de schat ligt tussen 3 eilanden!&#8221;), waardoor je nooit zeker weet waar de schat is. Nee, elke stad moet een andere soort aanwijzing bevatten.

## Conclusie

Deze devlog was iets korter dan de andere, maar dat mag wel een keertje. Dit systeem is nou eenmaal niet het moeilijkste om te implementeren. De meeste tijd ging zitten in het bedenken van mogelijke aanwijzingen, met de juiste balans tussen te moeilijk en te makkelijk.

Ik heb nu nog geen idee wat het volgende artikel gaat inhouden. Waarschijnlijk weer iets over die &#8220;backstory simulatie&#8221; en mijn opmerkingen na de nieuwe testpotjes. En anders iets over de visuele kant, want die mag ook wel wat upgrades gebruiken.