---
title: Meester der Misleiding – Deel 2
author: hetisdepanda
type: post
date: 2017-03-16T10:44:39+00:00
url: /toverende-taal/aardige-anekdotes/meester-der-misleiding-deel-2/
categories:
  - Aardige Anekdotes
  - Gewoon een Gedachte

---
<p style="color:gray;">
  DISCLAIMER: In deze reeks vertel ik verhalen over hoe ik het vroeger vaak op sluwe wijze mensen misleidde, zij het voor eigen gewin, zij het omdat het leuk was. Misschien heb je er iets aan, misschien vind je het gewoon leuk.
</p>

* * *

In de meeste keukens heb je verboden voedsel, een soort variant op het verboden fruit in de tuin van Adam en Eva. Het voedsel staat gewoon in de (koel)kast, maar iemand vindt dat het van hem of haar is, of dat anderen er van af moeten blijven omdat zij nog niks er van heeft gehad, of dat iedereen niet zo veel moet eten zodat we morgen ook nog iets hebben. Je hebt ook nog eens de variant waarin ergens een snoeppot staat, en je mag eigenlijk maar één of twee snoepjes per dag.

<!--more-->

Natuurlijk, met dit soort regels gaan mensen heel erg letten op wat er in de keuken gebeurt. Aan de andere kant, mensen die die zogenaamde regels willen overtreden, gaan dat proberen heel stiekem te doen. Misschien rennen ze heel snel naar de keuken als er even niemand is, misschien gaan ze heel nonchalant een halfuur in de buurt van de snoeppot staan om op het juiste moment iets te grijpen. En dat is verkeerd.

Wat veel beter werkte voor mij, is het alom bekende &#8220;hide in plain sight&#8221; — in plaats van stiekem doen, gedraag jij je alsof alles wat je doet volstrekt normaal is. Mensen zullen je dan waarschijnlijk iets &#8220;verkeerds&#8221; zien doen, maar ze zullen er geen moment bij stil staan, omdat het er uit ziet als een normale handeling.

Dus ik zou vaak iets gezonds uit de koelkast pakken met mijn ene hand, en iets ongezonds met mijn andere hand. Mensen die mijn zien lopen, denken &#8220;hij gaat iets eten&#8221;, en ze zijn de keuken alweer uit.

Of, nog leuker, ik deed alsof ik het verboden voedsel aan de kant moet schuiven om ergens bij te kunnen. Dus dan denken mensen eerst &#8220;hé, dat mag niet!&#8221;, dan leg jij het uit, en dan denken ze &#8220;oké prima&#8221;, en kun je _alsnog_ gewoon het verboden voedsel pakken.

Als laatste was het belangrijk om altijd langzaam aan te doen, en misschien ondertussen een beetje te neuriën, of moeilijk te kijken (alsof je ergens diep over nadenkt), of nonchalant een stuk van de verpakking of de krant te lezen. Op de een of andere manier, als mensen je zulke relaxte en rustige dingen zien doen, komt het geen moment in ze op dat je misschien juist iets heel verkeerds aan het doen bent ondertussen.