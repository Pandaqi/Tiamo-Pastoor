---
title: Achteraf gezien
author: hetisdepanda
type: post
date: 2017-01-30T22:46:45+00:00
url: /toverende-taal/genezende-gedichten/achteraf-gezien/
categories:
  - Genezende Gedichten

---
Ik hoop je weer te zien  
Ik hoop je weer te spreken  
Weer te voelen, weer te ruiken  
Als dit alles over is

Ik hoop op een gelukkig weerzien  
Waarbij jij zwaait, lacht  
Ik je knuffel  
Vertel hoe ik het leven  
Afgelopen jaren heb beleefd

Ik hoop rond een tafel neer te strijken  
Starend naar uitgestrekte grasvelden  
Groene heuvels  
Een in stervende zon gebaden stad  
En met jou een glas te delen  
En op iets prachtigs te proosten

Ik hoop in het gras te liggen  
Te bespreken wat ik zo lang voor me hield  
Lange verhalen over vergane dagen  
Avonturen die langer mochten duren  
Ik vertel het jou  
Jij vertelt het mij  
Over de tijd dat ik er niet bij was

Ik hoop je op een fiets te zien stappen  
Te zeggen dat ik je heb gemist  
Dat we dit zeker vaker moeten doen  
Als dit alles over is

Ik hoop je naar de horizon te zien fietsen  
Onder een zachte bries en een luid gejuich  
Achteraf gezien  
Was vroeger alles beter  
Van achteren gezien  
Kan jij alleen maar volle vaart vooruit