---
title: Oh, how times change
author: hetisdepanda
type: post
date: 2019-02-04T16:00:59+00:00
url: /toverende-taal/aardige-anekdotes/oh-how-times-change/
categories:
  - Aardige Anekdotes
  - Gewoon een Gedachte

---
Weet je nog, toen men vroeger klaagde over stripboeken? Het zou slecht zijn voor kinderen. Verschrikkelijk zelfs. Ze moeten fatsoenlijke boeken lezen! Met alleen maar tekst en geen plaatjes! Anders worden ze dom, gek, gestoord, en nog meer slechte dingen! Anders bezitten ze straks een vocabulaire van slechts vier woorden!

Nou, dat lijkt te zijn veranderd. Er is de laatste jaren een nieuw monster verschenen: _internet._ Steeds vaker halen ouders opgelucht adem als hun kind _eindelijk_ een keer van het beeldscherm af is en een &#8220;gezonde activiteit&#8221; onderneemt, zoals stripboeken lezen.

Of het maakt eigenlijk niet uit wat de kinderen doen, als ze maar geen beeldscherm voor hun ogen hebben. Jongleren met willekeurige voorwerpen uit de fruitschaal? Prima, maar niet op je mobiel zitten! De konijnen over de piano laten lopen in de hoop dat ze leuke muziek maken? Doen! Maar niet de iPad erbij pakken! De hond trainen om snoepjes te stelen voor jou terwijl je huiswerk maakt? Goed idee. Je zit tenminste niet achter de computer.

Ik vraag me af hoe dat in de toekomst gaat zijn.

<p style="padding-left: 30px;">
  *iemand komt &#8217;s avonds laat thuis van werk*<br /> &#8220;Schat, heb jij Thomas gezien?&#8221;<br /> &#8220;Hij zit al de hele dag achter de computer te gamen.&#8221;<br /> &#8220;God zij dank! Zolang hij maar niet weer de hele dag met z&#8217;n <em>virtual reality</em> bril rondloopt.&#8221;
</p>

Tientallen jaren later.

<p style="padding-left: 30px;">
  *iemand komt &#8217;s avonds laat thuis van werk*<br /> &#8220;Schat, heb jij Thomas 2.0 gezien?&#8221;<br /> &#8220;Hij is al een week in zijn virtual reality wereld.&#8221;<br /> &#8220;God zij dank! Zolang hij maar niet weer de hele dag hologrammen van zichzelf maakt.&#8221;
</p>