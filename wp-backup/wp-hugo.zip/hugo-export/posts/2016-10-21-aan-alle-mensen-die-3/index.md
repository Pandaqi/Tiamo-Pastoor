---
title: Aan alle mensen die…
author: hetisdepanda
type: post
date: 2016-10-21T15:00:55+00:00
url: /gewoon-een-gedachte/aan-alle-mensen-die-3/
categories:
  - Gewoon een Gedachte

---
&#8230;net als ik nooit eens een keer geluk hebben in een spel. Geef het op &#8211; het gaat nooit veranderen :p Negen van de tien keer zul jij net degene zijn die vijftien rondjes in de gevangenis blijft hangen in Monopoly. Negen van de tien keer ben jij bij het pesten net degene zonder joker of 2, en pleuren je vrienden voor jou zoveel pestkaarten op elkaar dat je maar beter gewoon meteen je verlies kunt accepteren. Negen van de tien keer dobbel je vier keer een 1, terwijl alles wat je nodig had één worp boven de 1 was. Negen van de tien keer speel je Scrabble en zit jij te kijken met alle exotische letters, en geen klinkers.

En die één uit de tien keer dat het wel goed gaat?

Wacht maar, dan blijkt er vast een regel te zijn die je over het hoofd hebt gezien, en zit je alsnog met de gebakken peren. En veertig punten achterstand in Ticket to Ride. Na vijf rondjes pas.

En dan denk je misschien: ah, dan ga ik wel een computerspel spelen, of een bordspel zonder geluk, kaarten of dobbelstenen. Maarja, dan wil de rest weer niet spelen, want dan kunnen ze niet genieten van hoe hard jij faalt :p