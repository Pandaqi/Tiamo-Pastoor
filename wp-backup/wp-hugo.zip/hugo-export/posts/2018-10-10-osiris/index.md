---
title: Osiris
author: hetisdepanda
type: post
date: 2018-10-10T22:27:28+00:00
url: /toverende-taal/genezende-gedichten/osiris/
categories:
  - Genezende Gedichten

---
Osiris  
de god van de dood  
heeft jou meegenomen  
zijn naamsgenoot

hij kwam onverwachts  
hij kwam heel erg vlug  
had slechts enkele zinnen nodig  
en hij wilde je terug

het ene moment sprong je  
vrolijk grassprieten plat  
trok je planten haast uit de grond  
likte ongevraagd mijn vingers nat

het andere moment lag je  
onbeweeglijk op je zij  
ogen nog open  
helder als altijd  
niemand zag dit aankomen  
ook niet jij

vier jaar heb ik jou  
met je zus  
elke dag eten gegeven  
in de zomer sprong je buiten  
en &#8217;s avonds tilde ik je even  
weer naar binnen, om te schuilen  
kou voor warmte te verruilen

en in het holst van de nacht  
als ik mijn bed wilde voelen  
brak ik eerst een stukje brood in twee  
en als je lief keek  
braken nog meer stukjes mee  
en stonden jullie met hongerige smoelen  
tegen de hokrand aangedrukt

nu breek ik nog het brood  
het automatisme zal lang blijven  
maar beide stukjes blijven  
voor jouw zus  
want na jouw dood  
zal Osiris over je waken  
en de stukjes brood die braken  
en die tripjes uit de kooi  
naar buiten,  
weer naar binnen,  
op de tafel,  
onder de tafel,  
door de tuin,  
tussen vers hooi,  
zijn voor jou hopelijk vervangen  
door een zachte slaap tegen de wangen  
van je nieuwe verzorger, Osiris,  
die ook ziet: wat was jij mooi