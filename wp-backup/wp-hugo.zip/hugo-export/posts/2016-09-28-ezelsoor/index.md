---
title: Ezelsoor.
author: hetisdepanda
type: post
date: 2016-09-28T15:00:28+00:00
url: /gewoon-een-gedachte/ezelsoor/
featured_image: https://nietdathetuitmaakt.nl/wp-content/uploads/2016/09/plantnu-fotos-194.jpg
categories:
  - Gewoon een Gedachte

---
Er is een plantensoort, hier niet zo ver vandaan, die maar weinig mensen kennen. Sterker nog, er is een plant die op veel plekken in Nederland veelvuldig voorkomt, maar veel te weinig aandacht krijgt. Ik heb het hier, natuurlijk, over _Ezelsoor_.

<p class="remark">
  Dit was mijn allereerste artikel dat ik ooit schreef voor dit blog, járen geleden, toen ik niet eens wist hoe dit werkte en of ik wel wilde bloggen. Ik laat het online staan omdat ik het belangrijk vind om te laten zien waar ik vandaan kom en hoe ik langzaam beter heb leren schrijven. (In de hoop duidelijk te maken dat &#8220;talent&#8221; nooit ergens iets mee te maken heeft.)<br /><br />Maar om een of andere reden denken veel bezoekers &#8220;hé, wat een leuk blog, laat ik eens naar het alleroudste bericht gaan en die lezen!&#8221; &#8230; en dan komen ze dit vage en slecht geschreven artikel over ezelsoor tegen. Dus ik zeg het even.
</p>

De ezelsoor&nbsp;is geclassificeerd als onkruid, maar dat vind ik een grove belediging. Het is een grijze plant die&nbsp;er weinig bijzonder uitziet, maar, en dit is het hele punt,&nbsp;_de plant heeft superzachte&nbsp;bladeren_! Je zou een bed kunnen maken van ezelsoor en er&nbsp;heerlijk op&nbsp;kunnen slapen. Je zou een bal van vijfhonderd kilo ezelsoor keihard tegen iemand aan kunnen gooien, en die persoon zou dat&nbsp;hartstikke fijn vinden. Je zou&nbsp;je hele huis kunnen bedekken met ezelsoor en&nbsp;op elk willekeurig meubelstuk in slaap kunnen vallen.

<!--more-->

Maar,&nbsp;het brengt wel een bepaalde kwestie aan het licht. Evolutionair gezien, overleven de planten die bepaalde weersomstandigheden kunnen weerstaan, en waarvan de zaden druk worden verspreid. Dit betekent dus dat er vroeger dieren moeten zijn geweest die&nbsp;de plant zagen, en dachten &#8220;heu, dat is handig, mijn zoon is binnenkort jarig, ik kan hem best een nieuwe knuffelbeer geven&#8221;, en vervolgens de plant meenamen en in hun eigen&nbsp;tuintje plantten.&nbsp;Ja, of dat&nbsp;grote beesten met hun lompe poten per ongeluk&nbsp;in de plant gingen staan,&nbsp;maar daar voelden ze niks van, dus sleepten ze zo de plant mee.

Dit impliceert, echter, dat het dus wel degelijk mogelijk is voor zachte dingen om&nbsp;te overleven in deze harde wereld. Ik stel dan ook voor dat iedereen hier een voorbeeld aan neemt, en probeert wat zachter met elkaar om te gaan. Je hoeft niet iemand anders te kleineren om zelf groter te worden. Wees&nbsp;een ezelsoor.