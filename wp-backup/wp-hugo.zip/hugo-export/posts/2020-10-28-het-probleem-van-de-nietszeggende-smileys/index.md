---
title: Het probleem van de Nietszeggende Smileys
author: hetisdepanda
type: post
date: 2020-10-28T16:00:50+00:00
url: /gewoon-een-gedachte/het-probleem-van-de-nietszeggende-smileys/
categories:
  - Gewoon een Gedachte

---
Ik ben al een tijdje bezig met een jongerenroman.

Ik ben erg geïnteresseerd in boeken die iets speciaals doen, die wat interactiever zijn en met de tijd meegaan, dus ik besloot om door het verhaal heen korte plaatjes van berichten, websites, SMSjes, en dergelijke te stoppen. (Die vertellen natuurlijk wat informatie over het verhaal, maar bevatten ook hints en dingen die het verhaal spannend houden.)

Toen ik onderzoek ging doen naar de verschillende manieren van online communiceren, viel mij een bijzonder fenomeen op:

<p style="padding-left: 30px;">
  Men zet achter <em>alles</em> een compleet overbodige en nietszeggende smiley.
</p>

Zowel jongeren, als volwassenen, als bedrijven, iedereen!

Het begint met relatief onschuldige, informele berichten die zoiets doen:

<!--more-->

<p style="padding-left: 30px;">
  &#8220;Haha dat is echt grappig <span class="emoji">😂</span>&#8220;
</p>

<p style="padding-left: 30px;">
  (Op zich past alles bij elkaar en is de boodschap duidelijk, maar was het echt nodig om drie keer hetzelfde te zeggen? :p)
</p>

<p style="padding-left: 30px;">
  &#8220;Ik heb mijn diploma gehaald! <span class="emoji">🎉🎉🎉</span>&#8220;
</p>

<p style="padding-left: 30px;">
  (Als ik zo&#8217;n bericht krijg, raak ik altijd meteen gedesoriënteerd. Mijn ogen worden op magische wijze naar die drie smileys toegetrokken en de inhoud van het bericht komt eigenlijk nauwelijks meer binnen. Ik lees vaak per ongeluk over dit soort berichten heen, wat nou juist <em>niet</em> de bedoeling is, want daarom had die ander er wel <em>drie</em> smileys achter gezet!)
</p>

&nbsp;

Maar het wordt erger. Soms worden mij samenvattingen van sportwedstrijden aangeraden op YouTube. Wat denk je dat de titels zijn?

<p style="padding-left: 30px;">
  &#8220;<SPELER> FURIEUS NA RODE KAART! 🤬&#8221;
</p>

<p style="padding-left: 30px;">
  (Poeh, ik vraag me af wat het woord <em>furieus</em> betekent. Oh, hey, daar is een smiley om het uit te leggen!)
</p>

<p style="padding-left: 30px;">
  &#8220;LIVERPOOL ON FIRE 🔥&#8221;
</p>

<p style="padding-left: 30px;">
  (Ah, dus dát is wat vuur betekent.)
</p>

<p style="padding-left: 30px;">
  &#8220;MOOI DOELPUNT VAN <SPELER> ⚽&#8221;
</p>

<p style="padding-left: 30px;">
  (Deze is al helemaal mooi. Bij een voetbalsamenvatting een voetbalemoticon neerzetten, ik zeg GENIAAL!)
</p>

Ten eerste: stop met alles in hoofdletters te typen! Het vermindert leesbaarheid en voelt alsof je een schreeuwende peuter bent die aandacht wil. Maar bijna iedereen doet het tegenwoordig.

Ten tweede: we zijn toch niet allemaal tegelijkertijd achterlijk geworden? Wat is het nut van die smileys? Ze voegen niks toe en verminderen vaak de leesbaarheid (omdat ze niet mooi samengaan met de rest van de tekst en hun eigen kleuren hebben). Ik zie al voor me hoe een of andere stagiaire die video&#8217;s online moet zetten en elke keer een half uur kijkt naar een lijst van smileys om dé perfecte toevoeging te vinden.

&nbsp;

Maar het blijft niet bij dit soort &#8220;sensationele&#8221; praat, nee nee. Ik zit op LinkedIn en zie berichten van grote universiteiten en bedrijven voorbijkomen die dit soort dingen zeggen:

<p style="padding-left: 30px;">
  <span class="break-words"><span dir="ltr">&#8220;Stealing your online identity can be a highly profitable 💰 business for cyber criminals.&#8221; </span></span>
</p>

<p style="padding-left: 30px;">
  (Ohh, dus <em>dat</em> bedoelen ze met <em>profitable.</em> Nou, als je er zakken geld mee verdiend, dan ga ik ook maar zo&#8217;n &#8211; eh &#8211; cyber criminal worden!)
</p>

&nbsp;

<p style="padding-left: 30px;">
  &#8220;Met trots kunnen we mededelen dat onze student <naamhier> is geslaagd! <span class="break-words"><span dir="ltr">🎓</span></span>&#8220;
</p>

<p style="padding-left: 30px;">
  (Kijk, ik snap het idee wel. Als je door je feed scrolt kan je aan de smiley meteen zien wat ongeveer de inhoud van het bericht is. Dan weet je meteen: oh even kijken wie er is geslaagd. Maar dat is het juist: de smileys zorgen ervoor dat dingen <em>niet</em> meer worden gelezen of inhoudelijk overwegen. Mensen springen gewoon van smiley naar smiley, alsof je alleen het eerste woord van alle koppen uit de krant leest.)
</p>

&nbsp;

<p style="padding-left: 30px;">
  &#8220;<span class="break-words"><span dir="ltr">📣 Wij zijn op zoek naar een <een of andere functietitel die klinkt alsof ze het zelf hebben bedacht>! 📣</span></span>&#8220;
</p>

<p style="padding-left: 30px;">
  (Ik weet niet eens wat ze hiermee willen. Een megafoon neerzetten doet natuurlijk helemaal niks voor je bereikbaarheid, en wederom komt het nogal aandachttrekkerig over. Dat ze zowel aan het begin als het eind een smiley neerzetten vind ik dan weer interessant. Misschien zijn ze programmeurs en denken ze dat je een geopende smiley ook moet afsluiten :p)
</p>

&nbsp;

<p style="padding-left: 30px;">
  <span class="break-words"><span dir="ltr">&#8220;Hi 👋 We are <company>! We strive to reshape reality and enable our species to experience a world beyond what we&#8217;re capable of today 💫 Interested? Follow us to see the what we’re working on 💜&#8221;</span></span>
</p>

<p style="padding-left: 30px;">
  (Hier ben je me volledig kwijt. &#8220;Hi&#8221; is niet zo&#8217;n moeilijk woord, het handgebaar hoeft er niet bij. Vervolgens waren ze vergeten dat er zoiets bestond als leestekens die een zin afsluiten, of witruimte, dus besloten ze zinnen uit elkaar te zetten met smileys die slechts heel vaag gerelateerd zijn aan de inhoud.)
</p>

Ik vind het allemaal maar bijzonder.

Ik heb geprobeerd om het in mijn boek over te nemen &#8211; want voor zover ik kan zien gaat de meerderheid van communicatie nu op deze manier &#8211; maar het voelt alsof ik zo&#8217;n oude opa ben die probeert &#8220;stoer&#8221; te doen door jongerentaal over te nemen. Alleen is het in dit geval geen jongerentaal, maar gewoon een manier van communiceren die ik maar niet kan ontrafelen. (En ben ik gewoon een jongvolwassene. En het helpt ook niet dat boeken in zwart-wit worden gedrukt, waardoor emoticons al helemaal niet spectaculair zijn.)

In mijn ogen is dit geen vooruitgang. Mensen lezen alleen nog maar de smileys en denken daarmee de hele inhoud te hebben meegekregen. In het beste geval vertellen de smileys dubbele (of driedubbele) informatie, in het ergste geval zijn ze slechts vaag gerelateerd en krijgt de lezer een compleet verkeerde impressie. (En het kost allemaal tijd om die smileys te vinden en op de juiste plek te zetten.)

Smileys hebben hun plaats en tijd, en een goedgeplaatste smiley zegt meer dan 1000 woorden (of is simpelweg broodnodig om de juiste toon aan een bericht te geven dat meerdere interpretaties heeft). Maar dit fenomeen schaar ik voorlopig onder dezelfde categorie als van die mensen die een bericht vol met spelfouten typen en dan boos zijn dat er een miscommunicatie ontstaat.

Maar wie weet, na veertig hoofdstukken met elk zo&#8217;n plaatje in mijn boek, krijg ik een dieper inzicht en vergaar ik de wijsheid die blijkbaar alle socialmediastrategen al lang geleden hebben gevonden.

&nbsp;

P.S. Ik hoop dat alle smileys er ongeveer hetzelfde uitzien in alle browsers, anders was dit waarschijnlijk een héél verwarrend artikel.

&nbsp;

&nbsp;

&nbsp;