---
title: Het geheim van de toiletpapiersleurder
author: hetisdepanda
type: post
date: 2019-01-06T16:00:02+00:00
url: /toverende-taal/aardige-anekdotes/het-geheim-van-de-toiletpapiersleurder/
categories:
  - Aardige Anekdotes
  - Gewoon een Gedachte

---
Het is laat op de avond. Wat zeg ik, het is al middernacht geweest. In gedachten loop ik naar het toilet, totdat ik in mijn ooghoek iets raars zie. Er slingert iets langs mijn voeten. Iets wat daar niet hoort te zijn. Gelukkig ben ik een fatsoenlijke detective en heb ik meteen bewijsmateriaal vastgelegd:

<div class="wp-block-image">
  <figure class="aligncenter size-full"><img decoding="async" loading="lazy" width="897" height="1600" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/WhatsApp-Image-2018-09-23-at-01.25.15_result.webp" alt="" class="wp-image-11750" /><figcaption>Hier zien we toiletpapier buiten zijn natuurlijke habitat. Sst! Geen geluid maken. Anders schrikt ie!</figcaption></figure>
</div>

Beduusd en verward ruim ik de rommel op en ga zo snel mogelijk naar bed. Ik had dus écht geen zin in toiletpapiergeesten.

(Overigens, een wcrol _uitrollen_ is verdraaid makkelijk, maar een uitgerolde wcrol weer _oprollen_ is onmogelijk. Het is een beetje hetzelfde als met luchtbedden. Het luchtbed uitvouwen en oppompen is makkelijk. Hem daarna weer leegkrijgen en in je rugzak stoppen die ineens lijkt te zijn gekrompen &#8211; onmogelijk.)

De volgende ochtend hoor ik de mythes. Mijn moeder schijnt dit onlangs ook al te zijn tegengekomen. Iemand anders is wel eens benedengekomen om tot diens schrik mijn broertje door de keuken te zien slaapwandelen. Mijn broertje herinnert zich er vervolgens niks meer van. Verdacht. Héél verdacht. Er schijnen meer slaapdronken mensen te zijn, die &#8217;s nachts ineens moeite hebben met de wc vinden. (En moeite met in de pot plassen, maar dat is een ander verhaal. Op zich valt dat nog mee met mijn stommiteiten als kind. Toen ging ik regelmatig &#8217;s nachts op de wc zitten &#8230; maar vergat dat de deksel er nog opzat en plaste dus bovenop de deksel.)

Maar geen van hen zou een wcrol meenemen en dan halverwege hun vlucht naar boven weer laten vallen. Dat zouden ze wel merken. En ik mag toch hopen dat ze het zelf zouden opruimen.

Nu sta ik op scherp. Vanaf 11 uur &#8217;s avonds houd ik _iedereen_ bij die naar beneden komt.

Ik kom het even later nog een keer tegen. Maar &#8230; deze keer was er helemaal niemand meer beneden gekomen! (Gelukkig was de misdadiger minder ver gekomen. In het plaatje hierboven moest ik meters wcrol oprollen; deze keer maar een meter.)

Ik word helemaal gek. Ik laat alles in mijn leven vallen om de toiletpapiersleurder te achterhalen. School? Niet meer belangrijk. Gezondheid? Nah, ik ga op de toiletpapiergeesten jagen. Eten? Oké, wel eten. Eten is belangrijk.

Totdat ik op een dag de keukendeur zie openzwaaien om 12 uur &#8217;s nachts. Er is niemand anders beneden. Toch schrik ik niet: dit gebeurt wel vaker. Onze hond is iets gaan drinken op de gang en komt terug de keuken in.

AHA! Onze hond is de schuldige! Hij loopt steeds richting de wc, ziet een wcrol, denkt dat hij ermee moet spelen, en laat zo een speurtocht achter in het huis. De dagen erna let ik constant met een schuin oog op onze hond &#8230; maar ik heb hem nooit meer met een wcrol in de mond gezien. Harde bewijzen blijven uit. Jammer genoeg kan ik deze zaak nooit sluiten.

Toch ben ik zeker dat hij het was. Toen het kouder werd (want dat gebeurt als het herfst en winter wordt), en men de deuren niet meer lieten openstaan, is het nooit meer gebeurd. Maar ooit wordt het weer lente, en dan ga ik hem op heterdaad betrappen.