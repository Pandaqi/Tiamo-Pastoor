---
title: De Stofhond
author: hetisdepanda
type: post
date: 2016-09-30T15:00:35+00:00
url: /gewoon-een-gedachte/de-stofhond/
categories:
  - Gewoon een Gedachte

---
Moderne honden kijken tegenwoordig nergens meer van op. Ze zijn gewend aan een grote hoeveelheid lawaai en drukte, aan veel schermen en toestellen en toeters en bellen, en zijn vaak niet eens zelf voor een spelletje te porren. Maar er is één ding waarvoor dat niet geldt. Er is één voorwerp dat honden in hun dromen achterna jaagt, ze op doet springen wanneer ze lekker slapen, en ze in staat stelt plotsklaps een koprol achterover te doen.

Het is de _stofzuiger_.

Ongeacht wat de hond aan het doen is, ongeacht of hij het ziet aankomen of niet, hij schrikt van de stofzuiger. Eerst is het een korte woeste blik en een sprongetje achteruit. Maar wanneer de stofzuiger nog een keer dichtbij komt, schiet de staart stijf omhoog en valt de hond zijn prooi aan.

<!--more-->

Wat raar is, want waarom zou je iets aanvallen waar je bang voor bent? Meestal, na de eerste &#8220;aanval&#8221; springt de hond nog banger achteruit en druipt af met een kleine hartaanval.

De enige reden waarom een hond zoiets zou doen, is omdat het denkt dat zijn leven wordt bedreigd door de stofzuiger. Althans, dat is de enige reden waarom iemand uit zelfverdediging iemand anders (waarvoor diegene bang is) zou aanvallen. Als iemand op je af komt met een mes, ren je weg. Als iemand plotsklaps op tien centimeter afstand staat, met een mes, kan je niks anders dan diegene wegduwen en uitschakelen.

Hoe dan ook, blijkbaar zijn dieren bang voor iets dat lucht opzuigt. En daarbij een hoop lawaai maakt. Dit is natuurlijk handige informatie als je ineens op straat aangevallen wordt door een wilde hond (of een wild konijn, of een wilde olifant &#8211; zolang het maar wild is)

Neem dus altijd je stofzuiger mee.