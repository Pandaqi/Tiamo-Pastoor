---
title: Aan alle mensen die …
author: hetisdepanda
type: post
date: 2018-06-13T07:40:57+00:00
url: /gewoon-een-gedachte/aan-alle-mensen-die-9/
categories:
  - Gewoon een Gedachte

---
&#8230; films kijken _zonder daadwerkelijk de film te kijken_. Je weet waar ik het over heb. Stop daarmee.

De situatie is als volgt. Iemand zegt: &#8220;oh laten we samen een film kijken, leuk!&#8221; Vervolgens doe jij moeite om een film (of serie) uit te zoeken, eentje die leuk is en die waarschijnlijk ook bij jullie allebei past, en je begint samen te kijken.

Na vijf minuten zit die ander op haar telefoon. &#8220;Oh nee ik moest gewoon even iets checken.&#8221; Tien minuten later komt de telefoon weer naar buiten. &#8220;Oh nee ik dacht dat ik een berichtje kreeg.&#8221; Nog eens tien minuten later staat die ander uit het niets op om naar het toilet te gaan en eten te maken. Jij pauzeert de film, maar die ander zegt &#8220;nee hoor laat maar doorspelen&#8221; Uiteindelijk mag jij halverwege de film _alles_ uitleggen, want die ander heeft eindelijk zijn aandacht van de telefoon weggekregen, maar begrijpt nu niet meer waar het over gaat.

WAT IS HIERVAN DE BEDOELING!?

<!--more-->

Mijn reden om een film te kijken is _om geëntertaind te worden door de film_. (Mijn tweede reden om een film te kijken is om hem te analyseren en zodoende meer te leren over plot, personages en verhalen vertellen in het algemeen.)

Maar blijkbaar zijn er meer redenen om een film te kijken. Als je ernaar vraagt zegt men altijd: &#8220;ja, maar ik kijk films vooral om gezellig samen te zijn.&#8221; Maar over dat argument lijkt niemand ooit nagedacht te hebben. (Het komt ook verdacht snel uit hun mond.) Als je gezellig samen wilde zijn, HAD JE NIET OP JE MOBIEL MOETEN ZITTEN.

Als je écht gezellig samen wilde zijn, had je, om maar iets te noemen, niet een film aan moeten zetten. Het is een stuk makkelijker om te kletsen als op de achtergrond _geen _explosies plaatsvinden, en als je gesprekspartner _geen_ intrigerende dialoog probeert te volgen. Ga gewoon rond een tafel zitten en vertel goede verhalen.

_Opmerking: _datzelfde frustreert mij als ik met mensen een (bord)spel of sport probeer te doen. Ze spelen niet serieus, letten niet op, en breken regels. Wat is het excuus? &#8220;Tss, niet iedereen speelt een spel om te winnen, sommigen doen het gewoon voor de gezelligheid.&#8221; HET HELE IDEE VAN EEN SPEL IS DAT JE WILT WINNEN. Je zet een bepaalde belevingswereld op, een bepaald avontuur of verhaal, en iedere speler waant zich een onderdeel daarvan. En, binnen dat verhaal, binnen die regels, wil je winnen. Het is namelijk ongelofelijk makkelijk om te verliezen, maar proberen te winnen geeft _uitdaging_, en mensen houden van uitdaging. Als iemand niet speelt om te winnen, betekent dat vooral dat diegene lui is en weigert om na te denken en moeite te doen. (Misschien bestaat dat wel: faalangst voor bordspellen.) Nog erger: als iemand niet speelt om te winnen, verpest hij meteen het spel voor alle andere spelers. Samen spelen is van nature zo sociaal als maar kan, en juist door te zeggen &#8220;het gaat om meedoen, niet om winnen&#8221;, verpest je dat. Zoals ik altijd zeg: als niemand speelt om te winnen, valt er ook niks te spelen.

Ik vind het apart dat mensen &#8220;afleiding&#8221; zien als een een nodige voorwaarde voor sociaal zijn. Ik heb wel eens commentaar gehad dat ik niet &#8220;open&#8221; genoeg was, dat ik niet genoeg &#8220;praatte&#8221;, maar diezelfde mensen vonden het dan wel compleet normaal om hun oortjes in te houden als ik met hen sprak. Diezelfde mensen zaten op hun mobiel, of konden halverwege een gesprek opstaan en weglopen. (Overigens was de reden dat ik niet veel praatte omdat ik vaak mijn stem kwijt was, of heel erg veel last van mijn stem had. Maar ja, dat kun je dan natuurlijk niet uitleggen. Daarnaast dacht ik jarenlang dat ik een soort overdreven, uitgerekte baard-in-de-keel had. Dat bleek niet zo te zijn. Sterker nog: uitgaande van de huidige toonhoogte van mijn stem, heb ik nooit de baard in de keel gehad :p)

Op eenzelfde manier ben ik op talloze feesten/bijeenkomsten geweest waar het hartstikke gezellig was, totdat iemand zei: &#8220;het is wel stil zo, hè? Laat ik muziek aanzetten.&#8221; Vervolgens was er alleen nog maar ruis, en was het hele idee van zo&#8217;n bijeenkomst toch een beetje verpest. Waarom doen ze dat? Waarom denkt men dat &#8220;sociaal zijn&#8221; betekent &#8220;voor de helft met je aandacht ergens anders zijn&#8221;?

Je zou kunnen denken dat het iets van &#8220;deze generatie&#8221; is. (Waarbij ik losjes doel op alle mensen die nu onder de 35 zijn.) Dat mensen een enorm korte concentratieboog hebben, verslaafd zijn aan hun smartphone, en almaar proberen te multitasken. Ik denk dat het er zeker mee te maken heeft, maar het is niet de hele reden, want ik bemerk dit probleem ook bij oudere mensen.

Mijn ouders zeggen bijvoorbeeld vaak van tevoren: &#8220;ik denk niet dat ik de hele film/het hele spel volhoudt&#8221; of &#8220;nee mijn hoofd kan het toch niet bijhouden; ik begrijp het toch niet&#8221;. Ik denk dan: &#8220;prima, een beetje pessimistisch, maar dan sta je na een half uur op en ga je naar bed&#8221;. Echter, als je dan de film kijkt, blijven ze de gehele speelduur zitten, terwijl hun aandacht heen en weer vliegt tussen hun telefoon, de film, en luide gesprekken met andere filmkijkers. Aan de andere kant, als je dan toch een bordspel gaat doen, blijven ze het hele spel erbij, maar luisteren bijvoorbeeld niet als je de spelregels uitlegt of als iedereen roept &#8220;JIJ BENT AAN DE BEURT&#8221;.

Kortom: mensen hebben een verknipt idee van wat gezellig samenzijn betekent. Maar de mensen die een film opzetten om hem vervolgens niet te kijken, of misschien zelfs anderen verhinderen om ervan te genieten, die zijn het ergst :p