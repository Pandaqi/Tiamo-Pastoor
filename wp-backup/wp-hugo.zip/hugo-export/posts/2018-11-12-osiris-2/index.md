---
title: Osiris
author: hetisdepanda
type: post
date: 2018-11-12T12:15:54+00:00
url: /gewoon-een-gedachte/osiris-2/
categories:
  - Gewoon een Gedachte
  - Muzikale Meesterwerken

---
Ik heb een compositie geschreven (en opgenomen) voor mijn onlangs overleden konijn, genaamd Osiris. Het is natuurlijk een stomme reden, maar het is wel de eerste compositie ooit die ik heb afgeschreven op de akoustische (Spaanse) gitaar, en waar ik ook trots op ben. 

Luister en geniet (hopelijk):<figure class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio">

<div class="wp-block-embed__wrapper">
  <span class="embed-youtube" style="text-align:center; display: block;"></span>
</div></figure>