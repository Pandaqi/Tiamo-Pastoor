---
title: Post-Handtekening
author: hetisdepanda
type: post
date: 2017-03-31T15:00:26+00:00
url: /gewoon-een-gedachte/post-handtekening/
categories:
  - Gewoon een Gedachte

---
Regelmatig staat er een postbode voor onze deur en belt deze aan omdat er een pakketje is voor iemand in het huis. Vaak kan ik het pakketje zo aannemen, zeg &#8220;houdoe&#8221; (of iets wat er op lijkt als het nog vroeg in de ochtend is), en de deur gaat weer dicht. Maar soms, heel soms, moet ik een handtekening zetten. En ik heb nog steeds niet uit kunnen vinden wanneer dat nou wel of niet moet.

Eerst dacht ik vroeger: het moet voor hele belangrijke, zakelijke pakketten. En brieven, want soms moest ik ook een handtekening zetten voor een brief die makkelijk door de brievenbus had gekund. (Al moet ik toegeven dat onze brievenbus ietwat zwaar is om open te duwen.) De postbode zei dan &#8220;een pakket voor de heer < een hoop initialen >&#8221;, en dat deed het lijken alsof er iets superbelangrijks voor mijn vader was binnengekomen. Maar uiteindelijk bleken dat vaak ook gewoon tijdschriften te zijn, of simpelweg een (persoonlijke) brief die voor de familie bestemd was.

<!--more-->

Dus de tweede gedachte was: je moet tekenen voor pakketjes uit het buitenland! Want, daar kan een hoop mis gaan, en er komen vaak veel extra kosten bij voor het transport en de douane, dus men moet zeker zijn dat die op de juiste plek bij de juiste persoon is aangekomen. Nope, de meeste pakketjes waarvoor ik heb getekend kwamen gewoon uit de Benelux. En als ze uit een ver, ver land kwamen moest ik niet eens altijd tekenen, alleen maar als er dus (belachelijk hoge) douanekosten aan vast zaten. (In dat geval, echter, was de handtekening niet voldoende en moest iemand die kosten ook nog eens gaan betalen. Raar.)

En nu weet ik het niet meer. Wat mij, echter, nóg meer verbaasd is het daadwerkelijke handtekening zetten. Je zou denken &#8220;nou als ze een handtekening verwachten, dan zou het wel officieel zijn en goed moeten&#8221;. Je denkt dat je een contract krijgt, met zegel van de koning, met gouden rand, en dat je dan met zwarte vulpen perfect op het onderste lijntje je handtekening moet zetten. In werkelijkheid hebben ze een apparaatje met een half werkend touchscreen, de eerste de beste pen die ze konden vinden, en moet je er maar het beste van maken.

Ik heb denk ik nog nooit iets weten neer te zetten wat te identificeren is als mijn handtekening. Nooit. Inmiddels doe ik ook niet meer mijn handtekening, maar schrijf gewoon in blokletters mijn voornaam, zonder krulletjes of andere decoraties, dan valt er tenminste nog iets van te maken. Maar dan rest er nog één vraag: wat doen ze met die handtekeningen? Wat is het leven van de post-handtekening nadat die is gezet? Wat gebeurt er post handtekening? (Dit hele stuk moest leiden tot deze grap. Ik hoop dat je er van hebt genoten.)

Ik heb er nooit iets van gehoord, dus er zal wel niks mee gebeuren. Bij ons staat zelfs negentig procent van de tijd dezelfde postbode voor de deur (die zal er wel weer een vaste baan hebben), en die heeft mij ook al ongelofelijk vaak een andere handtekening zien zetten, dus niemand lijkt er om te geven. Maar toch, toch vind ik het leuk om me in te beelden dat PostNL gewoon al jarenlang, sluw en stiekem, een database op aan het bouwen is van alle Nederlanders. Dat over 5 jaar blijkt dat de regering ons allang op alle fronten surveilleert, controleert en nauwlettend in de gaten houdt. En als wordt gevraagd hoe ze dat hebben gedaan geven alle woordvoerders maar één antwoord: &#8220;de lust naar pakketjes heeft de Nederlanders getekend voor het leven&#8221;