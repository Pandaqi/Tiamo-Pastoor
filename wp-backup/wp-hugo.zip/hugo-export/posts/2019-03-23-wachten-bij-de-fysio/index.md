---
title: Wachten bij de fysio
author: hetisdepanda
type: post
date: 2019-03-23T16:00:55+00:00
url: /toverende-taal/aardige-anekdotes/wachten-bij-de-fysio/
categories:
  - Aardige Anekdotes
  - Gewoon een Gedachte

---
Vandaag moest ik naar de fysiotherapeut. Net zoals altijd was de hele wachtkamer leeg toen ik binnenkwam, waardoor ik plaats nam ergens middenin de stoelenrij en mijn eigen ding kon doen.

Totdat er nog iemand binnenkwam.

Volgens mij is het een ongeschreven regel dat &#8230;

<p style="padding-left: 30px;">
  <em>Als er vrije plekken zijn, ga dan niet precies naast die ene andere persoon zitten.</em>
</p>

Maar die regel had deze vrouw blijkbaar niet meegekregen. Ze keek in het rond, leek een stoel in de andere hoek te kiezen, maar liep toen alsnog door om pontificaal naast mij te gaan zitten. Ik moest zelfs mijn benen een beetje intrekken (en mijn rugtas onder de stoel schuiven) om plaats te maken.

Tja, daar zaten we dan. Twee vreemdelingen die geen intentie hadden om met elkaar te kletsen, maar wel dermate dicht op elkaar zaten dat je bijna dacht dat de een de moeder was en de ander de zoon.

Om het nog erger te maken was ik een banaan aan het eten, wat op de lijst &#8220;charmant fruit om te eten&#8221; niet heel hoog staat. Om de spanning te breken, stond ik op om mijn bananenschil weg te gooien. Wat denk je? Zij stond precies tegelijkertijd op om een bakje thee te maken.

Ik begon haast te denken dat ze een detective was, ingehuurd om mij nauwlettend in de gaten te houden. Als ze wat meer van mijn leeftijd was geweest, had het misschien nog een flirtpoging kunnen zijn.

<!--more-->

(Althans, dat is wat ik zou doen als ik een leuk iemand zag. Proberen om in onhandigheid een situatie te creëren waarbij je wel met elkaar _moet_ gaan praten. Tot nog toe levert dat eigenlijk weinig succes op. Misschien is een fysiotherapiepraktijk ook niet de juiste plek om liefde te zoeken. Ik bedoel, bij de tandarts kun je tenminste nog met heel veel cliché oneliners komen over bijvoorbeeld een &#8220;feestje in je mond&#8221;. Maar bij de fysio? &#8220;Zo, ik zie dat jij ook scheve schouders hebt. Wil je een keer met mij &#8230; oefeningen doen om dit serieuze probleem te verhelpen?&#8221;)

Om de spanning opnieuw te breken, deed ik maar wat iedereen doet op zo&#8217;n moment: een exorbitante interesse tonen in de reclamefolders die verspreid liggen over de wachtruimte. (Zelfs het woord exorbitant voelt een beetje exorbitant.)

Zo&#8217;n beetje alle flyers en posters waren van andere hulpverleners. De een maakte reclame voor zijn &#8220;professionele en persoonlijke&#8221; begeleiding bij yoga, wat ik altijd raar vind. Welke hulpverlener is niet persoonlijk? Alsof je met z&#8217;n twintigen tegelijk naar de tandarts gaat en dat hij dan een groepsbehandeling geeft. Of alsof hij zegt: &#8220;deze tandpasta werkte in het verleden goed voor meneer Janssen&#8221; &#8220;maar &#8230; ik ben niet meneer Janssen&#8221; &#8220;hé, het staat op de deur, ik ben géén persoonlijke tandarts!&#8221;

De ander heette &#8220;Zen Zijn Wij&#8221;, wat ik een gemiste kans vind. De overduidelijke woordgrap is om &#8220;zijn&#8221; te vervangen door &#8220;zen&#8221; => &#8220;Wij Zen Zen&#8221;. Als die persoon voor een alliteratie van de &#8220;Z&#8221; ging, is dat natuurlijk ook niet helemaal gelukt.

Ik begon me af te vragen of mensen deze folders hier zomaar konden neergooien. Zo ja, dan wilde ik ook best gratis reclame. Dan ga ik de volgende keer gewoon mijn eigen flyers bij de fysio leggen.

Zou er geen competitie zijn? Zou iemand niet weggelokt worden bij de fysio met aanbiedingen van yoga, acupunctuur en zenheid? (Zou er een wet zijn die het verbiedt om je eigen spullen daar neer te leggen?)

Ik begon de folders te tellen en kwam erachter dat veruit de meeste folders een aanbieding waren voor groepstherapie om te stoppen met roken. Dat sudderde mijn gemoederen. Het is niet alsof iemand denkt: &#8220;wacht eens even, als ik stop met roken, kom ik ook van mijn rugklachten af! Dagdag fysio!&#8221;

En toen was het ongemakkelijke moment eindelijk voorbij: de mysterieuze vrouw werd door haar hulpverlener geroepen.