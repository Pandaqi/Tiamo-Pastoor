---
title: Witte Oordopjes
author: hetisdepanda
type: post
date: 2016-10-07T10:34:55+00:00
url: /gewoon-een-gedachte/witte-oordopjes/
categories:
  - Gewoon een Gedachte

---
Als ik op de fiets zit doe ik vaak stemoefeningen. (Omdat het tijdens colleges volgens mij niet zo gewaardeerd zou worden als ik keihard oerwoudgeluiden ging maken.) Vroeger deed ik dat alleen als ik zeker wist dat er niemand in de buurt was, omdat ik natuurlijk niemand wilde lastigvallen. Nou gebeurde het wel eens dat er plots iemand met een hond uit een zijstraatje kwam wandelen en me heel raar aankeek, maar dat was de uitzondering op de regel.

De laatste tijd, echter, heb ik een bepaalde trend ontdekt die mij vrijwaart van elke schaamte. Naar schatting driekwart van de mensen die om me heen fietsen, hebben oordopjes in of een koptelefoon op. Regelmatig hoor je het geluid zelfs tientallen meters verderop, en als zo&#8217;n ding zo hard staat, dan zullen ze zeker geen last hebben van mijn stemoefeningen. Zo gebeurt het dus dat ik regelmatig de hele fietstocht achter iemand fiets en lawaai maak, en die ander weet waarschijnlijk niet eens dat er andere mensen om hem heen hebben gefietst.

<!--more-->

Hierbij heb ik het natuurlijk wel aan Apple te danken dat zo&#8217;n beetje alle oordopjes inmiddels wit zijn, en je dus vrijwel direct kunt herkennen of iemand ze in heeft of niet. Vroeger was dat soms erg lastig. Dan stond ik voor een stoplicht te wachten, en begon ineens achter mij iemand keihard te praten over zijn hond of dat geweldige feest gisteren. Later bleek dan dat ze belden met een vriend(in) en in hun oordopjes aan het praten waren, maar ik schrok me in eerste instantie vaak de pleures. Hebben ze het tegen mij? Welk feest? Welke hond? Waarom praat diegene tegen mij? IK WEET HET NIET.

De opkomst van de witte oordopjes is natuurlijk heel erg fijn, maar het baart me ook zorgen. Als het overgrote deel van de fietsers niet eens kan horen als iemand een paar meter achter ze hard staat te neuriën of zingen, zullen ze zeker geen ander verkeer aan horen komen. Ze zullen zeker niet horen wanneer iemand hulp nodig heeft, of de politie of ambulance er dringend langs moet, of dat iemand (zonder bel) er langs wil.

Mensen moeten vooral doen wat ze zelf willen, en ik denk zeker niet dat we ooit muziek in het verkeer moeten verbieden, maar die mensen moeten wel bij zichzelf gaan nadenken wat de risico&#8217;s en gevolgen zijn. Het is niet alleen een gevaar voor henzelf, maar des te meer voor de anderen om ze heen.