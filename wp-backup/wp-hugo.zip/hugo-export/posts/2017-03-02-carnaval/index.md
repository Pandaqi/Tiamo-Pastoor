---
title: Carnaval
author: hetisdepanda
type: post
date: 2017-03-02T19:24:51+00:00
url: /gewoon-een-gedachte/carnaval/
categories:
  - Gewoon een Gedachte

---
Ik heb lang gezocht naar een objectief argument _tegen_ Carnaval. Want ik heb er best wel een hekel aan gekregen over de jaren, maar niemand lijkt dat te begrijpen. Ik woon in Brabant, en daar is Carnaval best wel een dingetje.&nbsp;En dan kan ik wel zeggen &#8220;het slaat nergens op&#8221;, of &#8220;je viert niks&#8221;, of &#8220;al die kostuums en prullaria kosten erg veel geld&#8221; — maar dat is mijn mening.

Voor anderen slaat Carnaval namelijk wel degelijk ergens op. Het is hun moment om alle stress kwijt te raken en helemaal los te gaan. Anderen&nbsp;vieren misschien dat ze vakantie hebben, of dat ze lekker gek kunnen doen samen met vrienden. En&nbsp;voor anderen kost het allemaal misschien helemaal niet veel geld, of&nbsp;hebben ze dat er&nbsp;makkelijk voor over.

<!--more-->

Om dan nog niet te spreken over de muziek. Het is luid, het is repetitief, het is slecht gezongen en niet origineel, maar mijn god wat blijft het in je hoofd hangen. Ik doe niks met Carnaval, en kom er niet mee in aanraking, ware het niet dat de optocht&nbsp;standaard elk jaar voor onze deur langs komt. En desondanks mijn complete desinteresse zit ik de rest van de week te neuriën over&nbsp;bloemetjesgordijnen en paarden in mijn gang.

Maar goed, dit is dus allemaal mijn mening en smaak, en ik heb er nog nooit iemand mee kunnen overtuigen dat&nbsp;Carnaval prut is en dat het écht niks voor mij is. De enige manier waarop ik kan ontkomen aan eventuele uitnodigingen voor Carnavals-festiviteiten is door er gewoon niet over te beginnen, en één a twee weken voor aanvang niet meer in de buurt van Carnaval-fanatiekelingen te komen.

Maar&nbsp;toen ik een paar dagen geleden&nbsp;over straat liep vond ik wel degelijk een objectief argument.

> Carnaval is slecht voor het milieu en omgeving

Overal op straat&nbsp;lag rommel,&nbsp;de bosjes zagen rood-wit-blauw van de confetti, over alle muren en ramen (ook onze ramen) was van dat kleverige, plakkerige spul gespoten. Kortom, het was een grote rotzooi. De dagen daarna was het niet veel beter, want al die rotzooi wordt niet bepaald biologisch afgebroken, kan nergens heen, en&nbsp;het wordt al helemaal niet schoongemaakt. Sterker nog, een paar jaar geleden was een ruitje bij ons ingegooid met van die rotzooi tijdens Carnaval, en niemand heeft daar ooit iets om gegeven.

En het is niet dat Carnaval de nummer 1 boosdoener is qua milieu. Vuurwerk,&nbsp;bijvoorbeeld, is misschien even erg, evenals plastic tasjes. Maar het heeft ook te maken met de&nbsp;_instelling_ van mensen tijdens Carnaval. Niemand is respectlozer,&nbsp;grover, uitbundiger,&nbsp;misschien zelfs dommer, dan met Carnaval. Natuurlijk zijn er vriendelijke mensen die ook tijdens dit&nbsp;feest zich koest houden, maar dat is&nbsp;een klein aandeel en niet de harde kern.

Terugkomend op dat ingegooide ruitje: tijdens de&nbsp;optocht gaat men ook altijd gewoon tegen onze ramen aanhangen, en zet allerlei spullen en voertuigen op onze oprit, en tot diep in de nacht lopen ze schreeuwend over straat (waardoor het hele huis wakker schrikt). Mensen vinden dat ze alles mogen maken, want ze gaan er van uit dat alle andere mensen ook in die &#8220;losse&#8221; stemming zijn. Sterker nog, ze vinden dat je mee moet feesten, zelfs als je herhaaldelijk aangeeft dat&nbsp;je er niet voor in de stemming bent of gewoon probeert boodschappen te doen.

Het enthousiasme is leuk, en ik ben jaloers op mensen die zich&nbsp;zo zorgeloos (en vaak out-of-character) kunnen gedragen een paar dagen, maar Carnaval heeft zichzelf een beetje overstegen. Het is niet meer het romantische, grappige gemaskerd bal feest, het is het zuipen en&nbsp;gek doen tot je er bij neer valt feest. En&nbsp;los van mijn mening over het feest, mag men best de troep opruimen en respectvol met mens en natuur om blijven gaan.