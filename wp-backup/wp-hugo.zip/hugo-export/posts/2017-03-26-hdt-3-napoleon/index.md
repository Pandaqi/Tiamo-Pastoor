---
title: '[HdT] #3 Napoleon'
author: hetisdepanda
type: post
date: 2017-03-26T15:00:12+00:00
url: /visuele-fratsen/hdt-3-napoleon/
categories:
  - Crappy Cartoons
  - Visuele Fratsen

---
<img decoding="async" src="http://res.cloudinary.com/nietdathetuitmaakt/image/upload/v1493117346/Henk-de-Tijdreiziger-_3.jpg" />