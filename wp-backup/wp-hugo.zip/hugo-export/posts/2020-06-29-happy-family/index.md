---
title: Happy Family
author: hetisdepanda
type: post
date: 2020-06-29T21:57:43+00:00
url: /toverende-taal/aardige-anekdotes/happy-family/
categories:
  - Aardige Anekdotes

---
Ik ben een groot fan van de band Racoon, altijd al geweest.

Toen zij doorbraken was ik precies op die leeftijd dat je jouw eigen muzieksmaak gaat ontdekken en ontwikkelen, en na een prachtige voorstelling van hen was ik verkocht.

(Na afloop van die voorstelling zeiden ze heel droog &#8220;ja, eh, we zijn dus bezig met een nieuw album, zouden jullie het leuk vinden om daar een liedje van te horen? Weten we meteen of het wat is.&#8221; Die hele zaal natuurlijk joelen, schreeuwen, &#8220;we want more!&#8221;, hartstikke enthousiast.

Welk nummer was dat? _Close Your Eyes_. Megahit geworden, misschien ook wel het beste nummer van die hele avond. Voelt toch alsof je één van de eersten was die het hoorde. En daarna werden ze te groot om nog in (kleine) theaters op te treden 🙁 )

Hoe dan ook, wij hadden in onze auto een _casettebandje_ waarop mijn zus, met pijn en moeite, het album van Racoon had gezet.

Eén van de meest geliefde nummers was _Happy Family_. Misschien omdat we zelf een groot gezin waren, misschien omdat het gewoon een leuk en goed nummer is, ik weet niet precies waarom. Maar we luisterden dat nummer disproportioneel vaak.

Waarom vertel ik dit?

Nou, aan het einde van het refrein zingt hij &#8220;_the kind of money that you make&#8221;_

Mijn gezin en ik, een stel jonge kinderen die maar een _piepklein_ beetje Engels konden, hadden hier een _hele andere betekenis_ aan gegeven.

Wij dachten dat het een filosofisch vraagstuk was, iets waar elke volwassene mee worstelde, iets wat wij nog wel zouden meemaken:

<p style="padding-left: 30px;">
  &#8220;Wil je <em>kinderen</em> of wil je <em>geld</em>?&#8221;
</p>

<!--more-->

Blijkbaar kon je ze niet allebei hebben :p Poeh, wat een ethisch verantwoord nummer is die _Happy Family_ toch. Ik herinner me vaag discussies die losbarstten over iedereens keuze:

<p style="padding-left: 30px;">
  &#8220;Ja, nee, ik zou denk ik wel voor kinderen kiezen. Ik bedoel, kinderen zijn schattig.&#8221;
</p>

<p style="padding-left: 30px;">
  &#8220;Nou ja, geld is ook belangrijk. Zonder geld heb je geen eten. En geen huis enzo.&#8221;
</p>

<p style="padding-left: 30px;">
  &#8220;Kan je niet gewoon kinderen<em> én</em> geld?&#8221;
</p>

<p style="padding-left: 30px;">
  &#8220;NEE! Dat kan niet. De wijze Racoon heeft gesproken!&#8221;
</p>

Nu ik dat nummer toevallig weer luister, tien jaar later, voelt het allemaal zo onschuldig (en een beetje dom). Hij zingt gewoon over dat zoveel gelukkige gezinnen uit elkaar vallen omdat men alleen maar geeft om hoeveel geld je verdient.

Nee, wacht, laten we het erop houden dat wij gewoon al twee stappen verder waren en nadachten over het eeuwenoude dilemma: &#8220;kinderen óf geld?&#8221;

(Desalniettemin, hoe Racoon zoveel catchy en mooie nummers heeft geschreven die tegelijkertijd over diepe thema&#8217;s gaan, vind ik nog steeds best knap.)

Ik vraag me af of de kinderen van vandaag hetzelfde denken.

Ze horen het nummer &#8220;Love Game&#8221; van _Lady Gaga_ en denken dat ze met _disco stick_ een of ander speelgoed bedoelt wat je blijkbaar nodig hebt als je gaat discodansen. (Wat &#8211; eh &#8211; totaal niet mijn gedachte was toen ik dit nummer steeds op de radio hoorde.)

Ze horen het nummer &#8220;CD van jou, CD van mij&#8221; van _Acda en de Munnik_ en denken dat het gaat over één of andere louche handel in gestolen cd-roms.

Ze horen het nummer &#8220;Nachtmuziek&#8221; van diezelfde _Acda en de Munnik_ en vragen zich af: &#8220;Vinden die buren dat niet vervelend? Als ze &#8217;s nachts keihard piano gaan lopen spelen?&#8221;

Ze horen het nummer &#8220;Close Your Eyes&#8221; en doen dan allemaal snel hun ogen dicht omdat ze denken dat ze écht iets _beautifuls_ gaan zien, in plaats van gewoon zwart.

(Ik heb wel het idee dat deze voorbeelden mij een beetje dateren. Ik heb geen idee wat inmiddels hippe popmuziek is, dit is allemaal van meer dan vijf tot tien jaar geleden kom ik nu achter :p Dus ik dacht: laat ik eens kijken in de Top 40. Maar het eerste nummer heette Banana Banana, en toen liet ik het maar zitten.)

Goed, dit was weer een leuke anekdote. Nu moet ik gaan slapen want ik heb morgenochtend een tentamen.

&nbsp;