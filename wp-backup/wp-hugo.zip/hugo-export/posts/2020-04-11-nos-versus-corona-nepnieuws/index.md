---
title: NOS versus Corona Nepnieuws
author: hetisdepanda
type: post
date: 2020-04-11T13:20:25+00:00
url: /toverende-taal/aardige-anekdotes/nos-versus-corona-nepnieuws/
categories:
  - Aardige Anekdotes
  - Gewoon een Gedachte

---
Een tijdje geleden schreef ik een kort artikel over hoe ik eigenlijk altijd moet lachen als ik de website van de NOS bekijk: [NOS &#8211; De onbedoelde stand-up comedian][1]

Vandaag moest ik daar weer aan denken toen ik dit artikel las: <https://nos.nl/artikel/2330124-ook-brand-bij-zendmasten-in-veldhoven.html>

Wat is het verhaal? Er gaat een wilde theorie in de rondte dat het aankomende 5G-netwerk zou bijdragen aan de verspreiding van het coronavirus. Complete onzin natuurlijk, zoals iedereen met een klein beetje verstand van technologie of biologie weet. (Of iedereen met een klein beetje hersenen.)

Tenzij deze mensen het natuurlijk op een soort metaforische manier bedoelen: doordat de wereld steeds beter en sneller met elkaar wordt verbonden, komen mensen steeds dichter bij elkaar, en _dat_ zorgt nou juist voor de verspreiding van het virus!

Maar het lijkt me sterk dat de mensen die deze theorie aanhangen weten wat een metafoor is. In plaats daarvan zijn ze echte zendmasten in brand aan het steken, die bijvoorbeeld nodig zijn om de hulpdiensten (112) bereikbaar te houden.

Tot zover vooral treurig nieuws, maar dan komt de paragraaf waarmee ze het artikel afsluiten:

<p class="text_3v_J6Y0G" style="padding-left: 30px;">
  <em>Ook in het Verenigd Koninkrijk zijn masten in brand gestoken en op andere manieren aangevallen. Er lijkt daar een verband te zijn met theorieën dat 5G zou bijdragen aan de verspreiding van het coronavirus. Experts spreken die theorieën overigens nadrukkelijk tegen.</em>
</p>

<p class="text_3v_J6Y0G" style="padding-left: 30px;">
  <em>Het 5G-netwerk wordt de komende jaren in Nederland ingevoerd. <strong>Of er ook hier een link is tussen de branden en dergelijke kritiek is onduidelijk, hoewel er bij de zendmast in Deurne wel &#8220;Fuck 5G&#8221; op een muur was gesprayd.</strong></em>
</p>

Hmm. Ik weet het niet hoor, of deze branden te maken hebben met de kritiek op het 5G-netwerk. Poeh, waar zouden we nu bewijs kunnen vinden dat zoiets sterk suggereert. Misschien de omgeving maar eens checken op bepaalde uitlatingen over het 5G-netwerk, zou iets kunnen opleveren.

Tot zover de NOS, die altijd — maar dan ook echt _altijd_ — probeert genuanceerd en professioneel te blijven, wat het vooral heel grappig maakt.

 [1]: http://nietdathetuitmaakt.nl/aardige-anekdotes/nos-de-onbedoelde-standup-comedian/