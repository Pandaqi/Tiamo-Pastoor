---
title: Studentenservice
author: hetisdepanda
type: post
date: 2017-09-03T18:29:05+00:00
url: /toverende-taal/aardige-anekdotes/studentenservice/
categories:
  - Aardige Anekdotes

---
Ik heb aan het begin van mijn studie vaak met mijn laptop aan een wiebeltafel gezeten. Dat is een tafel die bij de minste of geringste beweging heen en weer beweegt, en dat vinden laptops niet fijn. Halverwege mijn tweede studiejaar begon mijn scherm dan ook steeds losser te zitten, en, op een slechte dag, uit te vallen. Ik kon het nog wel fiksen door het scherm weer goed vast te drukken, maar na een paar uur kwamen dan toch een hoop felgekleurde strepen door mijn scherm. En dat leest toch minder makkelijk.

Op de een of andere manier heb ik het anderhalf jaar volgehouden met dit gebrekkige scherm, maar toen hij om de tien minuten uitviel moest ik er aan geloven. Ik moest langs de (notebook) servicebalie op de universiteit.

<!--more-->

Bij het inleveren kwam het eerste probleem aan bod. Ik had stiekem, eigenlijk, alleen verzekering als ik de laptop in mijn universiteitstas had zitten. Die had ik gratis bij de laptop gekregen, maar iedereen weet: alles wat je gratis krijgt werkt niet. De universiteitstas is niet waterdicht. Een laptop daar in stoppen terwijl je door het Nederlandse weer moet fietsen is niet verstandig. Dus ik draag altijd een andere, stevigere, betere tas bij, en daar deden ze moeilijk over. Gelukkig besloten ze hem alsnog te repareren, omdat ze zagen dat ik verder goed voor de laptop had gezorgd. (En, hopelijk, omdat ze zagen dat ik geen gemene randdebiel was die misbruik wilde maken van de studentenservice.)

Een week later kwam ik de laptop ophalen. Ik wist dat de servicebalie sloot om 6 uur, dus ik kwam netjes rond half 6. Ik zeg dat ik een laptop uit reparatie wil ophalen, hij kijkt naar de klok en zegt &#8220;ik weet niet of ik dat nog ga doen&#8221; Ik zeg &#8220;ik kom hem _ophalen_ hé, niet _afleveren_.&#8221; Hij antwoordt &#8220;ja, dat weet ik, maar we gaan eigenlijk al sluiten.&#8221;

Ik sta stomverbaasd te kijken hoe hij binnen een minuut mijn laptop haalt, en voor mij openklapt, en laat zien dat het is gerepareerd. Ik check of ze niet bij het repareren andere dingen kapot hebben gemaakt. Daarmee ben ik na een minuut ook wel klaar. Hij is vervolgens vijf minuten bezig met formulieren invullen en de bevestiging van teruggave printen. In die tijd ziet hij nog een aantal keer kans om diep te zuchten, en voor mijn neus naar een andere medewerker te roepen dat hij het zo vervelend vindt dat iedereen zo laat nog komt. IK WAS ER EEN HALF UUR VAN TEVOREN. Je stapt ook niet om half 8 de Albert Heijn binnen (of is dat inmiddels half 9?), om vervolgens geen enkele medewerker meer te vinden, en geweigerd te worden als je probeert af te rekenen. (&#8220;Ja, eh, sorry meneer, technisch gezien zijn we nog open, maar praktisch gezien gaan we elke avond om 7 uur dicht. &#8220;)

Maar goed. Hij eindigt deze beschamende (voor hem dan) tentoonstelling door te zeggen dat ik blij moet zijn dat ik de laptop nog terug krijg, want ik heb weer niet de universiteitstas bij. HET REGENT. Zij zeggen dat ik een &#8220;regenkapje&#8221; heb gekregen bij mijn universiteitstas. Ja, dat weet ik, maar die bedekt alleen het bovenste stuk, en werkt niet zo vlekkeloos als zij denken. WAAROM IS DE TAS ZO BELANGRIJK?

Om kwart voor 6 zit ik in de bibliotheek mijn nieuwe, glimmende, prachtige scherm te bestuderen. En ik zit mezelf hard af te vragen waarom hij er zoveel problemen van maakte. Hij had daar toch tot 6 uur moeten zitten. Het maakt hem persoonlijk geen reet uit wat voor tas iemand heeft. Waarschijnlijk heeft hij zelf niet eens meer die pruttas. Waarom maakt hij er een probleem van als hij een half uur voor sluiting _zijn baan_ uit moet voeren? Hoe doen andere studenten dat dan? Ik volgde toevallig geen vakken, dus ik hoefde niet naar college en kon komen wanneer ik wilde. College eindigt pas om half 6, dus als studenten wél een normaal rooster hebben, kunnen ze sowieso pas vanaf half 6 komen.

Hoe dan ook, ik ben blij dat mijn laptop eindelijk is gerepareerd. Als het scherm goed werkt gaan dingen toch ineens een stuk makkelijker. Maar mijn ervaring met de studentenservice was erg frappant, en ik heb ook geen enkele zin om er ooit nog terug te komen. Aan de andere kant, ik kan hun frustratie wel begrijpen. Terwijl ik daar was zat iemand naast mij uit te leggen dat zijn hele laptop het ineens, uit het niets, niet meer deed. Pas halverwege het gesprek werd duidelijk hoeveel cola er precies over het toetsenbord was geflikkerd, en hoeveel toetsen er misten. Hij had dan wel de universiteitstas bij zich, ik betwijfel dat het binnen de verzekering past.