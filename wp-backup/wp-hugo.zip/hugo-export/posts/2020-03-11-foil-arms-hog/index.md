---
title: 'Foil, Arms & Hog'
author: hetisdepanda
type: post
date: 2020-03-11T13:38:06+00:00
url: /gewoon-een-gedachte/foil-arms-hog/
categories:
  - Gewoon een Gedachte

---
Dit is mijn allereerste artikel in de reeks &#8220;projecten die niet de aandacht krijgen die ze verdienen&#8221;. (Ik moet nog een meer _catchy_ naam verzinnen.)

In deze reeks wil ik projecten (of mensen/organisaties) onder de aandacht brengen die in mijn ogen té goed zijn om onder de radar te blijven.

Deze keer wil ik de aandacht brengen naar het Ierse comedy trio **Foil, Arms & Hog**.

Hun meest bekende video (die enkele jaren geleden soort-van viraal ging) is deze over een potje Risk:

<span class="embed-youtube" style="text-align:center; display: block;"></span>

<!--more-->

Dit is natuurlijk niet het enige wat ze ooit hebben gemaakt. Ze hebben al _tien jaar lang_ een YouTube-kanaal waarop ze bijna elke donderdag een nieuw sketch plaatsen. De sketches zelf zijn supergoed, het camerawerk is professioneel, er zit zelfs handmatig ingevoerde ondertiteling bij vrijwel alle video&#8217;s &#8211; en dat allemaal gratis op YouTube!

Alle drie de komedianten zijn ook nog eens individueel heel sterk. Ze kunnen acteren, stemmetjes opzetten, verrassend goed zingen en muziek maken, en vooral heel goed een grap volledig overbrengen. (Voor als je het nog niet doorhad: elk woord uit hun naam slaat natuurlijk op één van hen.)

Ik vind het ongelofelijk knap dat ze dit überhaupt al jarenlang constant voor elkaar krijgen. Dat alles rondom de video&#8217;s ook nog eens van professionele kwaliteit is, en dat ze het allemaal gratis online zetten, is wonderbaarlijk.

Ze zouden véél populairder moeten zijn. Ik denk dat hun kanaal voor vrijwel iedereen wel een hoop leuke sketches bevat. (En, voor zover ik kan zien, worden ze alleen maar beter en beter.)

Dus bij deze: **abbonneer je op Foil, Arms & Hog** en steun hen 🙂

Je vraagt je misschien af: _maar, hoe verdienen ze geld dan?_ Nou, ze touren dus gewoon de hele wereld over met hun live shows. Dat maakt het nog knapper: die hele YouTube handel doen ze in hun vrije tijd, in hotelkamers en in de korte periodes tussen shows/tours. En, eens in de zoveel tijd, plaatsen ze een (professionele) opname van hun live show in plaats van een sketch. Dat zijn vaak de beste 🙂

Overigens vind ik hun naam + logo ook gewoon heel leuk. Het heeft iets &#8230; solide en klassieks, alsof hun group driehonderd jaar geleden is opgericht, en inmiddels nog steeds bestaat en de grootste ter wereld is. En tegelijkertijd is het gewoon een grappige en memorabele naam.