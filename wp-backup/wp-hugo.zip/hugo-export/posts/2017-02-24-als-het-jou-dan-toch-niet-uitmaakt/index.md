---
title: Als het jou dan toch niet uitmaakt
author: hetisdepanda
type: post
date: 2017-02-24T15:00:42+00:00
url: /toverende-taal/genezende-gedichten/als-het-jou-dan-toch-niet-uitmaakt/
categories:
  - Genezende Gedichten

---
Als het jou dan toch niet uitmaakt  
Ga ik liever naar de zee  
Langs rivieren, hoge duinen  
Neemt het zand de zorgen mee

Als het jou dan toch niets doet  
Ga ik liever naar de zon  
Lange dagen, zachte windvlagen  
Dingen doen die je nooit eerder kon

Als het jou toch om het even is  
Lig ik liever in het gras  
Blauwe luchten, diepe zuchten  
Lange verhalen over wat komt en al was

Als jij dan toch de passie kwijt bent  
Lig ik liever lang naast jou  
Een zeldzaam lied, een klein verdriet  
Omdat ik eeuwig van je hou

Als er voor jou toch niets in het leven is  
Sleur ik je liever altijd mee  
Gedachten houden je niet meer tegen  
Alles weggedragen door de zee