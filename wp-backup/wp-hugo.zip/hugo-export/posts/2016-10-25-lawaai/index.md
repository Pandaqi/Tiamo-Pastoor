---
title: Lawaai
author: hetisdepanda
type: post
date: 2016-10-25T15:00:43+00:00
url: /gewoon-een-gedachte/lawaai/
categories:
  - Gewoon een Gedachte

---
Ik ben erg sensitief voor geluid. Althans, dat dacht ik altijd. Toen ik zo&#8217;n zeven jaar was, reageerde ik vaak niet op dingen die mijn ouders tegen me zeiden. Ze dachten dat er iets mis was met mijn oren, maar meerdere tests bij de KNO-arts wezen uit dat er toch echt helemaal niks mis was met mijn gehoor. Mijn ouders stonden voor een raadsel, maar dachten toen maar dat ik gewoon eigenwijs was en niet naar ze luisterde.

In werkelijkheid, bedacht ik me later, hoorde ik juist veel te veel. Als iemand die naast me stond iets tegen me zei, hoorde ik ondertussen in de verte een auto rijden, bij de buren iemand zingen, en ergens anders een nerveuze vlieg rondzoemen. Pas als iemand al een paar seconden aan het praten was had ik door dat ik me op diegene moest gaan focussen, maar, tegen die tijd waren ze al klaar en moest ik steeds vragen &#8220;wat zei je?&#8221;

<!--more-->

Deze gevoeligheid is nooit echt weggegaan, en vaak valt hij ook niet eens op, maar eens in de zoveel tijd komt het weer terug. Dan ben ik misschien in een wat drukkere ruimte, of iemand praat (onnodig) _veel_ te hard, en ik kan me gewoon niet op het geluid concentreren. Aan de andere kant, echter, kan ik geluiden niet uitsluiten. Als twee mensen in de kamer naast me aan het praten zijn, kan ik me niet afsluiten voor dat gesprek en _expres niet horen _wat ze zeggen. Het kan gewoon niet. Het geluid komt te hard binnen.

En dan denk je misschien dat zo&#8217;n &#8220;gave&#8221; erg handig is. Ik kan immers geluid van ver alsnog goed meekrijgen, en ik mis nooit geluiden. Maar het maakt je ook helemaal gek. Op school in de klas waren mensen vaak door elkaar heen aan het praten, maar dat was op een acceptabel volume, dus werd het &#8220;achtergrond-ruis&#8221; en kon ik me makkelijk op werk of mijn eigen gesprekspartner focussen.

Thuis, echter, vond iedereen het altijd nodig om alles veel te hard te doen. Ze praatten te hard, maakten onverwachts keihard irritante geluiden, als ze een kastje opendeden klonk het alsof de geheime politie een inval deed. Dingen werden niet neergezet, maar keihard op de tafel of de grond gesmeten. Series en films werden niet gewoon gekeken, ze veranderden meteen de hele buurt in een bioscoop. (Wel een prutbioscoop trouwens, want je kunt alleen het geluid horen en mag niet kiezen van welke film.)

Het gevolg hiervan is dat ik na veel lange levensjaren het _verleerd _ben om diep na te denken, of me ergens op te focussen. Ik probeer vaak echt wel aan school of andere dingen te werken, maar de constante stroom van onnodige herrie zorgt dat ik elke vijf minuten er niet meer tegen kan en maar naar buiten ga, of zelf muziek ga maken, of ga sporten &#8211; in ieder geval langdurige pauze nemen. Erger nog, elke keer dat ik lawaai hoor schiet mijn hele lijf, en vooral mijn nek en oren, in de stress.

Ik zou willen dat ik er meer aan gedaan had, ik zou willen dat ik eerder en beter had geleerd geluiden uit te sluiten, want nu zit ik met de gebakken peren. Ik kan niet meer langdurig nadenken, en heb constante stress in mijn lichaam. En het zal lang duren voordat ik dat er uit krijg. Mocht jij hetzelfde voelen, doe er dan wat aan, je zult jezelf later veelvuldig bedanken 🙂 Krijg je eigen werkruimte, werk eventueel met koptelefoon of oordopjes in, en zorg dat er enigszins een regeling komt dat je huisgenoten (of, in extreme gevallen, buren) zich gedeisd houden.