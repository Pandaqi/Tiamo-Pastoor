---
title: De Wespen gaan Dood!
author: hetisdepanda
type: post
date: 2016-09-27T14:49:45+00:00
url: /gewoon-een-gedachte/de-wespen-gaan-dood/
categories:
  - Gewoon een Gedachte

---
Het is een titel die waarschijnlijk velen veel plezier zal opleveren, maar ik moet jullie teleurstellen: het lijkt erop dat alleen de wespen in mijn achtertuin doodgaan.

Al sinds begin van de lente, loop ik regelmatig van buiten naar binnen, en vind ik een wesp onder mijn schoen (of sok). Maar het zijn niet van die gigantische, angstaanjagende wespen &#8211; het zijn altijd kleine, verschrompelde wespjes. (Nee spellingchecker, dat is gewoon een Nederlands woord.)

<!--more-->

Dit leidt mij tot de volgende hypothese: _De wespen zijn ziek!_ Nou zou dit natuurlijk goed nieuws kunnen zijn, aangezien het minder wespen zou kunnen opleveren, wat op zijn beurt weer nog minder wespen oplevert, en ons uiteindelijk zou verlossen van de plaag die wespen zijn. (Want, wat is het nut van een wesp? Kan iemand ook maar één positief aspect van een wesp opnoemen? Spinnen, bijvoorbeeld, eten nog muggen en vliegen op voor ons. En bijen zorgen er voor dat de hele wereld lekker eten krijgt door bloemen te bestuiven. Maar wespen zijn gewoon steek-grage, nerveuze vliegen die een evolutie hebben ondergaan.)

Aan de andere kant, zieke muggen, bijvoorbeeld, vermoorden jaarlijks honderd-duizenden mensen. Malaria is een serieuze ziekte, en de westerse wereld weet niet hoe blij het moet zijn dat het hier geen issue is. Er zijn nog veel meer ziektes die insecten met zich meebrengen, waaraan ze zelf niet doodgaan, maar wij wel. Laten we hopen dat het deze keer anders is.

Toch, is het om deze reden dat ik een onverwacht credo ten gehore ga brengen: _Wees lief voor je medewesp!_ 

En als we dan toch bezig zijn, nog een veel belangrijkere uitspraak: _Wees nog veel liever voor je medebij!_ Waarom? Bekijk:_ _<a href="https://www.youtube.com/watch?v=GqA42M4RtxE" target="_blank" rel="noopener">The Death of the Bees</a>