---
title: Een perfecte 5/7
author: hetisdepanda
type: post
date: 2019-05-07T16:00:54+00:00
url: /toverende-taal/aardige-anekdotes/een-perfecte-5-7/
categories:
  - Aardige Anekdotes
  - Gewoon een Gedachte

---
De laatste tijd heb ik veel recensies gelezen van producten. Ik was op zoek naar betere muziekapparatuur (microfoons, speakers, statieven, etc.) en wilde natuurlijk weten wat andere gebruikers vonden.

Zeer regelmatig zag ik dat een product 4 sterren had. Ik dacht: _vier sterren, dus er iets is mis? Waarom geen vijf sterren?_

Met gezonde spanning las ik de recensies en zag tot mijn verbazing niets dan lofzang en enthousiasme.

  * &#8220;Niks op aan te merken; 4 sterren&#8221;
  * &#8220;Goede bouwkwaliteit; 4 sterren&#8221;
  * &#8220;Perfect voor al mijn opnames! 4 sterren&#8221;
  * &#8220;Ik hoef nooit meer een andere microfoon! 4 sterren&#8221;
  * &#8220;Vergeet al die andere statieven, deze heeft een perfecte prijs-kwaliteit verhouding. Ohja, 4 sterren.&#8221;

Ik snapte het niet. Wat moet er gebeuren om die vijfde ster erbij te krijgen?

  * &#8220;Nouja zeg, wat een verrassing: deze microfoon kan ook filmen! 5 sterren!&#8221;
  * &#8220;Ik had één statief besteld, maar tot mijn verbazing kreeg ik er drie! Zeker 5 sterren.&#8221;
  * &#8220;Na wat experimenteren kwam ik erachter dat als ik &#8216;_sesam open u!&#8217;_ in de microfoon schreeuw, mijn deur automatisch dicht gaat. Een solide 5 sterren.&#8221;
  * &#8220;Pff, ze hebben het weer voor elkaar gekregen hoor! Ik dacht gewoon speakers te hebben gekocht, kreeg ik er ook een babygeitje bij! Toch wel 5 sterren.&#8221;

Weet iemand waarom ze dat doen? Elke keer als ik nu een email krijg met &#8220;u heeft dit product gekocht &#8211; bent u er blij mee?&#8221;, staat de rating ernaast, en die is altijd 4 sterren. Voelt toch alsof ik de verkeerde dingen heb gekocht.

Tegelijkertijd heb ik nu het gevoel dat 5-ster producten oplichterij zijn. Als iets vijf sterren heeft, dan moeten het wel nepreviews zijn! Geen normaal weldenkend mens geeft iets 5 sterren!

Om deze anekdote af te sluiten wil ik een gerelateerde internetgrap delen. Een van de weinige grappen die ik om de een of andere reden elke keer weer hilarisch vond. Het plaatje hieronder is waar het allemaal mee begon:

<!--more--><figure class="wp-block-image size-full">

[<img decoding="async" loading="lazy" width="634" height="660" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/ndhu-5-7-1_result.webp" alt="" class="wp-image-10942" />][1]</figure> 

Vanaf dat moment begon iedereen alles wat &#8220;perfect&#8221; was een 5/7 rating te geven. Vijf was blijkbaar gelijk aan zeven :p (En dit was blijkbaar een normale schaal om ratings mee uit te voeren.)

Deze vond ik wel leuk:<figure class="wp-block-image size-full">

[<img decoding="async" loading="lazy" width="488" height="248" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/ndhu-5-7-2_result.webp" alt="" class="wp-image-10943" />][2]</figure> 

En deze:<figure class="wp-block-image size-full">

[<img decoding="async" loading="lazy" width="480" height="395" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/ndhu-5-7-3_result.webp" alt="" class="wp-image-10944" />][3]</figure> 

Deze mag je zeker niet vergeten:<figure class="wp-block-image size-full">

[<img decoding="async" loading="lazy" width="479" height="443" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/ndhu-5-7-4_result.webp" alt="" class="wp-image-10945" />][4]</figure> 

Er zijn mensen die zeggen dat het allemaal nep was, maar dat maakt het niet minder grappig. (Ik ben ook al een paar mensen tegengekomen die zo&#8217;n &#8220;ik geef het een 5/7&#8221; comment krijgen en denken: &#8220;waar sláát dit op?!&#8221; Ach, internetcultuur is soms een raadsel. Ik geef deze grap in ieder geval een perfecte 5/7.)

 [1]: https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/ndhu-5-7-1_result.webp
 [2]: https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/ndhu-5-7-2_result.webp
 [3]: https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/ndhu-5-7-3_result.webp
 [4]: https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/ndhu-5-7-4_result.webp