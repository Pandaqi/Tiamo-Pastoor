---
title: Aan alle mensen die…
author: hetisdepanda
type: post
date: 2016-10-06T15:00:25+00:00
url: /gewoon-een-gedachte/aan-alle-mensen-die/
categories:
  - Gewoon een Gedachte

---
&#8230;spullen op mijn bagagedrager achterlaten:

Ik vind het heel lief dat jullie me zomaar dingen geven, maar met de helft kan ik erg weinig. Een jasje is leuk, maar een foldertje voor een feest waar ik toch niet heen wil is vooral irritant. Geef me dan een zakje chips, heb ik lekkers te eten tijdens het fietsen. Of leg een usb-stick op mijn zadel, ook prima. Desnoods laat je alleen een briefje achter met een leuke grap, of quote, of naam en telefoonnummer. Ik weet zeker dat als je dat zou doen, een groot deel van de mensen een berichtje zou sturen naar het nummer, gewoon om te kijken wat er gebeurt. Als je er een spel van maakt, kun je zo best veel mensen leren kennen.

Het zijn maar gratis ideetjes, voor jullie, fiets-Sinterklazen.