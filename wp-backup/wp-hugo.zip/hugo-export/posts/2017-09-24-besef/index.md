---
title: Besef
author: hetisdepanda
type: post
date: 2017-09-24T16:00:52+00:00
url: /toverende-taal/genezende-gedichten/besef/
categories:
  - Genezende Gedichten

---
Met de dagen groeit het besef  
ik zal je nooit meer spreken  
al die dingen in je hoofd  
we zullen ze nooit weten

Al die dingen in je hoofd  
het waren er zoveel  
ik hoop dat het &#8217;t waard was

Of misschien toch niet  
want dan heb je een hele goede reden  
om gewoon terug te komen verdomme