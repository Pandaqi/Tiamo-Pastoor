---
title: Alicante
author: hetisdepanda
type: post
date: 2018-03-18T16:00:40+00:00
url: /toverende-taal/aardige-anekdotes/alicante/
categories:
  - Aardige Anekdotes

---
In een duister verleden, toen ik met mijn groepje vergaderde voor een project, vroeg ik een keer &#8220;dus, wat gaan we doen?&#8221;

Het antwoord daarop:

<p style="padding-left: 30px;">
  &#8220;Ja, we moeten alicante bekijken.&#8221;
</p>

Wat is alicante?! Het klonk bekend. Een of ander catchy deuntje kwam in me op, maar dat bleek &#8220;ale-alejandrooo&#8221; te zijn, niet &#8220;ali-alicanteeee&#8221;. Dat was vast niet wat ze bedoelden, maar ik had het idee dat de rest het wel begreep, dus ik voelde me dom en stelde geen vragen.

Even later overkwam mij hetzelfde fenomeen.

<p style="padding-left: 30px;">
  &#8220;Dus X en Y zijn de oplossing?&#8221;<br /> &#8220;Nou, we moeten wel alicante meenemen&#8221;
</p>

Wie is alicante!? Misschien was het wel een nieuwe Spaanse hype, net zoals toen iedereen ineens praatte over _despacito_. Ik gaf het op en raadpleegde Google. Alicante was een stad. Waarom zouden we een Spaanse stad in overweging nemen bij een project over kansberekening dat _alles _te maken had met Nederland?

Nog later kwam ik toevallig een verhaal tegen over Alicanto (met een -o op het eind), maar dat bleek een fabeldier. Als hij goud eet, straalt hij als de zon. Eet hij zilver, dan schittert hij als de maan. Best wel gaaf, maar heeft deze vogel die niet eens kan vliegen iets te maken met een wiskundige simulatie?

Totdat ik iemand sprak die wél kon articuleren.

<p style="padding-left: 30px;">
  &#8220;Het lijkt me verstandig om dit probleem van <em>alle kanten</em> te bekijken.&#8221;
</p>

&nbsp;