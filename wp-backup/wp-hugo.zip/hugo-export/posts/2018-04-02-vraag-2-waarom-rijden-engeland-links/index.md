---
title: 'Vraag: Waarom rijden ze in Engeland links?'
author: hetisdepanda
type: post
date: 2018-04-02T18:53:35+00:00
url: /gewoon-een-gedachte/vraag-2-waarom-rijden-engeland-links/
categories:
  - Gewoon een Gedachte

---
Het is de 5e eeuw. Soldaat Florius en Soldaat Engelbert kijken naar de horizon. Zoals de meeste mensen zijn zij rechtshandig, en zoals een goed soldaat betaamt hangen zij hun zwaard daarom aan hun linkerzij. Ze zijn verdwaald. Ergens zou een veldslag moeten plaatsvinden, maar ze liggen hopeloos uit de richting.

<p style="padding-left: 30px;">
  Florius: &#8220;Zeg Engelbert, hoor jij wat ik hoor?&#8221;<br /> Engelbert: &#8220;Nee?&#8221;<br /> Florius: &#8220;Daar, daar in de verte. Luister goed!&#8221;<br /> Engelbert: &#8220;Is dit weer een van jouw grapjes? Ik ga niet weer een hele dag rennen omdat je mijn zwaard hebt verstopt!&#8221;<br /> Florius: &#8220;Neen. Luistert. Dat is het geklets van zwaarden! Het gejengel van pijlen en bogen! Daar aan de horizon, daar vindt het gevecht plaats!&#8221;<br /> Engelbert: &#8220;Asjemenou! We moeten er zo snel mogelijk heen.&#8221;<br /> Florius: &#8220;Er is, echter, een probleempje. Als we nu vertrekken zijn we nooit op tijd &#8211; vóór zonsondergang &#8211; op het veld!&#8221;
</p>

Geheel toevallig renden op dat moment enkele paarden voorbij. Florius en Engelbert keken elkaar aan. Florius fronste, terwijl Engelbert een klein gloeilampje boven zijn hoofd kreeg.

<p style="padding-left: 30px;">
  Engelbert: &#8220;Het zou toch niet &#8230; &#8220;
</p>

<!--more-->

Engelbert sprong met wapperende armen voor een tweetal paarden, die geïrriteerd voor zijn neus stopten.

<p style="padding-left: 30px;">
  Paard 1: &#8220;Wa moede ge?&#8221;<br /> Engelbert: &#8220;Oh edel dier, zouden ik en mijn metgezel op uw rug mogen lopen?&#8221;<br /> Paard 2: &#8220;Lopen? Op mijn rug? Zulke barbaarse onzin hebben mijn oren nog nooit ontvangen!&#8221;<br /> Florius: &#8220;Neen, u ziet het verkeerd. U, met uw vier voeten, bent veel sneller dan wij met twee. Kunt u ons naar het gevecht brengen? Wij zullen u belonen met wortels, mandarijnen, een slechte tv serie van Studio 100, en Sinterklaasliedjes over paarden die op het dak lopen.&#8221;<br /> Paard 1: &#8220;Vooruit dan.&#8221;
</p>

Omdat beide heren rechtshandig waren, gingen ze links van het paard staan, en trokken zich met hun rechterhand omhoog. Een sierlijke zwaai later zaten ze op de rug van het paard. En zo werd Soldaat Florius de eerste Ridder Florius, en Engelbert evenzo. Ze voegden zich bij het gevecht, en voor ze het wisten hadden ze gewonnen, zonder ook maar een schrammetje. Nog jarenlang vertelde men de legendes van ridders Engelbert & Florius, en hoe zij als een stel lafaards op een paard gingen zitten en de rest vertrappelden. Wat een helden!

Deze uitvinding ging als een lopend vuurtje de wereld over, en overal verschenen ridders op de velden en de paden. Het was een chaos. Iedereen reed op elkaar in, en als je wilde afstappen stond je vaak ineens midden op de weg, waarna je door een ander paard werd geschept. Iemand schreeuwde iets over toeters installeren op elk paard, maar niemand begreep hem, en ze gooiden hem op de brandstapel.

Daarnaast was niet iedereen te vertrouwen, en moest je altijd klaar zijn om meteen je wapen te trekken en je tegenligger neer te knuppelen. (Tasjesdieven zijn van alle eeuwen! Hoewel het vroeger meer een soort buidel- of zakdieven waren. Dan chargeerden ze en probeerden met hun lans de tas van elkaars schouder te steken :p Dat is hoe het ging, sowieso.)

Er moesten regels komen!

Vanzelfsprekend besloot men om allemaal _links_ van de weg te gaan rijden. Zo konden ze aan de rand van de weg op- en afstappen, niemand reed op elkaar in, en gevaar werd snel onschadelijk gemaakt (zonder onschuldige omstanders te raken, die gewoon op hun zondagmiddag even lekker een gevecht tot de dood tussen twee ridders wilden aanschouwen).

Iedereen was blij. Eeuwenlang verplaatsten ridders zich door _links_ van de weg te rijden, en toen even later paard en wagen verschenen was er geen reden om dit te veranderen. Vandaag de dag rijden ze alleen nog maar links in alle Britse (ex)kolonies. Wat is er in vredesnaam gebeurd?

Napoleon, dat is er gebeurd.

Op een dag rende Napoleon zijn tent in, waar zijn militaire adviseurs al aan de thee zaten.

<p style="padding-left: 30px;">
  Napoleon: &#8220;Attention! Ik heb un strategie de geniale bedacht! Ik noem ut: <em>de croissant.</em>&#8221;<br /> Adviseur 1: &#8220;Laat mij u hier stoppun. Herinnert u zich nog de tragedie van 1791? Toen gebruikten we <em>de donut</em>, die u de dag van tevoren had bedacht, en verloren alle manschappen.&#8221;<br /> Napoleon: &#8220;Luistèr, sil vous plait, luistèr. Deze keer werkt ut wel! Is jullie iets opgevallen aan onze tegenstanders?&#8221;<br /> Adviseur 2: &#8220;Ze winnen steeds van ons?&#8221;<br /> Adviseur 3: &#8220;Ze hebben mooiere uniformen?&#8221;<br /> Adviseur 4: &#8220;Oh, oh, deze weet ik! Ze zijn vaak niet blij om ons te zien.&#8221;<br /> Napoleon: &#8220;Non! Stelletjuh domkoppèn! Ze rijden allemaal links. Ze chargeren eerst links, en dan pas rechts. Wat nou &#8230; als wij dat andersom doen! Hè? Hè? Hè? Who&#8217;s with me?&#8221;<br /> Adviseur 1: &#8220;Napoleon, de helft van de mannen kan nauwelijks links un rechts uit elkaar houden.&#8221;<br /> Napoleon: &#8220;Mooi, dan is dat besloten.&#8221;<br /> Adviseur 1: &#8220;Maar-&#8221;<br /> Adviseur 2: &#8220;Weet u zeker dat het niks te maken heeft met het feit dat u linkshandig bent?&#8221;<br /> Napoleon: &#8220;Oui &#8230; nouja, oké, misschien un beetje &#8230; maar daarom moeten is ut juist un idee bien. Ik kan snel mijn wapen pakken, en de tegenstander niet. Geniale!&#8221;
</p>

Napoleon had gelijk. Hij verwarde zijn tegenstanders met deze omgekeerde manier van rijden en aanvallen, en won veldslag na veldslag. Om te laten zien welke gebieden hij allemaal had veroverd, liet hij deze allemaal voortaan rechts rijden. Napoleon heeft veel veroverd, maar Engeland nooit.

Toen overal wagens ontstonden die door meerdere paarden werden getrokken, bleek het rechtsrijdsysteem nog handiger, en bleef het overal voortbestaan. (De bestuurder kon het beste op het paard linksachter zitten, wederom omdat de zweep in de rechterhand zat. Om dan zeker te weten dat jouw wagen niet in die van een ander blijft hangen, moesten mensen wel rechts van de weg rijden, anders kon je dat simpelweg niet goed zien.)

En zo geschiedde het.

<p style="padding-left: 30px;">