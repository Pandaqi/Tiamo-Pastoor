---
title: Woordenwissel
author: hetisdepanda
type: post
date: 2017-01-24T23:46:46+00:00
url: /gewoon-een-gedachte/woordenwissel/
categories:
  - Gewoon een Gedachte

---
Ik heb moeite met namen onthouden. Of, nouja, ik onthou namen wel, maar ik kan ze niet plaatsen bij de juiste mensen, of plak ze soms zelfs met volle overtuiging op de verkeerde mensen.

Ik kan een goede vriend per ongeluk aanspreken met de naam van mijn oom, en ik kan iemand die ik gisteren voor het eerst heb ontmoet aanspreken met de naam van mijn beste vriend. Per ongeluk, alhoewel het vaak niet eens wordt opgemerkt, omdat mensen toch niet luisteren als je een naam in een zin verwerkt. Bovendien staat een naam vaak aan het begin of eind van de zin (denk aan &#8220;Zeg Henk, wat heb je dit weekend gedaan?&#8221; of &#8220;Hoe is het met Truusje?&#8221;). En als je dan een beetje overtuigend spreekt, of de juiste persoon aankijkt, maakt het ze geen reet uit welke naam je zegt &#8211; ze weten toch wat je zegt en tegen wie je het hebt.<!--more-->

Veel lastiger wordt het als je andere woorden gaat verwisselen. Nee, geen letters verwisselen zoals mensen met dyslexie graag doen, maar hele woorden. En, puur bij toeval (of niet) vaak ook nog eens de belangrijkste woorden van de zin. (Ik heb het idee dat dit fenomeen het sterkst voorkomt bij extreem vermoeide en gestreste jongeren, maar dat kan ook aan mij liggen.)

Het werkt als volgt. Iemand zegt: &#8220;Zeg, heb jij je trui nog uit de droger gehaald?&#8221; Jij verstaat: &#8220;Zeg, heb jij de droger nog uit je trui gehaald?&#8221; Probleem.

Of iemand vraagt: &#8220;Zal ik mijn gitaar meenemen naar het dansen vanavond?&#8221; En jij hoort: &#8220;Zal ik mijn dansende gitaar meenemen vanavond?&#8221; Probleem, tenzij je poëtisch bent ingesteld en dit ziet als literair hoogstandje.

Maar het kan natuurlijk ook met geschreven teksten gebeuren. Er staat in de krant: &#8220;vannacht is een overval gepleegd op een hoekhuis in de Willekeurigelaan&#8221; Jij leest: &#8220;vannacht is een hoekhuis gepleegd op de overal aan de Willekeurigelaan&#8221;

En nu is dit allemaal nog niet zo erg, maar ik heb dat dus ook met veel belangrijkere dingen. Bijvoorbeeld, we krijgen een opdracht (om een of ander vak mee af te sluiten), waarin staat: &#8220;bepaal de geleidingscoëfficiënt die deze draad geeft&#8221;. Ik werk vervolgens twee weken aan een opdracht onder de impressie dat &#8220;bepaal hoe efficiënt deze draad leiding geeft&#8221; het einddoel was. Als niemand mij er op wijst kan ik dit zelf echt niet rechtzetten.

Om het nog erger te maken, stel ik krijg later een belangrijke, toonaangevende, hoogstaande baan. Men zegt tegen mij: &#8220;zeg, zou je voor maandag misschien dat rapport willen maken over mogelijke oplossingen voor ons probleem?&#8221; Ik ga dat weekend aan de slag met het bevel: &#8220;zeg, zou je misschien vóór maandag een probleem willen maken van een mogelijk rapport over oplossingen?&#8221; En als ik echt vermoeid ben, ga ik proberen een rapport op te lossen in water, en dan daar vervolgens maandag weer een groot probleem van zitten maken.

En daarom is studeren niks voor mij.

(Want, mensen met dyslexie krijgen tenminste verlenging bij tentamens, ik krijg met mijn gave hoogstens rare blikken en mensen die denken dat ik compleet gestoord ben.)

&nbsp;