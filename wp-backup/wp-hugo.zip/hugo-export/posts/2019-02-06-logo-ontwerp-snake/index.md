---
title: Logo Ontwerp (“Snake”)
author: hetisdepanda
type: post
date: 2019-02-06T16:00:39+00:00
url: /visuele-fratsen/logo-ontwerp-snake/
categories:
  - Visuele Fratsen

---
Vanochtend werd ik wakker met een urgente gedachte in mijn hoofd: &#8220;snake sine = logo&#8221;. Hoewel ik niet wist waar het vandaan kwam, vond ik dat mijn hoofd gelijk had en ik weer moest oefenen met logo&#8217;s ontwerpen. Dus ik zette een timer van een uur en schetste logo ideeën. Omdat ik al heel veel &#8220;speelse&#8221; of &#8220;losse&#8221; logo&#8217;s heb gemaakt, vond ik dat deze logo&#8217;s strak en modern moesten zijn. (Anders had ik weer een schattig slangetje getekend met veel kleuren.) Ook kreeg ik maar één kleur (zwart) en een klein beetje accentkleur (rood).

Hieronder staat het resultaat. (De grijze omlijning is om te laten zien waar een vierkant logo zou eindigen. Het is niet onderdeel van het logo.)

<img decoding="async" src="https://res.cloudinary.com/nietdathetuitmaakt/image/upload/v1549286706/Logo_Practice-Snake-01.png" /> 

Het eerste logo was op zich leuk, maar het bovenlichaam van de slang paste niet helemaal bij het onderlichaam. Het onderlichaam bestond namelijk uit perfecte &#8220;rounded rectangles&#8221;, terwijl ik het bovenlichaam uit de losse pols had getekend. Daardoor matchten de stijlen niet. Dat heb ik gefikst in het tweede logo.

**UPDATE:** Ik was zo dom om het hoofd (van de slang) geen ronde hoeken te geven. Dat is wederom inconsistent. Daarnaast ben ik niet tevreden over de representatie (en vooral lijndikte) van het slangenlichaam. Dus ik heb stiekem nóg een versie gemaakt nadat mijn uur voorbij was. (Blijkbaar heet een opgerolde slang in het Engels een &#8220;coiled snake&#8221;. Dat maakte referenties zoeken ietsje makkelijker.)

[<img decoding="async" loading="lazy" class="aligncenter size-full wp-image-8502" src="http://nietdathetuitmaakt.nl/wp-content/uploads/2019/02/Logo-Practice_Snake-Final.png" alt="" width="200" height="201" />][1]

<!--more-->

Veruit de meeste tijd ging zitten in het woord &#8220;SNAKE&#8221;. Ik vind het leuk om voor logo&#8217;s eigen letters te tekenen, in plaats van een standaardlettertype te downloaden en gebruiken, maar dat kost wel veel tijd. Ik ben wel trots op het resultaat 🙂 Misschien dat ik het ooit uitbouw tot een volwaardig &#8220;snake&#8221;-lettertype.

Het derde logo is de &#8220;kleine versie&#8221; van die andere. Deze zou je dan gebruiken op plekken waar je weinig ruimte hebt en alleen het logo héél klein wilt of kunt laten zien.

Bij de vierde versie wilde ik het tegenovergestelde proberen: een slang opbouwen uit perfecte ovalen. Op zich vind ik hem wel leuk, maar hij heeft nog veel aandacht nodig om echt goed te worden.

De laatste versie vind ik het schattigst en past ook het meest bij die woorden die in mijn hoofd opkwamen (&#8220;snake sine&#8221;). (Voor de niet-ingewijden: &#8220;sine&#8221; is Engels voor &#8220;sinus&#8221;, wat de naam is voor een golvende wiskundige formule.) Ik zou die gebruiken als het voor mijn eigen bedrijf/website/etc. was.

_Opmerking:_ het klinkt in mijn hoofd wel een beetje als een deel uit de Game of Thrones boekenreeks. &#8220;Game of Thrones: A Sign of Snakes!&#8221;

Zo, dat was de oefening voor vandaag.

 [1]: http://nietdathetuitmaakt.nl/wp-content/uploads/2019/02/Logo-Practice_Snake-Final.png