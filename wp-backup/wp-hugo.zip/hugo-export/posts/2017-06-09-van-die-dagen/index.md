---
title: Van die dagen
author: hetisdepanda
type: post
date: 2017-06-09T15:00:13+00:00
url: /toverende-taal/genezende-gedichten/van-die-dagen/
categories:
  - Genezende Gedichten

---
Sommige dagen voel ik me mislukt  
omdat ik veel minder taken heb volbracht  
dan mijn to-do lijstje bevatte

Sommige dagen is het een overwinning  
als ik voor het middaguur mijn bed uit rol  
en mijn pyjama verwissel voor kleren

Sommige dagen heb ik alle tijd  
maar verloopt alles en vervliegt het  
zonder dat ik iets bereik

Sommige dagen sta ik volgepland  
maar lijkt elke seconde, elke minuut  
toch tientallen keren trager te gaan

Je hebt van die dagen  
dat je wel wil  
maar dat je niet kan

Dat een onzichtbare kracht je terugtrekt  
en zegt &#8220;nu even niet,  
vandaag rusten we uit&#8221;

En ik twijfel, op van die dagen  
Of ik moet luisteren  
naar mijn gevoel  
of juist moet denken  
de beuk erin  
ik slaap wel als ik dood ben

Ik hou van die dagen  
waarin niks moet en alles mag  
Maar ik hou ook van die dagen  
waarin het spannend is, en alles gebeurt

Waren er maar meer van die dagen  
dat je rustig aan toch een hele boel beleeft  
Een utopia, misschien  
Iets waar niemand vat op heeft  
Ik wil niet sterven van de stress  
maar over mij zullen ze zeggen  
&#8220;die heeft ten volste geleefd&#8221;