---
title: Die kleine dingetjes
author: hetisdepanda
type: post
date: 2019-01-08T16:00:28+00:00
url: /toverende-taal/aardige-anekdotes/die-kleine-dingetjes/
categories:
  - Aardige Anekdotes
  - Gewoon een Gedachte

---
Aan het begin van mijn studie kon iedereen een laptop aanschaffen via de universiteit met maar liefst 50% korting. De enige voorwaarde was dat je drie jaar lang aan de universiteit verbonden bleef. Zoals je zou verwachten grepen bijna alle studenten deze aanbieding met beide handen aan!

De &#8220;ophaaldag&#8221; kwam, waarbij men niet alleen de laptop moest oppikken, maar ook hun boeken, (studenten)pasjes, etc. Er stond een _gigantische_ rij. De universiteit had slechts een handjevol mensen ingehuurd om alles in goede banen te leiden. Om het nog erger te maken waren dit gewoon studenten die niet veel ouder (of meer ervaren) waren dan wij. Al van ver zag je hen zweten en hoorde je de zuchten en kreunen.

<!--more-->

Natuurlijk mocht je niet zomaar binnenwandelen en een laptop meenemen. (Hoewel dat in deze chaos waarschijnlijk niet eens was opgevallen.) Je had identificatie nodig: een paspoort/identiteitskaart, studentenpas, en ondertekend contract.

_Iedereen_ voor mij was dit vergeten. Ze liepen naar de balie, zeiden &#8220;ik heb een laptop nodig!&#8221;, en waren verbaasd toen die zielige studentmedewerker vroeg &#8220;identificatie?&#8221; Vervolgens moesten ze hun tas openritsen, in hun portemonnee kijken, door hun collegeblokken rommelen, en zo de nodige materialen bij elkaar sparen. Dit kostte soms wel 5-10 minuten per persoon. Geen wonder dat de medewerkers er constant over klaagden.

Toen besloot ik iets aardigs te doen. Ik pakte alvast mijn spullen uit de tas en hield ze in mijn handen. Ik hield mijn pasjes met de juiste kant naar boven, het contract met het belangrijke deel zichtbaar. Toen ik aan de beurt was hoefde ik alleen mijn handen te laten zien en na tien seconden was het gepiept. Wat zei de medewerker? &#8220;God zij dank, eindelijk iemand die meewerkt.&#8221; Nou, als ik met zo&#8217;n kleine handeling iemand God kan laten bedanken, dan is dat het wel waard :p Ik zag zijn gezicht weer even opleven en zijn houding verbeteren. Hij was ook aardiger tegen mij dan tegen alle slachtoffers voor mij (ook al sprak ik hem zo kort).

Het zijn die kleine dingetjes die het verschil maken.

Voor de compleetheid nog een tweede anekdote. Eentje waarvan ik veel heb geleerd, maar me ook zeer schuldig over voel.

Een vriend van mij had een aantal honden. Deze honden werden heel goed verzorgd, kregen regelmatig nestjes, en haalden zelfs prijzen in competities. Op een avond liepen twee van de honden ineens weg. Dat was nog nooit gebeurd en hij was dan ook in alle staten. Eén van de honden werd vrij snel weer gevonden, maar de andere hond, een van de oudsten, kwam nergens opdagen.

Een paar uur later bleek deze hond te zijn aangereden en ter plekke overleden.

Al mijn vrienden zeiden heel snel &#8220;sterkte!&#8221;, &#8220;gecondoleerd!&#8221;, en nog meer mooie woorden (en emoticons) in de gezamenlijke chatgroep. Mijn eerste gevoel was: &#8220;daar heeft hij toch geen reet aan?&#8221; Ik ben van de daden, niet van de woorden. Maar ik wist niet wat ik wél moest doen. Een van mijn beste vrienden was ontroostbaar en ik raakte eigenlijk vooral in paniek.

Ik vroeg snel aan iemand anders — die niks van deze persoon of situatie wist — wat diegene in zo&#8217;n soortgelijke situatie zou doen. Het antwoord: &#8220;vraag of je iets voor hem kan _doen_, wees nuttig, bied jezelf aan&#8221;

Dus dat heb ik gevraagd. Een halfuurtje later kreeg ik een bericht dat ik een geweldige vriend was. Dat hij het stom vond dat de rest snel &#8220;sterkte!&#8221; zei en weer wegliep, terwijl hij juist behoefte had aan iemand die hielp of ondersteunde. Ik denk dat dit het meest emotionele bericht was dat ik ooit van hem (of misschien zelfs iemand in het algemeen) heb gekregen.

Het zijn die kleine dingetjes die het verschil maken, zelfs als het niet je eigen idee was.