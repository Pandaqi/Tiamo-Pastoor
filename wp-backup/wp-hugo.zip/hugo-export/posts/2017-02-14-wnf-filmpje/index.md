---
title: WNF-filmpje
author: hetisdepanda
type: post
date: 2017-02-14T16:17:58+00:00
url: /toverende-taal/aardige-anekdotes/wnf-filmpje/
categories:
  - Aardige Anekdotes

---
Het is doordeweeks, begin van het schooljaar, en het begint al te schemeren. Ik heb toevallig niet zoveel te doen als mijn zusje binnen komt stormen: &#8220;ik moet voor morgen een WNF promotiefilmpje maken, en op Youtube zetten, maar mijn iMovie is vastgelopen!&#8221; (Wanneer zou iMovie eens niet vastlopen.)

Ze had de afgelopen dagen in verscheidene bossen natuurfilmpjes gemaakt, maar deze monteren (inclusief titels en muziek) was teveel voor haar computer.

<!--more-->

De special effects tovenaar die ik ben (sarcasme hier, sarcasme daar), stort ik me meteen op dit project. Ik download een trial versie van _After Effects_, zet alle filmpjes op een rij, plaats quasi-filosofische teksten erbij — &#8220;Hmm, een open stuk grasveld, wat past hierbij &#8230; VRIJHEID&#8221; — en klaar is kees.

Ik herinnerde een Disney film met een ijsprinses die een prachtig a capella openingsnummer had. Met die muziek eronder werd het een waar meesterwerk! (Jammer genoeg heeft YouTube er later een copyright claim tegenaan gegooid, dus het filmpje staat niet meer op YouTube.)

Totdat we het filmpje in z&#8217;n geheel bekijken en denken: &#8220;meh, het is allemaal een beetje veel van hetzelfde&#8221;. We zien dat één fragment nogal donker en onduidelijk is uitgevallen.

Ik besluit met plug-ins en effecten te klooien. Ta da! Even later regent het ineens in dit fragment! Om het effect nog meer te verkopen stop ik er een geluidseffect van hevige regen onder en maak ik het beeld nog ietsje grauwer.

Mijn zusje twijfelde sterk of we dit wel moesten doen — zo voor de grap laten regenen — aangezien het _overduidelijk_ later erin gemonteerd was. Ik stel haar gerust, want dit is veel te leuk.

De volgende dag breekt aan. Ze laat het filmpje zien en na afloop is er maar één vraag van de docent: &#8220;dapper zeg, zo in de stortregen filmen, hoe heb je de camera droog gehouden als ik vragen mag?&#8221;