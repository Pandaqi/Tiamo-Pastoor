---
title: De Knuffelfietser.
author: hetisdepanda
type: post
date: 2016-10-22T15:00:58+00:00
url: /gewoon-een-gedachte/de-knuffelfietser/
categories:
  - Gewoon een Gedachte

---
Sinds iets meer dan een jaar, draag ik elke dag een hoop knuffels bij me. Niet van die gigantische teddyberen die je als zitzakken kan gebruiken, maar gewoon een aantal lieve sleutelhangertjes die aan zo&#8217;n beetje elk onderdeel van mijn tas (en sleutel) hangen. Niet alleen is knuffeltjes aan je tas hangen een goede manier om je tas te herkennen en wat op te fleuren, het verandert vooral de indruk die anderen van je hebben.

Veel mensen denken dat hun kapsel, of make-up, of spieren hun uiterlijke schoonheid bepalen. De impact van je rugtas (of andere accessoires), echter, is minstens even groot.

<!--more-->

Zo fiets ik bijvoorbeeld wel eens &#8217;s avonds laat &#8211; als het donker is en een beetje griezelig &#8211; van de stad naar huis. Als je een gemeen persoon zou zijn die anderen wil irriteren, moet je op dat soort tijdstippen achter ze gaan fietsen en ze niet meer loslaten :p Of, wat nog verdachter is, is om ze in te halen en dan honderd meter later ineens abrupt af te remmen. Een man zou misschien denken dat je gek bent, maar een vrouw zou zich waarschijnlijk kapot schrikken &#8211; tenzij je een knuffelfietser bent.

Ik heb wel eens gehad dat ik in het donker fietste, en voor mij een meisje in een rotvaart naar huis probeerde te komen. En als er dan iemand anders ineens uit een zijstraat kwam (want dat doen mensen &#8217;s avonds, zeker als ze de hond uitlaten), ging ze nóg harder fietsen. Maar toen ik haar inhaalde, bleef ze de rest van de route achter me fietsen. (Dat duurde zelfs zo lang dat ik er persoonlijk een beetje bang van werd.) Ik vind het fijn te denken dat dat door de knuffeltjes is, maar dat is natuurlijk geen goed genoeg bewijs.

Een andere situatie dan. &#8217;s Ochtends kom ik altijd een hoop mensen tegen die ofwel naar de middelbare school, ofwel ook naar de universiteit moeten. Als dat meiden zijn krijg ik altijd dezelfde reactie als ik langs fiets: &#8220;aaaawww&#8221; Als het jongens zijn lachen ze me keihard uit, of, als ze een beetje in een hangjongeren-bui zijn, roepen ze na dat ik homo ben. En dat is prima. Want met dat soort rotjongens, die altijd met te veel naast elkaar _superlangzaam_ fietsen en het fietspad barricaderen, wil ik ook helemaal niet geassocieerd worden. De knuffels zijn de scheiding tussen mij en het kwaad.

Het kan echter ook andersom werken: mensen denken eerst dat je gewoon een normale jongeman bent, maar als ze de knuffeltjes zien denken ze ofwel dat je een pedo bent, of ze beginnen zich hard af te vragen of ze je leeftijd of geslacht verkeerd hebben ingeschat. Ik vind dat raar, maar ook weer niet zo raar. Natuurlijk is het verkeerd dat mensen denken dat jongens &#8220;stoer&#8221; moeten zijn, en dat knuffels niet voor mannen zijn, maar anderzijds zijn ze het gewoon niet gewend, en dan is je natuurlijke reactie verbazing.

Maar, wat denk ik vooral belangrijk is, is dat het een belofte naar jezelf is. Elke ochtend moet ik veel te vroeg opstaan en heb ik veel te weinig energie, maar als ik die lieve knuffeltjes zie, begint mijn dag toch een beetje goed. Als ik na een lange dag helemaal kapot ben, zie ik de knuffeltjes en kan ik de zachte zorgenvriendjes gebruiken voor een dutje. Het is om mezelf te herinneren om aardig te zijn voor mezelf en voor anderen, om zacht te zijn en niet zonder nadenken maar te doen wat anderen verwachten.

Waar knuffels al niet goed voor zijn.