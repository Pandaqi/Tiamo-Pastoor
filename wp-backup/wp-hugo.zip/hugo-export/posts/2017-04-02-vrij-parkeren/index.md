---
title: Vrij parkeren
author: hetisdepanda
type: post
date: 2017-04-02T15:00:31+00:00
url: /toverende-taal/aardige-anekdotes/vrij-parkeren/
categories:
  - Aardige Anekdotes

---
Bij mij in de buurt staat een groot ziekenhuis. En we weten allemaal wat een groot ziekenhuis nodig heeft &#8211; een grote parkeerplaats! Dus toen het ziekenhuis enigszins indrukwekkende proporties aan begon te nemen, word vóór de vooringang van het ziekenhuis staat een parkeerplaats neergezet waar je u tegen zegt.

Maar, we weten ook allemaal wat mensen doen als ze een grote gratis parkeerplaats zien &#8211; ze gaan er met hun auto de hele dag staan, ook al hoeven ze er helemaal niet te zijn! Sterker nog, naast het ziekenhuis zit een bedrijf dat de laatste jaren gigantisch groot is geworden, dus elke ochtend werd de hele parkeerplaats opgevuld met auto&#8217;s van medewerkers van dat bedrijf. Er waren nog wel wat plekken over, maar zeker niet genoeg om alle ziekenhuisgangers te accommoderen.

<!--more-->

Wat is dan de meest logische oplossing? Betaald parkeren natuurlijk. Want waarom niet mensen die toch al een zwaar leven hebben omdat ze ziek zijn ook nog eens een hoop geld aftroggelen. Dus de parkeerplaats werd erg duur. En dat is logisch, want voor mensen van dat geweldig succesvolle bedrijf is 20 euro parkeergeld per dag natuurlijk een schijntje. Hebben ze binnen een halve minuut koffiedrinken terugverdiend.

Maar de climax in dit verhaal moet nog komen. Dat bedrijf werd zo groot, dat die gigantische ziekenhuisparkeerplaats niet genoeg was voor alle medewerkers. Ze deden vervolgens wat iedereen doet die hun auto soms niet kwijt kan: een parkeerplaats bouwen waar half Nederland zijn auto kwijt zou kunnen _en het zou nog niet vol staan_. En het leukste is nog dat je een pasje nodig hebt van het bedrijf om er überhaupt naar toe te mogen rijden.

Ik stel me nu een groep directeuren voor die elke ochtend neerkijken op het ziekenhuis en het keihard uitlachen. Een groepje leidinggevenden dat eens in de zoveel tijd alle medewerkers instrueert om de hele parkeerplaats leeg te laten en toch lekker bij het ziekenhuis te gaan staan, gewoon om ze te pesten. Zij hebben nu een veel grotere parkeerplaats, helemaal van henzelf, waar medewerkers niet voor hoeven te betalen. Maar tegelijkertijd hebben ze wel de parkeerplaats van het ziekenhuis veel duurder gemaakt dan nodig.

Ik zou hier heel boos over kunnen zijn, maar ik vind het eigenlijk wel grappig. Ik hoop alleen dat het ziekenhuis op een gegeven moment beseft dat ze niet meer zoveel geld moeten vragen. Mensen die zich toch al slecht voelen zouden er spontaan een hartaanval van krijgen, en dan doe je toch iets verkeerd als ziekenhuis denk ik :p