---
title: Kerstnummer 2018
author: hetisdepanda
type: post
date: 2018-12-17T16:00:56+00:00
url: /muzikale-meesterwerken/kerstnummer-2018/
categories:
  - Muzikale Meesterwerken

---
<figure class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio">

<div class="wp-block-embed__wrapper">
  <span class="embed-youtube" style="text-align:center; display: block;"></span>
</div></figure> 

Al zo&#8217;n 8 jaar op rij doe ik elke Kerstmis een speciaal project. Meestal betekent dit dat ik een verhaal of instrumentale compositie schrijf, maar het kan in principe alles zijn.

Dit jaar was het een compositie op de piano! (Mede omdat ik te weinig tijd had voor mijn andere projectplannen.)

Langzamerhand word ik beter in muziek opnemen en mixen op de computer, dus dat is fijn! Het blijft, echter, lastig om een eenzame piano vol te laten klinken. (Zeker met mijn oude, blikkerige keyboard.) Maar ik ben wel blij met het eindresultaat.

De tekening was een schets voor een ander project (een prentenboek dat ik wil gaan maken) die ik losjes heb ingekleurd. Ik vond het wel passend. (Hoewel ik niet weet wat ik moet denken van de armen van het Kerstmannetje. Hij houdt de slee nu heel raar boven zijn schouders vast. Het was veel logischer geweest als zijn armen omlaag hingen. Ach ja, weet ik dat ook weer.)

De titel is niets meer dan een flard tekst die door mijn hoofd dwaalde tijdens het componeren. (Dit klinkt heel deftig, maar componeren betekent voor mij meestal gewoon een halfuurtje improviseren op de piano, en dan hopen dat ik iets ervan heb onthouden.) De zin &#8220;soul collides with you&#8221; past precies op het einde van een van de melodische frases. (Mag jij raden welke :p)