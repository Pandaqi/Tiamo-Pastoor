---
title: Soms vind je jezelf
author: hetisdepanda
type: post
date: 2017-11-24T16:00:47+00:00
url: /toverende-taal/genezende-gedichten/soms-vind-je-jezelf/
categories:
  - Genezende Gedichten

---
Soms vind je jezelf toevallig  
op een mooie plek  
in een intrigerende situatie  
omringd door prachtige muziek

Soms vind je jezelf toevallig  
starend naar een zonsondergang  
je wacht niet tot morgen  
je bent niet bang

Soms vind je jezelf toevallig  
in een ongemakkelijke strijd  
een conflict tussen binnen en buiten  
een gevecht tegen de tijd

Soms vind je jezelf toevallig  
op de bodem van de put  
in het dal tussen hoge heuvels  
in de schaduw van de verlichting

Soms vind je jezelf toevallig  
tussen waarheid en fictie  
tussen opbouwen en afbreken  
tussen doorgaan en doorslaan

Soms vind je jezelf toevallig  
in prachtige bossen  
onder stralende sterren  
langs rustgevende rivieren

Soms vind je jezelf, toevallig.