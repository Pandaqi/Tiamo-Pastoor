---
title: Verdachte Verduisteringen
author: hetisdepanda
type: post
date: 2016-12-11T15:44:02+00:00
url: /gewoon-een-gedachte/verdachte-verduisteringen/
categories:
  - Gewoon een Gedachte

---
Regelmatig ben ik op weg ergens naar toe (meestal op de fiets, meestal naar de universiteit) en kom ik meerdere keren dezelfde auto tegen. En dat is natuurlijk op zich al frappant, want ik fiets zeker niet in een rondje, en neem ook geen grote omwegen. Dus die andere auto moet wel minstens drie keer hetzelfde rondje hebben gereden.

Maar, wat vooral de reden is dat zo&#8217;n auto mij opvalt, is omdat dit soort auto&#8217;s vaak busjes zijn, al dan niet met verduisterde ramen. Je zou kunnen zeggen dat zo&#8217;n busje een camouflage is, en dat er een beroemdheid in zit, of zakken met staven goud, en dat vooral niemand dat mag zien. Maar jullie weten denken net als ik dat dat zeer onwaarschijnlijk is, dus dan wordt de vraag: waarom wil een bestelbusje verduisterde ramen, en waarom zou deze rondjes gaan rijden door de binnenstad?<!--more-->

Het antwoord is natuurlijk: Wie is de Mol! Nee grapje, het eerste wat in gedachten springt zijn natuurlijk mensen met slechte intenties. Iemand die van plan is een kind te kidnappen, rijdt rondjes rond een school, of speeltuin, en verduisterd zijn ramen zodat niemand kan zien wat er binnenin de auto gebeurt. Maar, juist omdat mensen dit weten, valt het weer zo op. Je kunt je ramen wel verduisteren, maar als daardoor de politie meteen op je hielen zit, helpt het niks.

Daar bovenop, de plek waar ik fiets komen ongelofelijk veel auto&#8217;s en fietsers langs, op elk tijdstip van de dag, die over het algemeen op weg zijn naar de universiteit. Dus ik denk niet dat desbetreffende auto&#8217;s daadwerkelijk pedofielen of kidnappers zijn, want dan zijn ze in the wrong place. Nee, hoogstens zijn het criminelen die fietsers lastig vallen en hun laptop stelen. (Wat trouwens vooral de universiteit vervelend zal vinden, want de laptop is, in ons geval, verzekerd tegen diefstal.)

Dus wat is het dan wel? Zou de chauffeur door z&#8217;n verduisterde ramen zelf de weg niet zo goed meer zien, en daardoor zijn verdwaald? Hmm. Een ander voorbeeld.

Vaak zie ik een postwagen (of pakketjeswagen) meerdere keren langs ons huis rijden. Soms krijgen we ook daadwerkelijk iemand aan de deur, vaak stopt ie gewoon voor onze voordeur en gaat al onze buren van pakketjes voorzien. Al jarenlang krijg ik bijna altijd al mijn post van dezelfde mevrouw en meneer &#8211; je zou bijna denken dat ze een vaste baan hebben bij PostNL. Dus het lijkt me niet waarschijnlijk dat men gewoon drie wagens door dezelfde wijk hebben rijden, rond hetzelfde tijdstip. (Daarnaast zou het ook _totaal_ niet optimaal zijn om drie auto&#8217;s op hetzelfde moment rond dezelfde plek te laten rijden. Dat is een beetje hetzelfde als dat jij naar een vriend gaat fietsen, en twee extra fietsen meeneemt, &#8220;voor de zekerheid&#8221;)

Dus, dezelfde wagen komt drie keer langs dezelfde plek, en levert elke keer bij andere mensen andere dingen af. WAAROM!? Zouden ze elke keer dingen vergeten zijn? Zouden ze écht niks te doen hebben en dan maar van hun werk hun hobby maken? Zouden ze teveel post hebben voor deze paar straten om in één keer mee te nemen, en dus steeds naar een distributiecentrum in de buurt rijden?

Ik weet het gewoon niet. Ik moet het eigenlijk een keer aan de postbode vragen, maar &#8220;waarom lijkt het soms alsof je rondjes rijdt?&#8221; klinkt ook weer zo stom. Waarschijnlijk wordt ik dan raar aangekeken en loopt de postbode gewoon weg, of zegt &#8220;ik rijd geen rondjes?&#8221; Dus, ik ben bang dat dit een onopgelost probleem blijft. _Tenzij_, kidnappers nu ineens jongvolwassenen kidnappen, en ze hebben ontdekt dat je als postbode onopgemerkt heel vaak in de buurt kan komen van heel veel mensen. Muwhaha, niet helemaal onopgemerkt dan, want ik heb ze door! Of ik besteed veel te veel tijd aan nadenken over nutteloze dingen, kan ook.