---
title: Freds Wilde Wereld – Deel 4
author: hetisdepanda
type: post
date: 2017-05-11T11:36:31+00:00
url: /visuele-fratsen/freds-wilde-wereld-deel-4/
categories:
  - Crappy Cartoons
  - Visuele Fratsen

---
<img decoding="async" src="http://res.cloudinary.com/nietdathetuitmaakt/image/upload/v1494502523/Fred-WW-4.jpg" />