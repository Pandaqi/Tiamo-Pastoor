---
title: Een korte ontmoeting
author: hetisdepanda
type: post
date: 2017-05-09T15:00:13+00:00
url: /toverende-taal/genezende-gedichten/een-korte-ontmoeting/
categories:
  - Genezende Gedichten

---
Er is schoonheid in de eenvoud,  
er is schoonheid in de chaos,  
‘s Avonds laat, fietsen op straat  
dat ik dat mag  
Bron van licht, lief gezicht  
Duistere nacht, lieve lach

Gedag

had ik maar meer gezegd