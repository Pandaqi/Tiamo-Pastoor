---
title: Dan merk je pas
author: hetisdepanda
type: post
date: 2017-10-09T16:00:18+00:00
url: /toverende-taal/genezende-gedichten/dan-merk-je-pas/
categories:
  - Genezende Gedichten

---
Je merkt pas dat je iemand mist  
als je dag na dag opstaat  
de trap af, de deur open  
en hem aan de ontbijttafel verwacht  
maar hij is er niet

Je merkt pas dat je iemand mist  
als je uur naar uur probeert te denken  
afleiding zoekt, werk verricht  
maar je gedachten dwalen af  
naar hij die er niet is

Je merkt pas hoe erg je iemand mist  
als je nacht na nacht in bed kruipt  
nadenken gaat, aan het dromen slaat  
en wenst dat hij je morgen wakker schudt  
maar hij doet het niet

Je voelt pas hoe enorm je iemand mist  
als je woord na woord aanhoort  
en verwacht dat hij zoals altijd  
de zaken zal doen, en de dingen regelt  
maar hij verschijnt maar niet