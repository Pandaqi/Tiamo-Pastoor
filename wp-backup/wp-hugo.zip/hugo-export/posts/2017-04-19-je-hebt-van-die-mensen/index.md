---
title: Je hebt van die mensen
author: hetisdepanda
type: post
date: 2017-04-19T16:00:18+00:00
url: /gewoon-een-gedachte/je-hebt-van-die-mensen/
categories:
  - Gewoon een Gedachte

---
Ik denk dat ik de beste manier om een zin te beginnen heb gevonden. Een vriend van mij begint best vaak een zin met &#8220;je hebt van die mensen &#8230;&#8221;, gevolgd door een merkwaardig of grappig iets dat hem is opgevallen. Ik ben dat over gaan nemen, merkte ik laatst. Het is zelfs zo erg, dat ik zelfs in mijn gedachten zinnen op die manier open. Ik zie bijvoorbeeld weer eens een zo-goed-als-leeg pak yoghurt in de koelkast staan, en ik denk: &#8220;Je hebt van die mensen die nog te lui zijn om een pak op te maken en weg te gooien.&#8221; Toegegeven, een redelijk negatieve gedachte, maar het is beter dan dat ik in mezelf (of hardop) mensen ga vervloeken en uitschelden.

Hoe dan ook, ik denk dat er een goede reden is dat deze zin vaak te gebruiken is, en ook vaak in positieve zin wordt gebruikt. Meestal als iemand zo&#8217;n zin begint, vertelt hij of zij vervolgens een verhaaltje. Iets wat hij heeft meegemaakt, iets raars dat hij iemand heeft zien doen. Vaak is het ook bedoeld als soort van advies of reactie op iemand anders. (&#8220;Ugh, ik moet eigenlijk een bijbaantje hebben maar ik weet niet wat of hoe.&#8221; &#8220;Nouja, je hebt van die mensen die gewoon bij de Albert Heijn binnenlopen en net zo lang blijven zeuren tot ze een baan krijgen.&#8221;) En meestal wordt dat gewaardeerd. Mensen snappen het meteen, ze herkennen wat je zegt, en vooral: ze voelen zich een beetje beter omdat er dus blijkbaar superveel mensen zijn die nog stommere dingen doen.

<!--more-->

Dus, mocht je een manier zoeken om sociaal over te komen en mensen geïnteresseerd te maken in jou en wat je zegt, begin zo veel mogelijk zinnen met &#8220;je hebt van die mensen&#8221;. Niet te veel natuurlijk, want dan lijk je een robot die hapert. Of iemand zonder geheugen. Of iemand die weinig andere zinnen kent.

Maar, wat ik persoonlijk dan meteen interessant vindt, is of je daar ook een beetje misbruik van kan maken. Als iemand zegt &#8220;je hebt van die mensen&#8221;, dan gaan luisteraars meteen van twee dingen uit: de mensen die doen wat hij zegt _bestaan,_ en diegene die het zegt heeft blijkbaar al _heel vaak dat soort mensen meegemaakt_. Het is een beetje alsof je zegt &#8220;als je een beetje algemene en sociale kennis hebt&#8221;, of &#8220;zoals ieder cool persoon weet&#8221;. (Ik wilde die zin eerst afmaken met &#8220;&#8230; laten alle coole personen ook soms een scheet&#8221;. Ik vind het spreekwoord-waardig.)

En dus maakt het niet uit wat je er achteraan zegt; mensen gaan er toch vanuit dat het waar is, en doen eventueel alsof ze het meteen herkennen. Geef toe, een zin als &#8220;je hebt van die mensen die zich zo hard vervelen in een bushokje dat ze lantaarnpalen gaan knuffelen&#8221; klinkt alsof iemand daar één of meerdere keren een aanvaring mee heeft gehad. Een zin als &#8220;je hebt van die mensen die zichzelf geweldig vinden&#8221; is vaag genoeg dat iedereen er zelf wel een paar personen bij kan bedenken. Een zin als &#8220;je hebt van die mensen die een olifant als huisdier nemen en haar leren de macarena te dansen&#8221; gaat misschien een beetje te ver, maar je kunt het proberen.

Mocht je dit lezen en denken &#8220;dat klinkt grappig&#8221;, dan daag ik je uit om met deze zin mensen de raarste dingen te doen geloven. Ik daag je ook uit als je dit leest en denkt &#8220;wat een rare vent&#8221;, maakt mij niet uit.

&nbsp;