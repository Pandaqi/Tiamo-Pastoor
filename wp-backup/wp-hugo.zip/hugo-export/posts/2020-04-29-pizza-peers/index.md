---
title: Pizza Peers
author: hetisdepanda
type: post
date: 2020-04-29T16:00:29+00:00
url: /gewoon-een-gedachte/pizza-peers/
featured_image: https://nietdathetuitmaakt.nl/wp-content/uploads/2020/04/mainLogo.gif
categories:
  - Gewoon een Gedachte
  - Superieure Spellen

---
**Pizza Peers** is een coöperatief spel over pizza&#8217;s bezorgen. Het is een chaotische en vooral hilarische dans tussen het verzamelen van ingrediënten, uitvinden van nieuwe pizzacombinaties, bakken tot de perfecte temperatuur, en vervolgens nét op tijd afleveren.

Bezoek de officiële spelpagina voor meer uitleg hoe het spel werkt: [**Pizza Peers &#8211; Tasty Multiplayer Fun**][1]

## Trailer<figure class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio">

<div class="wp-block-embed__wrapper">
  <span class="embed-youtube" style="text-align:center; display: block;"></span>
</div></figure> 

  


<!--more-->

## Over &#8220;Pizza Peers&#8221;

Dit spel &#8230;

  * Is voor alle leeftijden
  * Heeft vier moeilijkheidsgraden om je op te warmen
  * Is helemaal gratis
  * En heeft geen installatie of andere apparatuur nodig

Waarom niet? Omdat je het spel opstart op de computer en speelt met je smartphone!

Volg onderstaande stappen om het spel te spelen:

  * Ga naar deze link op een computer: [**http://pizza-peers.herokuapp.com**][2]
  * Click &#8220;create game&#8221; => na eventjes wachten staat rechtsonder een viercijferige code (de &#8220;room code&#8221;)
  * Vraag nu alle spelers om hun smartphone erbij te pakken en naar hetzelfde adres te gaan.
  * Typ de &#8220;room code&#8221; en een leuke gebruikersnaam, en klik &#8220;join game&#8221;

Tada! Als iedereen verbonden is, klik je op het knopje en begin je met spelen.

## The Peerful Project

Dit spel is onderdeel van &#8220;The Peerful Project&#8221;.

  * [**Klik hier**][3] voor de pagina op het blog die dit project uitlegt (in het Nederlands, motivatie voor dit project en wat het inhoudt)
  * [**Klik hier**][4] voor de officiële pagina van het project (in het Engels, vooral mooie plaatjes en de lijst met spellen)

Het is het allereerste spel in het project. Ik ben er erg trots op en zie dat iedereen er veel plezier aan beleeft, maar er kan natuurlijk nog veel beter.

De komende spellen worden waarschijnlijk wat kleiner en simpeler dan deze, maar daarmee niet minder leuk of innovatief! Stay tuned, ik heb een paar gave dingen in gedachten.

 [1]: http://pandaqi.com/pizza-peers
 [2]: http://pizza-peers.herokuapp.com
 [3]: http://nietdathetuitmaakt.nl/bijzondere-bordspellen/the-peerful-project/
 [4]: http://pandaqi.com/the-peerful-project