---
title: '[HdT] #7 Ark van Noah'
author: hetisdepanda
type: post
date: 2018-06-07T16:00:38+00:00
url: /visuele-fratsen/hdt-7-ark-van-noah/
categories:
  - Crappy Cartoons
  - Visuele Fratsen

---
<img decoding="async" src="http://res.cloudinary.com/nietdathetuitmaakt/image/upload/v1528225914/Henk-de-Tijdreiziger-_7.png" />

Ja, je spelt het eigenlijk als _nougat_, maar blijkbaar weet niemand dat. En ja, het konijn is de enige die alleen op de boot is, maar dat komt &#8230; omdat hij die ander heeft opgegeten? (Nee, dat komt eigenlijk omdat er geen ruimte meer voor was, maar dat vertelt de tekenaar natuurlijk niet :p)