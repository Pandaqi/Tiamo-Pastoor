---
title: Openbaar Vervoer
author: hetisdepanda
type: post
date: 2016-11-07T17:02:09+00:00
url: /gewoon-een-gedachte/openbaar-vervoer/
categories:
  - Gewoon een Gedachte

---
Eens in de zoveel tijd heb ik een zeldzame aanvaring met het OV. Soms dan is iets te ver om te fietsen, en kan niemand me brengen, dus moet ik wel. Op dat soort moment word ik er weer aan herinnerd dat het OV-chipkaart systeem onnodig ingewikkeld is. (Waarom moet je per sé naar een geel service-apparaat ergens in een supermarkt om je kaart op te waarderen of een abonnement er op te zetten? &#8220;Goh, Henk, we hebben alle gegevens en systemen online in databases staan, we zouden gewoon met één druk op de knop dingen kunnen regelen voor mensen&#8221; &#8220;Nee Truus, foei, straks denken mensen nog dat OV leuk is!&#8221;)

Ik word er aan herinnerd dat je er nooit helemaal gerust op kan zijn dat iets op tijd aankomt of vertrekt, en dat je dus maar het beste een half uur van tevoren op het station kunt aankomen. Ik word er aan herinnerd dat fietsenstallingen bij stations en bushaltes allesbehalve veilig zijn. Ik hoor dagelijks iedereen om me heen klagen over volle treinen, vertraging, bussen die gewoon niet op komen dagen of ineens een compleet andere route besluiten te rijden, en noem het allemaal maar op. Maar is dat wel zo&#8217;n groot probleem?

<!--more-->

Ik heb zelden een fatsoenlijke zitplek gehad in de trein. Vrijwel altijd sta ik samen met wat andere mensen op een kluitje in de tussenstukjes, en is het zo&#8217;n rotzooi dat men niet eens de piepkleine uitklapstoeltjes uitgeklapt krijgt. Je kunt er over zeuren, je kunt er chagrijnig van worden, maar meestal leidt het tot leuke gesprekken met vreemdelingen en memorabele situaties. Zeker &#8217;s avonds, als het buiten donker en koud is, en binnen in de trein warm en verlicht, heeft het wel iets romantisch. Ik ken meerdere mensen die vrienden hebben gemaakt in het OV. Ik ken zelfs meerdere mensen die een relatie hebben gekregen met iemand die ze leerden kennen toen hun reistochten ineens kruisten.

Ik vind het heerlijk om samen met mensen ergens heen te reizen. Je bent samen met mensen, met hetzelfde doel, met dezelfde problemen met het OV. Je zit een tijdje samen stil, maar toch ga je ergens heen en bereik je iets. Ik bedenk mijn beste ideeën als ik &#8217;s avonds met mensen naar huis fiets. Ik heb de mooiste gedachten als het buiten keihard regent en ik zit in de trein bij het raam weg te dromen. Ik heb de beste gesprekken met mensen doordat we op een veel te laat (of vroeg) tijdstip onszelf nog ergens heen probeerden te slepen.

Al die OV-gebruikers moeten het gewoon anders zien. Het feit dat het OV je ergens heen brengt &#8211; hopelijk de plek waar je daadwerkelijk moet zijn &#8211; is een bijdingetje. Het belangrijkste van het OV is dat het een plek is die je even los kan rukken uit je dagelijkse sleur. In plaats van dat je comfortabel in je bed series zit te kijken, zit je ineens een half uur bovenop mensen die je niet kent, en zie het dan maar gezellig te maken. In plaats van dat je in je eentje achter de computer hopeloos naar je huiswerkopgaven staart, kun je vrij associëren en helpen de dingen die je meemaakt in het denkproces. In plaats van dat je altijd met dezelfde paar mensen praat en omgaat, moet je aan jezelf bewijzen dat je ook sociaal kunt zijn.

Als het kon (als in, als ik er de tijd en het geld voor had), zou ik elke avond naar een willekeurige stad reizen met de trein of bus. Kijken wie ik tegenkom, kijken of ik bevriend kan raken met mensen die ik elke keer weer tegen het lijf loop, kijken wat er te doen is in die andere stad. Genieten van de avondlucht, de stadssfeer, of misschien juist de stille, vreselijk mooie natuur. Dit klinkt erg mooi en dromerig, maar natuurlijk moet er ook gewerkt worden. Maar wees niet gevreesd, ook dat kan in de trein, als je maar op tijd een plekje claimt :p