---
title: Wolkentolken
author: hetisdepanda
type: post
date: 2018-01-24T15:59:54+00:00
url: /toverende-taal/genezende-gedichten/wolkentolken/
categories:
  - Genezende Gedichten

---
Als wolken konden praten,  
negeerde ik elk gerucht,  
je kunt ze beter laten  
het is toch maar gebakken lucht