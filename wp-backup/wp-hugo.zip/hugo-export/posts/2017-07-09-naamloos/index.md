---
title: Naamloos
author: hetisdepanda
type: post
date: 2017-07-09T15:00:42+00:00
url: /toverende-taal/genezende-gedichten/naamloos/
categories:
  - Genezende Gedichten

---
Ik heb harde lessen geleerd  
Ik heb zachte knuffels gehad  
Als je de doornstruiken wegdenkt  
Ben ik al jaren op het juiste pad