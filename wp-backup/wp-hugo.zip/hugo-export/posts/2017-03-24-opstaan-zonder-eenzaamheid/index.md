---
title: Opstaan zonder eenzaamheid
author: hetisdepanda
type: post
date: 2017-03-24T15:00:04+00:00
url: /toverende-taal/genezende-gedichten/opstaan-zonder-eenzaamheid/
categories:
  - Genezende Gedichten

---
Wanneer de zon laag staat  
ben ik  
te laat

Wanneer de maan puur schijnt  
en ik  
verdwijn

Wanneer de zon weer stijgt  
zelfs ik  
ben klein

Wanneer de dag aanbreekt  
sterf ik  
te veel

Wanneer alles wakker wordt  
schiet ik  
tekort

Maar wanneer jij verschijnt  
wil ik  
weer zijn