---
title: Soms snap ik Bol.com niet
author: hetisdepanda
type: post
date: 2020-02-12T16:00:17+00:00
url: /gewoon-een-gedachte/soms-snap-ik-bol-com-niet/
categories:
  - Gewoon een Gedachte
  - Superieure Spellen

---
Er bestaat een heel grappig spel genaamd **Klask.** (Wat weer een soort van broertje is van het oudere, klassieke **WeyKick**.)

In dit spel bestuurt iedereen een poppetje met magneetjes onder het speelveld. Het doel? Schiet de bal in het doel van je tegenstander. Het is super simpel, hartstikke leuk, en functioneert als een soort minder intimiderende variant van _tafelvoetbal_ (of meer tactische variant van _air hockey_).

En Bol.com krijgt het voor elkaar om deze foto tussen het promotiemateriaal te stoppen:

[<img decoding="async" loading="lazy" class="size-full wp-image-9202 aligncenter" src="http://nietdathetuitmaakt.nl/wp-content/uploads/2020/02/Klask-Bol.com__result.webp" alt="" width="550" height="825" />][1]

Stel je voor dat je lekker aan het lunchen bent op je werk. Onder het genot van een croissant met koffie bespreek je bedrijfsplannen met je collega&#8217;s.

Je hoort ineens een gil achter je.

Je draait je om, zit er iemand MET EEN HOND ONDER ZIJN ARM, met een magnetisch poppetje een bal te kaatsen. Met zo&#8217;n lach op het gezicht van: &#8220;ha, loser, je kunt mij toch nooit verslaan, ik heb een hond&#8221; (Gek genoeg lijkt de hond heel serieus het speelveld te bestuderen, net zoals zijn tegenstander. You&#8217;re fooling no one, Bol.com, die hond is eigenlijk het meesterbrein achter dit potje Klask.)

Zo, dat moest ik even zeggen.

_Opmerking:_ ik heb dus niet genoeg geld om zelf zo&#8217;n bord te kopen. Hopelijk heb ik dat in de toekomst wel, want het lijkt me oprecht een geweldig spel. Ik hou sowieso van dat soort tastbare en fysieke spellen, zoals tafelvoetbal, air hockey, pingpong, et cetera. En dan komt er waarschijnlijk ook een (serieuze) recensie van dit spel :p

&nbsp;

 [1]: http://nietdathetuitmaakt.nl/wp-content/uploads/2020/02/Klask-Bol.com__result.webp