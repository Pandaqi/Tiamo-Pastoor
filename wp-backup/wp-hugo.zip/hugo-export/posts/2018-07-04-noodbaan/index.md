---
title: Noodbaan
author: hetisdepanda
type: post
date: 2018-07-04T11:47:07+00:00
url: /toverende-taal/aardige-anekdotes/noodbaan/
categories:
  - Aardige Anekdotes

---
Dit artikel is een anekdote over banen. (Die dingen waar je werkt en vervolgens geld krijgt.)

Ik wilde een goede woordgrap maken in de titel, maar ik was even het woord &#8220;vluchtstrook&#8221; kwijt — je weet wel, die strook langs sommige delen van de snelweg, speciaal voor noodgevallen — en dacht dat het een &#8220;noodbaan&#8221; heette.

Dit bleek Zuid-Afrikaans voor vluchtstrook. Het duurde jammer genoeg lang voordat ik dat doorhad. (Ik dacht dat alle sites waarop ik kwam een erg bijzondere spelling hanteerden.) Maar toen ik dat zag kon ik ervan genieten. Zuid-Afrikaans is namelijk een geweldig ingenieuze, schattige variant op het Nederlands.

(Dit stond in een artikel over auto&#8217;s die de noodbaan blokkeerden waardoor hulpdiensten niet konden doorrijden: &#8220;Diegene wat die _noodbaan_ versper het sodat ek, in die reaksievoertuig, en ons brandweerwa nie kon verbykom nie: Skaam julle!&#8221;)

Hoe dan ook: **ik overhoorde vandaag een leuk gesprek**. Ik zat te wachten op mijn afspraak op de universiteit, toen twee jongens voorbij liepen. De eerste zei:

<p style="padding-left: 30px;">
  &#8220;Ze hadden me ook nog een baan aangeboden!&#8221;
</p>

<!--more-->

Je verwacht een blij gezicht, gejuich, felicitaties, confetti. Wat gebeurde er? Die persoon begon keihard te lachen. Die ander deed meteen mee. En enkele seconden later zei die ander:

<p style="padding-left: 30px;">
  &#8220;Mij ook!&#8221;
</p>

Waarna ze moesten bulderen van het lachen, terwijl ze uit zicht verdwenen.

Ik was ongelofelijk benieuwd naar de context. Laten we de puzzelstukjes bij elkaar leggen: twee studenten hebben van dezelfde persoon/instantie een baan aangeboden gekregen, zonder dat ze het van elkaar wisten. Dat was blijkbaar lachwekkend, een reden tot spot, en ik ga ervan uit dat ze de baan niet hebben aangenomen.

**De eerste optie:** een professor zit nu heel zielig in zijn kamer zich af te vragen wat hij verkeerd heeft gedaan. Hij heeft al superlang een assistent nodig, en hij biedt al zijn masterstudenten een baan aan (nadat ze hun scriptie hebben afgerond). Geen van hen heeft het ooit geaccepteerd. Ze vonden het al moeilijk genoeg om met die professor om te gaan, en moesten niet _denken_ aan een slecht betaald baantje waarbij ze hem elke dag zagen.

**De tweede optie:** er is grote vraag naar universitaire studenten, zeker in mijn richting (wiskunde en informatica). Toen ik mijn LinkedIn aanmaakte halverwege het eerste jaar van de studie, kreeg ik daarna regelmatig aanbiedingen voor stages, part-time banen (en een paar full-time banen van mensen die het niet begrepen). Vaak waren dat dezelfde algemene berichten van bedrijven die hopeloos op zoek waren naar _iemand_ die de vacature wilde opvullen.

Ik werd het op een gegeven moment zat om hen steeds vriendelijk af te wijzen. (Of uit te leggen dat: &#8220;het feit dat ik kan programmeren, websites maken, en visueel ontwerpen, betekent niet dat ik ze ALLEMAAL TEGELIJK kan met die ene rare programmeertaal die jullie bedrijf gebruikt&#8221;) Dus toen heb ik mijn LinkedIn status verandert naar &#8220;Doet dingen.&#8221;, in plaats van een fatsoenlijke uitleg van wat ik kan of dat ik wiskunde studeer. Wat denk je? Geen vervelende aanbiedingen meer!

Het stomme is alleen dat ik veel mensen ken die een _moord_ zouden doen voor aanbiedingen. Die zouden een gat in de lucht springen als iemand op _hen_ afkwam omdat diegene hen heel graag voor een goed salaris wilde hebben. Dus ik voelde me enigszins elitair door het juist vervelend te vinden.

En ik denk dat die twee jongens er hetzelfde over dachten.

<p style="padding-left: 30px;">
  &#8220;Pff, kreeg wéér een aanbieding van Philips om te komen werken als statistical researcher.&#8221;<br /> &#8220;Zeker weer een prutsalaris?&#8221;<br /> &#8220;4000 per maand! Om te huilen!&#8221;<br /> &#8220;Jeetje mineetje, wat een paupers. Ik zou reageren met: 10 000 per maand, voor minder doe ik het niet.&#8221;<br /> &#8220;Al gedaan. Maar nee, toen waren ze natuurlijk niet meer geïnteresseerd.&#8221;<br /> &#8220;Ik had dat laatst ook. Media Markt zocht iemand om speciaal voor hen een &#8216;Media Markt&#8217;-laptop te maken.&#8221;<br /> &#8220;Tss, vraag het aan de zwervers ofzo. Ver beneden onze pay grade.&#8221;<br /> &#8220;Ze vonden mijn diploma&#8217;s en ervaring zo goed, ze hadden mijn naam doorgegeven aan Microsoft. Die sneue gasten hadden me zelfs een baan aangeboden!&#8221;<br /> (Haha)<br /> &#8220;Mij ook!&#8221;<br /> (Haha)
</p>

**De derde optie:** het ging over bowlen :p

Dit was het weer voor onze wekelijkse column &#8220;woensdag wereldnieuws&#8221;, waarvan dit de eerste aflevering was, en waarschijnlijk ook de laatste, want geef toe: &#8220;woensdag wereldnieuws&#8221; is een stomme naam. (Woensdag Wijsheden zou dan nog beter zijn. Maar ik denk niet dat dit artikel veel wijsheid met zich meedraagt. De enige boodschap lijkt te zijn: het is leuk om gesprekken af te luisteren en zelf de details in te vullen, en studenten vinden zichzelf heel wat.)

<div class="list-featured__wrap">
  <p class="list-featured__text">
    En als afsluiter nu de leukste nieuwszin van de dag &#8230;
  </p>
  
  <p class="list-featured__text" style="padding-left: 30px;">
    &#8220;Mijn kat wilde vanochtend naar buiten&#8221;, zegt de bewoner. &#8220;Toen zag ik dat ik geen balkon meer had.&#8221;
  </p>
  
  <p>
    Kijk niet raar op als ik ooit een verhaal schrijf met de titel: &#8220;de balkondief&#8221;. (Met een spraakgebrek, waardoor iedereen denkt dat hij de &#8220;ballondief&#8221; is.)
  </p>
</div>

&nbsp;