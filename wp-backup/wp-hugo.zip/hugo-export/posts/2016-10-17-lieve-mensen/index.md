---
title: Lieve Mensen
author: hetisdepanda
type: post
date: 2016-10-17T15:00:40+00:00
url: /gewoon-een-gedachte/lieve-mensen/
categories:
  - Gewoon een Gedachte

---
Soms vraag ik me af: heb ik gewoon geluk gehad, of is de wereld een stuk liever dan men ons wil doen geloven?

Als ik de krant opensla, zie ik overal uit de hand gelopen ruzies, steekpartijen, ontvoeringen, drugs-liquidaties, en ga zo maar door. Als ik mijn Facebook bekijk zie ik overal berichten van welke stomme of verschrikkelijke dingen mensen nou weer hebben gedaan. Ik zie mensen die een heel artikel schrijven over dat homo&#8217;s geaccepteerd moeten worden, en een nog veel grotere groep mensen die onder al die artikelen hatelijke comments plaatst. Waarop weer hatelijke comments worden geplaatst, en daarop wéér nog meer haat, en ga zo maar door.

<!--more-->

Als ik uit interesse iets wetenschappelijks opzoek kom ik altijd blogs tegen van mensen die fel tegen onderzoek, wetenschap en kennis zijn. Niet alleen dat, ze verspreiden foutieve informatie en krijgen grote groepen trouwe volgelingen. Het is een beetje alsof Jezus zou verkondigen dat roken goed voor je is, en dat hij zegt dat aan het einde van zijn speech gratis hamburgers zullen worden uitgedeeld, dus iedereen klapt en juicht en is het meteen met hem eens.

En als iemand dan vraagt _maar waar is je bewijs dat roken zo goed is?_ Dan zegt hij _weet je wat ook goed is? Hamburgers!_ _En bovendien, het is nooit bewezen dat roken slecht voor je is!_ En jij bent natuurlijk niet tevreden, dus je zegt _wat, er is wel bewezen dat roken slecht voor je is?_ En hij zegt _ik ben de zoon van God, ik heb vijf keer de marathon gelopen _(al nam hij een shortcut over het water), _ik heb de hele bevolking van jaren alcoholverslaving voorzien, en ik heb een diploma schrijven, wederopstanding en paaseieren verstoppen &#8211; waarom zou zo&#8217;n deskundig persoon liegen over dat nooit écht bewezen is dat roken slecht voor je is?_ En hij duwt ook nog een gratis plakje cake in je hand, en waggelt weer vrolijk verder.

Als ik achter een groep jongeren fiets wordt er, zonder uitzondering, tientallen keren grof gescholden. Als ik achter ouderen fiets wordt er, zonder uitzondering, tientallen keren asociaal gereden en verkeersregels overtreden. Dat niet alleen, ze veroorzaken wel degelijk levensgevaarlijke situaties. En ik voorspel nu, mochten er ooit zelf-rijdende auto&#8217;s komen die onverhoopt een aanrijding krijgen, dan gaat men massaal de mensen die er in zitten de schuld geven. En ik voorspel nu, mocht er ooit een medicijn of behandeling tegen kanker worden gevonden, dan gaan er mensen hele bewegingen oprichten om &#8211; zonder enige vorm van bewijs of justificatie &#8211; te claimen dat die medicijnen autisme veroorzaken.* (Het zal je maar gebeuren. Dan organiseren ze een protest tocht tegen dat medicijn, en dan wordt het ineens een stille tocht voor alle fatale slachtoffers binnen hun vereniging.)

Overal zijn grote groepen mensen te vinden die de buitenwereld het liefst zo veel mogelijk dwars zitten, mensen zoveel mogelijk pijn doen, en zichzelf geweldig vinden. Overal vind je ze &#8211; maar niet omdat ze in de meerderheid zijn, maar omdat ze het hardste schreeuwen en het meeste kapot maken. Als je daar doorheen weet te kijken, als je door het bos van negativiteit, pessimisme, haat, en stellige meningen door kijkt, zul je prachtig bloeiende bomen vinden. Dit klinkt poëtisch en zweverig, en dat is het ook.

Wat ik wil zeggen is dat ik in mijn leven veel rotte appels heb ontmoet, maar veruit het grootste deel van de mensen waarbij ik ook maar in de buurt ben geweest, zijn hele lieve mensen. Ze zijn aardig. Ze zijn altijd in voor een praatje, of proberen jou juist op te vrolijken met verhalen. Ze proberen je te helpen als je vast zit, ze nodigen je uit voor feesten en evenementen. Ze bedenken van tevoren of iets wat ze willen doen andere mensen tot last zal zijn &#8211; en als dat zo is, dan doen ze het niet (revolutionair!). Ze respecteren andermans persoonlijkheid, haar voor- en nadelen, en haar grenzen. Ze stralen hun eigen slechte humeur of omstandigheden nooit af op anderen, en bedenken geen onzin om anderen kwaad te doen, uit jaloezie of onzekerheid.

Die mensen, die verdienen allemaal een lintje. Of een medaille. Of een andere hoge onderscheiding. Of gewoon een zak chips, wat ze denk ik liever hebben. Want lieve mensen willen niks er voor terug. Lieve mensen zijn er niet op uit om zichzelf op te hemelen, of anderen naar beneden te trekken. Ze werken in de achtergrond aan een betere wereld.

Dus, de volgende keer dat iemand weer gemene dingen schreeuwt, bedenk dit: negeer die persoon compleet, en zoek de lieve mensen in je leven. En als het even kan, leer van ze, en help ze ook eens een handje.

*Voor mensen die denken dat dit voorbeeld overtrokken is &#8211; het is _exact_ wat er, in ieder geval in Amerika, is gebeurd met de onzin rondom dat vaccinaties autisme zouden veroorzaken. Niet vaccineren is potentieel dodelijk. Niet alleen voor jezelf, maar ook andere kinderen, dus eigenlijk is wat er echt gebeurde nog _erger_ dan mijn kanker-voorbeeld. (Wat klinkt als een raar scheldwoord, maar dat bedoel ik dus niet zo.)