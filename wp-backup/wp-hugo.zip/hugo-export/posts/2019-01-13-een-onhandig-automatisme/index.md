---
title: Een onhandig automatisme
author: hetisdepanda
type: post
date: 2019-01-13T16:00:44+00:00
url: /toverende-taal/aardige-anekdotes/een-onhandig-automatisme/
categories:
  - Aardige Anekdotes

---
Lang, lang geleden hadden wij thuis een bijzondere gewoonte. Een soort &#8220;inside joke&#8221; die wij zelf nauwelijks begrepen. Een ritueel waarvan ik nu weet waarom het geen ritueel meer is.

Als we iemand groetten, of juist gedag zeiden, of een grapje maakten &#8230; _dan sloegen we die persoon tegen de kont_. Gewoon, een snelle pets tegen de kont. Ik weet niet waarom, maar achteraf gezien moeten buitenstanders hebben gedacht dat we een soort cult vormden, en dat dit ons geheime signaal was. Voor de gezinsleden, echter, was het allemaal heel normaal. Waar anderen een _high five_ deden, of een _boks_, deden wij een high five tegen de billen. Zo, als je nu nog niet denkt dat ik gek ben, lees vooral verder!

Begin van het schooljaar; ik zat in groep 6. We stonden in een rij om het klaslokaal binnen te gaan. Ons lokaal was immers net aangebouwd en had een hele smalle doorgang.

(Het was niet alsof we werden gefouilleerd. &#8220;Zozo, laat die handjes maar zien. Zijn die knikkers van jou? Zeg op! Nee hè? Je hebt ze weer gejat! Net als die Pokémonkaarten van vorige week! Tja, ik ben bang dat je niet door de douane komt. Probeer maar bij groep 4 erdoorheen te komen, daar pikken ze dit soort dingen nog.&#8221;)

<!--more-->

(Ik krijg nu ineens geweldige ideeën voor een verhaal! Men doet een project op de basisschool om de kinderen meer te leren over de wereld en de maatschappij. Om het zo leuk mogelijk te maken krijgt elke groep een eigen land aangewezen die ze een maand lang moeten &#8220;runnen&#8221;. Voor men het weet zijn er ineens diplomatische rellen tussen groep 2 en groep 4, wil groep 8 haar handelsverdrag met groep 7 opzeggen, en verklaart groep 6 _iedereen_ de oorlog. Mocht iemand dit lezen en dit verhaal schrijven: ik wil dat lezen!)

Hoe dan ook: ik kwam wat later terug van de pauze en sloot achteraan de rij. Vóór mij stond een van mijn vriendinnen. (Nee, ik deed niet aan polygamie op die leeftijd. Gekke lezer toch. Ik was bevriend met meerdere meisjes; dit was er één van. Zo, nu kunnen we door.)

Ik wilde haar begroeten. Want, dat is wat je doet als je een bekende ziet. Wat doet mijn stomme hoofd? &#8220;Thuis geven we altijd een pets tegen de kont, dus &#8230;&#8221;

Ik sloeg haar _keihard_ op haar kont.

Ik heb nog _nooit_ iemand zo boos en teleurgesteld en verward tegelijkertijd naar mij zien kijken. Ze keek alsof ze al dertig jaar met mij getrouwd was en net had gehoord van al die andere vriendinnen van mij :p Die vriendschap is uiteindelijk ook helemaal niks meer geworden. Ik heb nog maar één keer met haar afgesproken sindsdien, en toen wilde ze — gek genoeg — perse met meerdere mensen tegelijkertijd afspreken.

Dus onthoudt deze wijze les: &#8220;als een automatisme een blik doet verschijnen die je nog nooit eerder hebt gezien bij je vriend/vriendin, is het misschien een onhandig automatisme&#8221;

_Opmerking:_ ik kan deze categorie haast beter hernoemen van &#8220;Aardige Anekdotes&#8221; naar &#8220;Genante Anekdotes&#8221;. Ik besef nu pas hoeveel stomme dingen ik vroeger heb gedaan. En hoe dat de enige interessante anekdotes zijn :p (Of de enige dingen die ik heb onthouden. Ik moet toch ook slimme dingen hebben gedaan vroeger? Toch? Toch!?)