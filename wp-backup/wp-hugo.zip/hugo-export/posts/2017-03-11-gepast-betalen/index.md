---
title: Gepast Betalen
author: hetisdepanda
type: post
date: 2017-03-11T15:00:49+00:00
url: /gewoon-een-gedachte/gepast-betalen/
categories:
  - Gewoon een Gedachte
  - Proberen Programmeren

---
Laatst was ik bezig met een eigen kaartspel/bordspel, en hoefde ik nog maar één onderdeel te ontwerpen: de geldbriefjes. Geld is een erg belangrijk onderdeel in het spel, aangezien je uit het spel ligt als je het niet hebt, en niks kan als je er te weinig van hebt. Het is om die reden dat ik hoge eisen stel aan mijn geldbriefjesvoorraad:

  * Het mag&nbsp;nooit&nbsp;opraken tijdens het spel.
  * Iedereen moet&nbsp;altijd gepast kunnen betalen. Dus, stel je bent iemand 7 euro verschuldigd, dan moet je&nbsp;niet verplicht zijn 20 euro te geven omdat je niks&nbsp;kleiners hebt. (In sommige spellen, zoals Koehandel, is dit wel een grappig element overigens. Vaak ben je veel meer kwijt dan je hebt geboden, omdat je niet gepast kan betalen en het spel geeft er geen reet om.)

Maar, er kwam&nbsp;een&nbsp;oud en bekend probleem om de hoek kijken: mijn grondstoffen zijn schaars en ik ben sterfelijk! Ik kan niet duizenden&nbsp;vellen met geldbriefjes uitprinten, want dat kost teveel tijd en geld, en is niet nodig.

<!--more-->

Dus, om dit probleem op te lossen, moest ik&nbsp;op zoek naar de optimale verdeling van geldbriefjes. Ofwel, elk mogelijk getal in een bepaald interval (zeg, 0 euro tot 1000 euro) moet op _zoveel mogelijk manieren_ gemaakt kunnen worden. Hierbij moet&nbsp;ik twee vragen beantwoorden:

  * Welke verschillende waardes voor geldbriefjes moet ik nemen?
  * Hoeveel moet ik van elke soort in het spel stoppen?

## La Theorie!

Gelukkig ken ik hiervoor een simpele wiskundige aanpak, die ik nu ga proberen uit te leggen. Wiskunde doet veel met functies, en in dit geval gaan we dingen doen met _machtreeksen_. Een machtreeks is niets anders dan heel veel verschillende machten van een getal opgeteld:

<div class="wp-block-image">
  <figure class="aligncenter size-full"><a href="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/latex-image-6.png"><img decoding="async" loading="lazy" width="592" height="50" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/latex-image-6.png" alt="" class="wp-image-10920" /></a></figure>
</div>

<p class="has-text-align-left">
  Nou kunnen wij die machten gebruiken, om verschillende waardes van geldbriefjes weer te geven! Dus, bijvoorbeeld, voor het geldbriefje met waarde 5 wordt de machtreeks
</p>

<div class="wp-block-image">
  <figure class="aligncenter size-full"><a href="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/latex-image-7.png"><img decoding="async" loading="lazy" width="554" height="45" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/latex-image-7.png" alt="" class="wp-image-10921" /></a></figure>
</div>

<p class="has-text-align-left">
  <em>Wat is blabla? Dat klinkt niet wiskundig!</em> Klopt, het staat in dit geval voor &#8220;dit gaat oneindig lang door&#8221;. En dat is vaak ook wat je wil, zij het niet dat ik geen oneindig aantal briefjes heb. Stel ik heb maar vier briefjes van vijf, dan moet ik de machtreeks na 4 termen afkappen:
</p>

<div class="wp-block-image">
  <figure class="aligncenter size-full"><a href="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/latex-image-8.png"><img decoding="async" loading="lazy" width="379" height="56" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/latex-image-8.png" alt="" class="wp-image-10922" /></a></figure>
</div>

<p class="has-text-align-left">
  * In dit geval heet het een <em>formele machtreeks</em>, just so you know. En, die 1 aan het begin van de machtreeks is wat er gebeurt als je 0 briefjes van 5 gebruikt, want elk getal tot de macht 0 is 1.
</p>

## La&nbsp;Toepassing!

Nu we dit weten, kunnen we iets heel leuks gebruiken om ons probleem in één klap op te lossen; we vermenigvuldigen al onze machtreeksen met elkaar!

_Waarom zouden we dat doen?_ Oké, stel je hebt twee briefjes van één, en twee briefjes van twee. Als we hun machtreeksen vermenigvuldigen, krijgen we

<div class="wp-block-image">
  <figure class="aligncenter size-full"><a href="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/latex-image-9.png"><img decoding="async" loading="lazy" width="483" height="48" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/latex-image-9.png" alt="" class="wp-image-10923" /></a></figure>
</div>

Versimpel:

<div class="wp-block-image">
  <figure class="aligncenter size-full"><a href="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/latex-image-10.png"><img decoding="async" loading="lazy" width="699" height="47" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/latex-image-10.png" alt="" class="wp-image-10924" /></a></figure>
</div>

Versimpel nog een keer:

<div class="wp-block-image">
  <figure class="aligncenter size-full"><a href="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/latex-image-11.png"><img decoding="async" loading="lazy" width="572" height="47" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/latex-image-11.png" alt="" class="wp-image-10925" /></a></figure>
</div>

Ofwel, we kunnen de waardes&nbsp;0, 1, 2, 3, 4, 5 en 6 maken met deze briefjes. Bovendien kunnen we de waardes 2&nbsp;en 4&nbsp;op twee manieren maken, want er staat een 2 voor.

_Klopt dit?&nbsp;_Jazeker, 2 kunnen we maken met één&nbsp;briefje van twee (2), of twee briefjes van één (1 + 1).&nbsp; Ook kunnen we 4 maken met twee&nbsp;briefjes van twee (2 + 2), of één briefje van twee plus twee&nbsp;briefjes van één (2 + 1 + 1).

## La&nbsp;Resultaten?

Het enige dat we moeten doen is heel veel verschillende combinaties briefjes afgaan, hiervoor de machtreeksen vermenigvuldigen, en checken welke het meeste mogelijkheden geeft.

Dit is waar de&nbsp;simpele theorie een beetje ophoudt, echter, en we maar beter de computer het verdere werk kunnen laten doen.

Opmerkingen:

  * Alle standaard bedragen in het&nbsp;spel zitten tussen de 0 en 10 euro. Met hoogstens 8 spelers, denk ik dat het redelijk is om aan te nemen dat ik alle mogelijke waardes tot 8 * 30 = 240 wil kunnen maken.
  * Door allerlei speciale omstandigheden of kaarten, kan een bedrag&nbsp;oplopen tot wel honderden euro&#8217;s. Ik neem dus aan dat ik&nbsp;met de geldbriefjes hoogstens&nbsp;8 * 500 = 4000 kan maken.
  * Ik kan, met het huidige ontwerp, 36 geldbriefjes op één A4-tje printen.&nbsp;Ik maak hier even de aanname dat ik niet&nbsp;meer&nbsp;dan 4 A4-tjes wil printen, dus we hebben in totaal 4 x 36 = 144 briefjes om te verdelen. Omdat de resultaten van het algoritme&nbsp;gewoon op te schalen zijn, ga ik hem runnen voor 14 briefjes (en dan de uitslag keer 10 doen).

De resultaten? De beste distributie van briefjes is:<figure class="wp-block-table">

<table>
  <tr>
    <td>
      <strong>Soort</strong>
    </td>
    
    <td>
      <strong>Hoeveelheid</strong>
    </td>
  </tr>
  
  <tr>
    <td>
      1 Euro
    </td>
    
    <td>
      43
    </td>
  </tr>
  
  <tr>
    <td>
      2 Euro
    </td>
    
    <td>
      33
    </td>
  </tr>
  
  <tr>
    <td>
      5 Euro
    </td>
    
    <td>
      20
    </td>
  </tr>
  
  <tr>
    <td>
      10 Euro
    </td>
    
    <td>
      10
    </td>
  </tr>
  
  <tr>
    <td>
      20 Euro
    </td>
    
    <td>
      3
    </td>
  </tr>
  
  <tr>
    <td>
      50 Euro
    </td>
    
    <td>
      3
    </td>
  </tr>
  
  <tr>
    <td>
      100 Euro
    </td>
    
    <td>
      26
    </td>
  </tr>
  
  <tr>
    <td>
      200 Euro
    </td>
    
    <td>
      6
    </td>
  </tr>
</table></figure> 

<!-- Java Results: [6, 6, 5, 2, 0, 2, 7, 0] -->

  
Hierbij moet ik vermelden dat de resultaten opschalen natuurlijk wel een beetje vals spelen is, aangezien&nbsp;we met gehele getallen werken.&nbsp;Stel je zou, met 140 briefjes, 5 briefjes van 100 moeten hebben, dan zou je bij 14 briefjes er 0.5 moeten hebben, en dat kan&nbsp;het algoritme niet. Dus ik heb het meerdere keren&nbsp;met verschillende hoeveelheden en instellingen gerund, en daarvan het gemiddelde genomen.

Vervolgens heb ik het afgerond naar beneden, en de paar briefjes die ik dan overhoud heb ik gegeven aan de 20 en 50 euro, aangezien die in elke simulatie letterlijk o keer werden gekozen. En dat is ook logisch, want ze zijn te groot om kleine bedragen gepast te betalen, maar te klein om echt grote bedragen te krijgen

Hierbij moet ik ook vermelden dat het algoritme heel zwaar is (aangezien er ongelofelijk veel mogelijkheden zijn om langs te gaan), dus bij nader inzien had ik het misschien niet in R moeten doen en het moeten optimaliseren, maar ach.

## Klopt dit wel?

Jup, voor mijn spel ziet het er logisch uit.&nbsp;Maar, met andere voorwaarden wordt het weer heel anders; Monopoly, bijvoorbeeld, werkt veelal met grotere bedragen (in de tienduizenden), dus daarbij zul je minder kleine briefjes krijgen en veel meer grote.

Ik hoop dat je er wel iets van hebt geleerd, en eventueel iets mee kan.&nbsp;En ik hoop dat ik heb laten zien dat wiskunde van tijd tot tijd toch nog redelijk nuttig kan zijn.

## De Code

Zie deze Google Drive folder: [Gepast Betalen (Simulatie)][1]

 [1]: https://drive.google.com/drive/folders/1RSj2DY9EClNm6TbOTEq9a6Ks0rIhdPPm?usp=sharing