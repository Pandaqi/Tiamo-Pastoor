---
title: Freds Wilde Wereld – Deel 2
author: hetisdepanda
type: post
date: 2017-03-22T17:20:47+00:00
url: /visuele-fratsen/freds-wilde-wereld-deel-2/
categories:
  - Crappy Cartoons
  - Visuele Fratsen

---
<img decoding="async" src="http://res.cloudinary.com/nietdathetuitmaakt/image/upload/v1493117346/Fred-WW-2.jpg" />