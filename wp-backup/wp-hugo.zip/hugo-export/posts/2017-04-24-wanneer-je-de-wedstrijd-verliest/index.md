---
title: Wanneer je de wedstrijd verliest
author: hetisdepanda
type: post
date: 2017-04-24T15:00:45+00:00
url: /toverende-taal/genezende-gedichten/wanneer-je-de-wedstrijd-verliest/
categories:
  - Genezende Gedichten

---
Niet als de tegenstander ongrijpbaar is  
Of de dag te lang, de nacht te bang  
Niet als je toestand onhoudbaar is  
Of de woede te groot, de liefde te dood  
Niet als een uitweg onvindbaar is  
Of het verdriet te zwaar, alle zekerheden niet waar  
Niet als de schoonheid onbedwingbaar is  
Of het lawaai te hard, je horizon zwart  
Maar wanneer je diep van binnen opgeeft  
En de weg van de minste weerstand kiest  
Je stiekem hoopt op een dramatisch, vluchtig einde  
Dat is wanneer je de wedstrijd verliest.