---
title: Al mijn harten
author: hetisdepanda
type: post
date: 2017-07-06T15:00:13+00:00
url: /toverende-taal/genezende-gedichten/al-mijn-harten/
categories:
  - Genezende Gedichten

---
Ik zing met al mijn stemmen  
tot ik in slaap val naast jou  
Als jij storende zaken terzijde schuift  
Je ziekte negeert, je zwakte wegwuift  
Zing ik met al mijn stemmen  
tot ik samen lig met jou

Ik zie met al mijn ogen  
een onverstoorde horizon met jou  
Als jij ongeloof en onraad ziet  
De ochtend overslaat, ondanks de onzin geniet  
Zie ik met al mijn ogen  
een oneindig overblijven met jou

Ik hou met al mijn harten  
tot in de eeuwigheid van jou  
Als jij handen ten hemel heft  
Je hoofd neerslaat, de harde waarheid treft  
Hou ik met al mijn harten  
tot het einde van jou