---
title: Zomers zonder Zorgen
author: hetisdepanda
type: post
date: 2017-05-24T15:00:49+00:00
url: /toverende-taal/genezende-gedichten/zomers-zonder-zorgen/
categories:
  - Genezende Gedichten

---
Ik kan me zomers herinneren  
zomers zonder zorgen  
waar je ’s ochtends vroeg de tuin in rent  
de voetbal ligt al klaar  
waar je ’s middags de tv aanzet  
een grote wielerronde daar  
waar je ’s avonds lekker buiten zit  
genieten van de zomerzon  
en ’s nachts mooie liedjes speelt  
in het gras op de gitaar

Ik kan me zomers herinneren  
waar de wereld even  
heel even  
een beetje beter werd  
heel even  
een beetje mooier werd  
heel even  
een beetje lichter werd

Ik kan me zomers herinneren  
anders dan de tegenwoordige tijd  
Zonder geweld, weer een aanslag  
zonder verdriet, zonder spijt  
Zonsondergang betekende  
morgen weer een mooie dag  
Maar nu is er slechts angst  
een onderdrukte zomerlach