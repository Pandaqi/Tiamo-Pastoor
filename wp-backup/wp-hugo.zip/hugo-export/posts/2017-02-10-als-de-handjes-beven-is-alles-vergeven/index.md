---
title: Als de handjes beven, is alles vergeven
author: hetisdepanda
type: post
date: 2017-02-10T22:20:40+00:00
url: /gewoon-een-gedachte/als-de-handjes-beven-is-alles-vergeven/
categories:
  - Gewoon een Gedachte

---
Van nature reageren onze lichamen goed op kou. Als wij in de winter naar buiten stappen terwijl het sneeuwt, gaat ons lichaam z&#8217;n best doen om zichzelf op de juiste warmte te houden. Natuurlijk helpen die duizend lagen kleding en dikke handschoenen ook mee, maar zelfs die kunnen niet alles tegenhouden. Dit regelen van de warmte gaat via bloed, en vaak is ons bovenlichaam en hoofd dan ook goed verwarmt, terwijl onze handen en voeten af lijken te sterven.

En dit is erg vervelend. Wat zeg ik? Het is verschrikkelijk! Regelmatig zit ik gewoon lekker thuis wat aan school te typen op mijn laptop, en dan wil ik eventjes piano gaan spelen, zijn mijn handen te bevroren om fatsoenlijk een akkoord te spelen. Of ik ga naar de supermarkt, ik wil mijn pinpas in het apparaat duwen, trillen mijn handen helemaal en duw ik hem er eerst drie keer naast. (Om hem vervolgens wel goed er in te duwen, maar een error te krijgen dat het apparaat de kaart niet kan lezen. Blijkbaar moet je in één keer met precies de juiste kracht mijn kaart er in beuken, anders lukt het niet.)

<!--more-->

Misschien nog vervelender, ik ben regelmatig (in de koudere maanden) op school gekomen om de eerste uren een tentamen te maken, om vervolgens het eerste halfuur niet te kunnen schrijven vanwege mijn bevroren handen.

Het eerste dat ik probeerde was natuurlijk mijn handen blijven bewegen. Op de fiets, tijdens het werk, de hele tijd mijn handen blijven gebruiken. Werkt dat? Een beetje, maar het kost veel moeite en mensen denken dat je gek bent omdat je de hele tijd met je handen zit te wapperen. Dus dan probeer ik mijn handen maar warm te houden door ze tegen zachte en/of warme dingen aan te drukken, maar het is toch lastig gitaarspelen met je hand tegen een kop warme chocomel gedrukt. (Of met je handen onder een knuffel.)

Dus dan moet je al snel overstappen op een meer rigoureuze aanpak. Ik bedoel, er moet toch een reden zijn dat dit gebeurd, zowel bij mij als bij vele andere mensen die ik de hele dag met blauwe of soms wel paarse handen zie? De fysiotherapeut zegt natuurlijk meteen: de bloedsomloop is niet goed! Dus ik kreeg oefeningen mee om mijn schouders los te maken, rechtop te zitten, mijn armen en handen sterker te maken, et cetera. Dit is allemaal leuk en aardig, maar ook dit lost weinig op. Natuurlijk is het goed om een juiste houding te hebben en je lichaam zo sterk mogelijk te maken, maar schouders kunnen niet losser dan los, en ruggen niet rechter dan recht, en er valt weinig te doen aan dat bloed nou eenmaal koud is als het je handen bereikt.

_Niks aan te doen?_ bromt de psycholoog. Nu zou het ineens allemaal aan stress, of angst, of nervositeit liggen. Van stress raakt je lichaam gespannen, gaat alle warmte naar de belangrijkste organen (en dat zijn gek genoeg niet je handen), beginnen je handen te trillen en warmte te verliezen door te zweten. Dus dat kan, maar het lijkt me sterk dat de halve bevolking altijd gestrest is, zelfs als ze lekker thuis op de bank films zitten te kijken.

Dus er blijft maar één optie over, jammer genoeg: het zit in het DNA. Niks aan te doen, vette pech. Vroeger zouden mensen met bevroren handen moeite hebben met overleven, maar tegenwoordig bestaan handschoenen, en zijn sterke en grote handen niet meer essentieel voor het overleven, dus verschijnen er overal mensen met deze afwijking het DNA. En dan is er weinig aan te doen &#8211; voor nu, in ieder geval. (Al lijkt het me niet de prioriteit om het DNA dat koude handen veroorzaakt aan te gaan passen, mochten we ooit de technologie krijgen om DNA te veranderen in levende mensen.)

Dus het enige dat je kan doen, is er je sterke punt van maken. Misschien kun je zelfs wel tegen iedereen zeggen dat je handen alleen warm worden van knuffels geven, en zo gratis knuffels met iedereen incasseren. Of je zegt dat alleen een kop warme chocomel helpt, en hoopt dat iedereen een warm kopje voor je koopt. Of je kunt er gewoon een grapje over maken als je met iemand praat. Of als openingszin gebruiken als je een leuk iemand ontmoet. (&#8220;Ik heb altijd koude handen, en er is maar één ding dat daar tegen helpt &#8230; &#8221; En dan mag jij beslissen hoe je die zin afmaakt. &#8220;Jouw lach&#8221; of &#8220;jouw prachtige ogen&#8221; of &#8220;jouw warmte&#8221; is aardig, &#8220;jouw warme lichaam&#8221; is misschien risky, &#8220;met jou in bed liggen&#8221; gaat denk ik een grens over. Maar ik zou het niet weten, want ik heb het nooit geprobeerd.)