---
title: De Dierenbandiet
author: hetisdepanda
type: post
date: 2018-11-02T14:12:00+00:00
url: /gewoon-een-gedachte/de-dierenbandiet/
categories:
  - Gewoon een Gedachte

---
Ik heb weer eens een kaartspelletje gemaakt! De spelregels lagen er al een tijdje, maar ik vond ze te ingewikkeld (en niet leuk genoeg), waardoor het spel maandenlang niet verder werd ontwikkeld. Eergisteren, echter, las ik de spelregels terug, paste wat cruciale dingen aan, testte het uit, en ineens werkte het best wel goed.

Om het spel mooi af te maken heb ik gister de hele dag schattige dierenkaartjes lopen tekenen, waardoor ik nu klaar ben om het spel online te zetten. (Ik dwong mezelf alles in één dag te tekenen, want ik moest eigenlijk belangrijkere dingen te doen. Uiteindelijk is het verrassend goed gelukt.)<figure class="is-layout-flex wp-block-gallery-45 wp-block-gallery columns-4">

<ul class="blocks-gallery-grid">
  <li class="blocks-gallery-item">
    <figure><a href="https://nietdathetuitmaakt.nl/gewoon-een-gedachte/de-dierenbandiet/attachment/dierenbandiet-panda_result/"><img decoding="async" loading="lazy" width="756" height="1051" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/11/Dierenbandiet-Panda_result.webp" alt="" data-id="8037" data-full-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/11/Dierenbandiet-Panda_result.webp" data-link="https://nietdathetuitmaakt.nl/gewoon-een-gedachte/de-dierenbandiet/attachment/dierenbandiet-panda_result/" class="wp-image-8037" /></a></figure>
  </li>
  <li class="blocks-gallery-item">
    <figure><a href="https://nietdathetuitmaakt.nl/gewoon-een-gedachte/de-dierenbandiet/attachment/dierenbandiet-eenhoorn_result/"><img decoding="async" loading="lazy" width="756" height="1051" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/11/Dierenbandiet-Eenhoorn_result.webp" alt="" data-id="8035" data-full-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/11/Dierenbandiet-Eenhoorn_result.webp" data-link="https://nietdathetuitmaakt.nl/gewoon-een-gedachte/de-dierenbandiet/attachment/dierenbandiet-eenhoorn_result/" class="wp-image-8035" /></a></figure>
  </li>
  <li class="blocks-gallery-item">
    <figure><a href="https://nietdathetuitmaakt.nl/gewoon-een-gedachte/de-dierenbandiet/attachment/dierenbandiet-draak_result/"><img decoding="async" loading="lazy" width="756" height="1051" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/11/Dierenbandiet-Draak_result.webp" alt="" data-id="8034" data-full-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/11/Dierenbandiet-Draak_result.webp" data-link="https://nietdathetuitmaakt.nl/gewoon-een-gedachte/de-dierenbandiet/attachment/dierenbandiet-draak_result/" class="wp-image-8034" /></a></figure>
  </li>
  <li class="blocks-gallery-item">
    <figure><a href="https://nietdathetuitmaakt.nl/gewoon-een-gedachte/de-dierenbandiet/attachment/dierenbandiet-bandiet_result/"><img decoding="async" loading="lazy" width="756" height="1051" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/11/Dierenbandiet-Bandiet_result.webp" alt="" data-id="8033" data-full-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/11/Dierenbandiet-Bandiet_result.webp" data-link="https://nietdathetuitmaakt.nl/gewoon-een-gedachte/de-dierenbandiet/attachment/dierenbandiet-bandiet_result/" class="wp-image-8033" /></a></figure>
  </li>
</ul></figure> 

Het spel heet&nbsp;**De Dierenbandiet**. In dit spel probeert iedereen de&nbsp;_eenhoorn_ te vinden en vervolgens uit de stad te smokkelen. Men begint met slechts een paar konijnen in de hand en moet door slim te kopen/verkopen op de markt meer waardevolle diersoorten zien te verkrijgen. Klinkt simpel, maar nu komt het echte werk: tussen de spelers worden geheime smokkelstapels heen en weer geschoven. Niet alleen moet jij slim zijn met welke kaarten je bij de stapels legt en welke je in de hand houdt, je moet ook opletten dat niet iemand anders plotseling jouw smokkelstapel met de eenhoorn ontvangt! Kortom: veel nadenken, een beetje geluk, en een hoop schattige dieren.

Zoals altijd is het hele spel (de kaarten die je kunt printen en zelf uitknippen) inclusief spelregels te vinden op de bijbehorende pagina: [De Dierenbandiet [spel]][1]

 [1]: http://nietdathetuitmaakt.nl/bordspellen/de-dierenbandiet/