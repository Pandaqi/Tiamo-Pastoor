---
title: Veel gebeurd
author: hetisdepanda
type: post
date: 2017-08-24T16:00:31+00:00
url: /toverende-taal/genezende-gedichten/veel-gebeurd/
categories:
  - Genezende Gedichten

---
Wat is er veel gebeurd  
wat is er vreselijk veel gebeurd  
sinds die dag dat ik je  
niet meer sprak  
en vanaf toen het echt binnendrong  
nooit meer sprak

Wat is er veel gebeurd  
wat is er ongelooflijk veel gebeurd  
sinds die dag dat  
het jaar weer begon  
en nu het einde weer nadert  
weet ik niet meer waarom

Waarom is er zoveel gebeurd  
zo onbegrijpelijk veel gebeurd  
maar kan ik niet herinneren wat  
ik al die tijd heb gedaan  
en zal ik weer met lege handen  
aan het begin van een nieuw jaar staan

Wat is er veel gebeurd  
wat is er verschrikkelijk veel gebeurd  
veel onnodigs ook  
dat vrees ik nog het meest  
dat al die energie, pijn en leed  
uiteindelijk voor niets is geweest