---
title: Theo toch
author: hetisdepanda
type: post
date: 2017-02-18T15:00:12+00:00
url: /toverende-taal/aardige-anekdotes/theo-toch/
categories:
  - Aardige Anekdotes

---
Ik kom regelmatig in het theater. Ook al gebeurt het niet zo vaak als in bijvoorbeeld Amsterdam, soms kom ik daar een bekende tegen. En dan niet een oude vriend of kennis, maar een bekende Nederlander.

Dat is op zich niet raar, want die mensen gaan natuurlijk ook graag met hun gezin naar voorstellingen, zeker als ze zelf uit de theaterwereld komen. Maar waar ik nooit zo bij stil heb gestaan, is hoe vervelend dat wel niet moet zijn, en dat bekende Nederlanders het ook niet schromen om dat te laten blijken.

<!--more-->

Laatst liep ik uit de zaal na een voorstelling, en pardoes voor ons liep Theo Maassen (met aanhang). Ik zie dat dan, en ik vind het grappig, maar ik heb geen intentie om hem aan te spreken (want, sowieso, waar zou ik het over moeten hebben?) Maar een andere man had dat wel. Die stapte naar hem toe, stak zijn hand uit, en zei: &#8220;als ik me niet vergis ben jij Theo Maassen, mag ik &#8211; &#8221;

&#8220;Nee, nee, nee, nee &#8230;&#8221;, reageerde Theo, en hij liep hoofdschuddend weg. De man bleef met grote verbijstering (en nog steeds uitgestoken hand) achter, Theo besloot een verdieping lager de rust op te zoeken.

Ik weet niet of dit de meest correcte of aardige respons is op iemand die je wil ontmoeten, maar ik kan het wel begrijpen. Laat het bij deze een les zijn: spreek gerust een bekende Nederlander aan, maar alleen als die alleen is of er uit ziet alsof ze klaar staat voor een paartje. (Dit zeg ik ook om mezelf in te dekken, mocht ik ooit enigszins bekendheid verwerven. Ik denk het niet, maar een man mag dromen.)