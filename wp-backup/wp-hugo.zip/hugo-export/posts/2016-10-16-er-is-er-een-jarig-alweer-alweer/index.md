---
title: Er is er één jarig, alweer, alweer
author: hetisdepanda
type: post
date: 2016-10-16T09:05:53+00:00
url: /gewoon-een-gedachte/er-is-er-een-jarig-alweer-alweer/
categories:
  - Gewoon een Gedachte

---
Er is altijd wel weer iemand jarig. Zo is er, als je in een groep van 23 mensen staat, meer dan 50% kans dat er mensen zijn die dezelfde verjaardag delen.<sup><a href="https://nl.wikipedia.org/wiki/Verjaardagenparadox">[1]</a></sup> Maar, wat nog erger is, is dat de kans natuurlijk groter is dat mensen vlak na elkaar jarig zijn. Zo zijn twee personen in mijn gezin de dag na elkaar jarig, of ben ik een paar dagen voor een vriend van mij jarig. Als je dat allemaal bij elkaar neemt &#8211; gezin, familie, vrienden, studiegenoten, etcetera &#8211; is er altijd wel iemand jarig. En dat is vervelend.

Want wie heeft er tijd voor al die verjaardagen? Ik in ieder geval niet. Ik vind het hartstikke fijn voor iemand als ie jarig is, maar het is nou niet echt een prestatie. Als iemand jarig is wordt er in principe gevierd dat diegene een aantal jaar geleden op die dag is geboren. Terwijl, wat ik een veel grotere reden voor festiviteiten vindt, is als iemand iets groots heeft bereikt. Zoals, bijvoorbeeld, haar eerste huis gekocht, of de eerste grote baan, of een succesvolle verhuizing na jarenlang gedoe en problemen, of het eindelijk afmaken en uitbrengen van een computerspel waar iemand al jaren aan heeft gewerkt.

<!--more-->

Dat zijn dingen om te vieren. Verjaardagen niet. Maar, omdat het vrij makkelijk is om te zien of achterhalen dat iemand jarig is, en omdat het een feest is dat iedereen kent (want ze hebben het zelf ook), is het alom de gewoonte om zo iemand dan te feliciteren. En als je de persoon enigszins kent, voel je je stiekem een beetje verplicht een cadeau te geven, of een kaartje te sturen, of in ieder geval meer aandacht er aan te besteden. Het gevolg is dat je veel tijd en energie kwijt bent aan onzin kopen en doen voor mensen (want ja, voor vijf á tien euro kun je ook niks fatsoenlijks kopen), en niemand is er iets mee opgeschoten.

Natuurlijk, het is fijn als mensen aardig tegen je zijn en je dingen geven. Maar ik heb liever dat mensen het hele jaar aardig tegen elkaar zijn. En dat mensen gewoon zomaar iets doen voor een ander, of zomaar iets geven. En als je dan een cadeau geeft op iemands verjaardag, gooi dan gezamenlijk geld in een pot en koop iets waar die persoon écht iets aan heeft.

En nu denk je misschien: _ja, maar dit zijn de bittere woorden van iemand die altijd in de vakantie jarig is, en niks krijgt!_ Dat klopt, hoe raad je het?! Maar dat heeft er natuurlijk niks mee te maken. Ik heb liever dat mensen mij niet feliciteren, mij niks geven en niks speciaals doen op mijn verjaardag, als dat betekent dat ik gewoon de rest van het jaar een fijne tijd heb.

Mochten mijn woorden aanslaan, en steeds meer mensen besluiten te stoppen met de neppe verjaardag-onzin, weest niet bevreesd, verjaardagvierder. Je kunt altijd nog gewoon iets bereiken in je leven en dan daar een feest over geven. (Wacht maar, ik ga een partij oprichten. De Partij Inzage Regelrechte Aversie Alle Troepfeesten. En ongeacht het aantal stemmen dat ik krijg neem ik maar één plek in &#8211; de verjaardagszetel.)