---
title: De Konijnenklas!
author: hetisdepanda
type: post
date: 2021-01-05T16:00:30+00:00
url: /gewoon-een-gedachte/de-konijnenklas/
categories:
  - Gewoon een Gedachte

---
<div class="wp-block-image">
  <figure class="alignright size-large is-resized"><a href="https://nietdathetuitmaakt.nl/wp-content/uploads/2020/12/Voorkant-jpg_result.webp"><img decoding="async" loading="lazy" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2020/12/Voorkant-jpg_result.webp" alt="" width="288" height="408" /></a></figure>
</div>

Eindelijk is hij daar: mijn tweede prentenboek!

Voor all informatie, bezoek de officiële pagina:&nbsp;[**De Konijnenklas (Prentenboek)**][1] (Deze bevat ook de link naar het boek in webwinkels, uitleg hoe ik het heb gemaakt, mijn ervaringen met self-publishen, en nog wat meer.) 

Hieronder geef ik een korte samenvatting over het boek en waarom ik het (op deze manier) heb gemaakt.

Het boek heet **De Konijnenklas** en gaat, niet geheel verrassend, over een klas konijnen.

Je volgt de meester en zijn leerlingen op een avontuur op zoek naar de _passievrucht_. Waarom? De meester is zijn passie voor lesgeven kwijt en de leerlingen hun passie voor leren. Samen ontdekken ze tijdens het avontuur waarom het handig is om sommige dingen te weten, wat er zo mooi is aan nieuwe dingen leren, ga zo maar door. En aan het einde ontdekken ze nog iets anders &#8230;

Wie dit blog veel leest, weet dat ik _onderwijs_ hoog heb zitten. Daarom ben ik eindeloos gefrustreerd dat ons huidige onderwijssysteem totaal inadequaat is en jongeren eigenlijk weinig (nuttigs) leert.

In dit boek wilde ik docenten een middel geven om kinderen uit te leggen wat &#8220;werkdruk&#8221; is, hoe een docent soms ook even erdoorheen zit, of fouten kan maken. Hoe een docent jou het beste les kan geven, als je zelf ook iets teruggeeft aan de docent. (_Niet_ als je de docent ziet als een strenge volwassene waarnaar je sowieso moet luisteren.)

Het zijn, echter, tijden van Coronacrisis. We zien nu overal de gevolgen van de sluiting van (basis)scholen, en, nu ik dit schrijf, zijn ze natuurlijk wéér net dichtgegaan. Dit verhaal is net zozeer een opsteker voor kinderen, om hen te herinneren hoe belangrijk het is om jezelf dingen te blijven leren, en waar je die kennis zoal voor kan gebruiken.

Natuurlijk is dit in een avontuurlijk jasje gestoken, met een subtiele tweede laag, en een kort rijmend verhaal over mooie plaatjes. Het moet wel leuk blijven! Een spannend, interessant, mooi verhaal heeft bij mij altijd de voorkeur boven een eventuele &#8220;boodschap&#8221;.

Hopelijk kan dit verhaal zowel volwassenen als kinderen aanspreken en inspireren!

 [1]: https://nietdathetuitmaakt.nl/boeken/de-konijnenklas