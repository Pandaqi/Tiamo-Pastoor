---
title: Composition in F Minor
author: hetisdepanda
type: post
date: 2018-09-20T12:52:12+00:00
url: /gewoon-een-gedachte/composition-in-f-minor/
categories:
  - Gewoon een Gedachte
  - Muzikale Meesterwerken

---
<div id="attachment_7975" style="width: 310px" class="wp-caption alignright">
  <a href="http://nietdathetuitmaakt.nl/wp-content/uploads/2018/09/Tiamo-Album-Cover_result.webp"><img aria-describedby="caption-attachment-7975" decoding="async" loading="lazy" class="wp-image-7975 size-medium" src="http://nietdathetuitmaakt.nl/wp-content/uploads/2018/09/Tiamo-Album-Cover-300x300.png" alt="" width="300" height="300" /></a>
  
  <p id="caption-attachment-7975" class="wp-caption-text">
    Album cover voor Composition in F Minor
  </p>
</div>

Ik heb een instrumentaal album gemaakt. Het is geen officiële uitgave via een producer of iets, maar slechts een manier om mijn nummers vast te leggen (en heel veel te oefenen met muziek mixen). Desondanks vind ik het goed klinken en ben ik er wel trots op!

Het hele album staat op Bandcamp: [Composition in F Minor][1]

(Het is gratis te beluisteren. Downloaden kost geld. Bandcamp wil namelijk niet dat mensen almaar gratis hun nummers erop gaan zetten, want ze verdienen alleen als je het verkoopt, dus ik had geen keus. Als ik het gratis downloadbaar maak kunnen maar 200 mensen maandelijks het album bezoeken. Het is jammer, maar zo is de wereld :p)

Daarnaast heb ik een hele pagina geschreven over wat het album inhoudt, het proces, waarom ik het heb gedaan, welke kanttekeningen/opmerkingen/verbeterpunten ik zelf nog heb, en leuke verhaaltjes over de totstandkoming van nummers. Deze pagina is hier te vinden: [[Album] Composition in F Minor][2]

 [1]: https://tiamo.bandcamp.com/album/composition-in-f-minor
 [2]: http://nietdathetuitmaakt.nl/album-composition-in-f-minor/