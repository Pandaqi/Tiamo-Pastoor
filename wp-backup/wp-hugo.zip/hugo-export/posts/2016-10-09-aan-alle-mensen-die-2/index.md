---
title: Aan alle mensen die…
author: hetisdepanda
type: post
date: 2016-10-09T15:00:08+00:00
url: /gewoon-een-gedachte/aan-alle-mensen-die-2/
categories:
  - Gewoon een Gedachte

---
&#8230;niet hun vuile vaat afspoelen, maar het wel gewoon in de vaatwasser pleuren of bovenop andere rotzooi stapelt.

Dat werkt niet. Je schuift problemen af op andere mensen, en je laat de hele vaatwasser vastlopen, omdat je te lui bent om drie seconden een kraan te laten lopen over je bord. Het is alsof je je fiets niet in het fietsenrek zet als je op school komt, maar gewoon horizontaal bovenop vijf andere fietsen legt. Of alsof het buiten keihard regent, en jij gaat met een emmer naar buiten om de regen op te vangen, en loopt vervolgens naar binnen en gooit daar de hele boel nat.

<!--more-->

Je maakt het leven onnodig lastiger. Hetzelfde geldt voor mensen die dingen verkeerd opstapelen. Je kunt niet zeven glazen borden bovenop een veel kleiner bord met bestek er op leggen &#8211; dat valt sowieso om en je mooie servies is foetsie. Maar het geldt niet alleen voor vaat, het geldt voor alles. Je kunt geen stapel boeken bovenop iemands laptop leggen. Je kunt de gitaar niet ondersteboven achter de kast wegstoppen, al zit er nog een hoes omheen.

Ga goed om met spullen, ruim ze op, hou ze schoon. Maar ga zeker goed om met andermans spullen, en val ze niet lastig met je eigen rommel. Een snelle schoonmaak a day keeps the problems away, zeg ik altijd maar.

(Grapje natuurlijk, ik weet ook wel dat schoonmaak geen Engels is. Het moet natuurlijk zijn &#8220;A quicky cleanmake a day, keeps the problems away&#8221;.)