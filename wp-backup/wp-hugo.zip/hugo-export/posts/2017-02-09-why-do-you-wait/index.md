---
title: Why do you wait?
author: hetisdepanda
type: post
date: 2017-02-09T15:00:54+00:00
url: /toverende-taal/genezende-gedichten/why-do-you-wait/
categories:
  - Genezende Gedichten

---
What do you hear?  
A chirping bird?  
A friendly word?  
A sleeping city, free from fear

What do you see?  
A bright paradise?  
A face full of lies?  
A worried friend, down on her knee

What do you feel?  
A brewing anger?  
A hand to lend her?  
A locked-up heart, too hard to steal

Why do you wait?  
A growing doubt?  
A different way out?  
Maybe too early, maybe too late

Why don’t you try?  
Outcomes you don’t know?  
Think you still need to grow?  
Try to go to bed,  
without regret,  
every night