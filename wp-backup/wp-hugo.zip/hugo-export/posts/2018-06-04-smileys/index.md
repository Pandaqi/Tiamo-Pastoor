---
title: Smileys, emoticons en andere gedrochten
author: hetisdepanda
type: post
date: 2018-06-04T12:34:43+00:00
url: /gewoon-een-gedachte/smileys/
categories:
  - Gewoon een Gedachte
  - Toverende Taal

---
De laatste jaren ontstaat een almaar groeiende kloof in de samenleving. Aan de ene kant heb je de mensen die vaker een smiley gebruiken dan een letter van het alfabet, aan de andere kant waarschuwen mensen voor de typografische horror en verachten ze elke tekst met een smiley.

(Een derde groep schreeuwt: &#8220;Het heet alleen een smiley als hij lacht! Anders is het een emoticon!&#8221;)

Om alle groepen blij te maken noem ik smileys, emoticons, en eigenlijk elke visuele of typografische constructie die een emotie aangeeft: **emoticoontje**. (Ik heb daarmee vast een vierde groep boos gemaakt door een Engels en Nederlands woord samen te voegen.)

## Het Probleem

Er zijn meerdere aanklachten tegen emoticoontjes:

<!--more-->

  * Ze zijn vaak lelijk (wanneer naast normale tekst geplaatst) en onderbreken de flow. 
      * Op diezelfde manier vind ik het vervelend als mensen slashes ( / ) of vierkante haakjes ( [ ] ) gebruiken in een tekst. Het is een verticaal symbool, en staat dus loodrecht op de leesrichting (van links naar rechts, ofwel horizontaal), wat de leesbaarheid doet haperen.
  * Ze worden teveel gebruikt. 
      * Als jij vijf lachende poppetjes achter je bericht plaatst, noem ik dat gewoon inefficiënte communicatie.
      * Daarnaast, als je praat over muziek, is het dan echt nodig om er drie muzieknootjes achter te plaatsen?
  * Ze worden verkeerd of onhandig gebruikt. 
      * &#8220;Ik voel me zo slecht. Had ik gister echt niet door dat ik in mijn ondergoed stond? Wie heeft me allemaal gezien?! Ik durf echt nooit meer op school te komen :(&#8221;  
        &#8220;Haha jij stond zo voor schut xD&#8221; (of, deze zie je ook wel eens &#8220;Haha jij stond zo voor schut :D&#8221;)
  * De bedoeling van je zin zou uit de inhoud of de context duidelijk moeten zijn. (Met andere woorden: het is lui om emoticoontjes te gebruiken.) 
      * Vergelijk het met het schrijven van een boek. Dit soort zinnen mogen dan echt niet: &#8220;Nee je jurk is echt prachtig,&#8221; zei Hans _op sarcastische wijze_.

Het algemeen aanvaarde idee is dat emoticoontjes **absoluut verboden** zijn buiten privéberichtjes om. Krantenartikelen, boeken, wetenschappelijke verslagen, et cetera mogen nooit een emoticoontje bevatten.

Anders krijgen we nieuwsberichten zoals dit:

<p style="padding-left: 30px;">
  &#8220;Honderd mensen dood door ingestort gebouw Mexico <strong>🙁</strong>&#8220;
</p>

<p style="padding-left: 30px;">
  Gisteren gebeurde een ramp <strong>😮 </strong>
</p>

<p style="padding-left: 30px;">
  Een gebouw, gevuld met medewerkers van het bedrijf TacoTaco (<strong>xD</strong>) stortte in, waarbij honderd stierven <strong>:'( </strong>
</p>

<p style="padding-left: 30px;">
  De brandweer was snel ter plekke, maar was vergeten water mee te nemen <strong>-.</strong><strong>&#8211; </strong>
</p>

<p style="padding-left: 30px;">
  De lokale burgemeester reageerde: &#8220;tja, ons plan om het bedrijf uit te breiden valt nu wel een beetje in het water <strong>:p</strong>&#8220;
</p>

Op zich niks mis mee om emoticoontjes te verbannen, toch?

## Het Tegenargument

Eigenlijk het enige tegenargument gaat als volgt:

<p style="padding-left: 30px;">
  Mensen hebben lichaamstaal en context nodig om communicatie te interpreteren en de juiste betekenis te geven. Als wij alleen geschreven tekst lezen, weten we niet zeker welke emotie of intentie de schrijver ermee wilde overbrengen. Emoticoontjes lossen dit op door een zin emotionele waarde te geven.
</p>

En ik vind dit een sterk tegenargument. Talloze keren heb ik een zin geschreven waarvan ik van tevoren wist: &#8220;als ik hier niet de juiste emotie aan vastplak, kan hij wel eens heel anders (en heel vervelend) vallen&#8221;.

Op dit blog besloot ik dan ook bij de oprichting om een kleine hoeveelheid emoticoontjes toe te laten. Ik weet zeker dat sommige lezers me meteen wegzetten als kinderachtig, of het als een minpunt zien, maar in mijn ogen voegt het juist veel toe aan een tekst. Het zorgt voor minder miscommunicatie, efficiëntere communicatie, en vaak ook een luchtigere toon.

Dus, dit artikel schrijf ik eigenlijk om gelimiteerd gebruik van emoticoontjes, in welke tekst dan ook, te verdedigen.

Neem bijvoorbeeld de zin: &#8220;de hond is dood&#8221;. De context ervan wordt heel anders als je er een verschillend emoticoontje achter plakt:

  * **De hond is dood 🙁** 
      * Ach, wat zielig. Peters lievelingshond is gisteren gestorven van ouderdom.
  * **De hond is dood xD** 
      * Je speelt een computerspel waar je al dagenlang probeert om een monsterlijke hond te verslaan. Eindelijk, na veertig pogingen, kan je met toepasselijke absurditeit je vriend berichten dat de hond dood is.
  * **De hond is dood -.-** 
      * Je werd net in het park aangevallen door een wilde bulldog. Je vertelt het hele verhaal aan je vriend, die een gevoelloze opmerking maakt als &#8220;ha, toen heb je die hond zeker een pak slaag gegeven?&#8221;. Daarop reageer jij: &#8220;dude, de hond is dood -.- de politie moest hem taseren en dat werd hem te veel.&#8221;
  * **De hond is dood 🙂** 
      * Je bent een crimineel en wilt inbreken bij een geldkluis. Jammer genoeg wordt hij bewaakt door een hond. Na vele pogingen en experimenten heb je hem eindelijk weten te verwijderen. Je bericht je baas vrolijk: &#8220;de hond is dood :)&#8221;
  * (Een alternatief is dat &#8220;de hond is dood&#8221; codetaal is voor &#8220;ons doelwit is uitgeschakeld&#8221;, en welk emoticoontje erna volgt bepaald hoe succesvol de ontsnapping was. &#8220;De hond is dood ^^&#8221; betekent dat de president is neergeschoten en de ontsnapping vlekkeloos verliep.)

## Het juiste soort emoticoontje

Ondanks het sterke tegenargument, moeten we niet al die nadelen van emoticoontjes negeren. Waar mogelijk, probeer duidelijk te zijn in je communicatie door de juiste woorden te kiezen. (In plaats van een smiley achter een bericht plakken, kun je ook vrolijke woorden kiezen.) Beperk je daarnaast tot enkele emoticoontjes waarvan de betekenis redelijk duidelijk en wijdverspreid bekend is.

De belangrijkste regel, echter, is: **geen plaatjes.** 

Ten eerste verschillen de plaatjes per app of platform. Ik heb vaak genoeg een heel ander emoticoontje ontvangen dan die ander wilde sturen. (&#8220;Eh, waarom staan er drie dansende bananen achter je verzoek om samen te werken aan het volgende project?&#8221;)

Daarnaast zorgt het bij mij altijd voor irritatie, omdat het de leesbaarheid van tekst drastisch verlaagd. Het breekt de tekst op, is vaak niet precies even hoog of breed als de letters, en dwingt je om te switchen tussen &#8220;letters interpreteren&#8221; en &#8220;plaatjes interpreteren&#8221;. Het is een beetje alsof je een verhaal probeert te lezen en de helft van de zinnen is vervangen door een rebus.

Als je een emoticoontje gebruikt, hanteer dan de simpelste typografische variant.

<p style="padding-left: 30px;">
  Dingen als<strong> &#8220;:p&#8221;</strong> en <strong>&#8220;:)&#8221;</strong> en <strong>&#8220;:(&#8220;</strong> zijn duidelijk.
</p>

<p style="padding-left: 30px;">
  Dingen als <strong>&#8220;:^))&#8221;</strong> en<strong> &#8220;S)&#8221;</strong> en <strong>&#8220;*>*&#8221;</strong> is vragen om problemen.
</p>

Hopelijk hebben mensen hier iets aan.