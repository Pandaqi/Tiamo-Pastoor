---
title: Een Muzikaal Feest-Experiment (Kerst)
author: hetisdepanda
type: post
date: 2017-12-23T16:00:21+00:00
url: /muzikale-meesterwerken/muzikaal-feest-experiment-kerst/
categories:
  - Muzikale Meesterwerken

---
Kerstliedjes hebben allemaal datzelfde &#8220;Kerstmis-gevoel&#8221; om zich heen hangen. Als je een nummer hoort, kun je vaak meteen zeggen of het een kerstnummer is of niet, zonder ook maar één woord van de tekst mee te krijgen.

Natuurlijk, als je veelvuldig kerstbellen hoort rinkelen, of een engelenkoor &#8220;aaah&#8221; hoort produceren, is de ware aard van het nummer vrij snel verraden. Maar toch zijn er een aantal andere elementen die een kerstliedje een _kerstliedje_ maken. Daar wilde ik eens naar kijken.

P.S. Als je alleen geïnteresseerd bent in het eindresultaat, scroll dan snel naar het einde.

P.P.S. Ik ga het niet echt hebben over de klassieke (kerk)kerstnummers. &#8220;Oh Dennenboom&#8221; en &#8220;Jingle Bells&#8221; en de rest zijn niet bijzonder interessant.

## Jazz

Waar moet je aan denken bij kerst? Haardvuur? Lekker warm tegen de verwarming zitten? Gezelligheid? Mooie lichtjes? Warme truien? Chocomel? Eigenlijk is Kerst het grote feest van &#8220;we gaan het binnen zo comfortabel mogelijk maken, want buiten laat het weer ons in de steek&#8221;. En welke muzieksoort zorgt ervoor dat je lekker wilt liggen en nooit meer opstaan? Precies, **Jazz**.

<!--more-->

En waar staat **Jazz** bekend om? Exotische akkoorden! In plaats van een standaard &#8220;C &#8211; G &#8211; Am &#8211; F&#8221; akkoordenschema, doet jazz eerder iets als &#8220;C &#8211; G7 &#8211; C &#8211; C7 &#8211; F &#8211; Dm7b5 &#8211; enzovoort&#8221;. Dit soort akkoorden voegen een soort warmte en breedte toe aan de klank van een nummer. Het enige probleem is dat ze moeilijk bij een melodie te passen zijn, zonder dat het een grote rotzooi wordt.

De meeste populaire kerstnummers zijn daarom een mix van **Jazz** en **Pop.** (Ook mede omdat het anders niet catchy genoeg was voor de radio, denk ik.) Dit zorgt ervoor dat je eigenlijk een popliedje krijgt, met hier en daar een raar akkoord en bijzondere klank.

Bijvoorbeeld, dit zijn de begin-akkoorden van **All I Want For Christmas:**

<p style="padding-left: 30px;">
  G<br /> I don&#8217;t want a lot for Christmas<br /> G/B<br /> There is just one thing I need<br /> C<br /> I don&#8217;t care about the presents<br /> Cm6/Eb<br /> Underneath the Christmas tree
</p>

<p style="padding-left: 30px;">
  G/D                           B7<br /> I just want you for my own<br /> Em                           Cm/Eb<br /> More than you could ever know<br /> G/D                           E7<br /> Make my wish come true<br /> Am7                          Am7b5/D<br /> All I want for Christmas &#8230;.
</p>

Dat zijn een hoop moeilijke akkoorden. En toch klinkt het goed, en extreem kerstig.

(Zelfs **Rudolph the Red-Nosed Reindoor** heeft een D7 erin zitten, bedenk ik me net.)

Daar bovenop, elk kerst-nummer is ofwel extreem langzaam, ofwel uptempo. Het hierboven genoemde nummer is uptempo, terwijl een nummer als **White Christmas** heel langzaam voortbeweegt. Een tussenweg bestaat niet echt, omdat zoiets meer richting andere muziekstijlen gaat.

(Denk er maar eens over na. Jingle Bells gaat bijvoorbeeld ook vrij rap, terwijl een nummer als **Last Christmas** een langzame beat heeft.)

## De grote vragen en gouden regels

Hoe bedenk je welke akkoorden je kunt gebruiken?

<p style="padding-left: 30px;">
  Gouden regel: Dit heeft te maken met een deel van muziektheorie die <strong>modaliteit</strong> heet. Elke toonsoort heeft 7 verschillende <strong>modi</strong>, en je kunt vrij akkoorden pakken uit elk van hen. GEEN ZORGEN! Ik zal dit dadelijk illustreren door zelf een kerstmelodie te maken.
</p>

Hoe bedenk je welke melodie over de akkoorden kan?

<p style="padding-left: 30px;">
  Gouden regel: wederom, elke <b>modus </b>heeft een eigen toonladder, en je pakt gewoon één van de noten uit deze ladder.
</p>

## Onze eigen poging

Men pakt een toonsoort! Voor dit voorbeeld gaan we naar G Majeur. (Omdat hij gevarieerder is dan C Majeur, maar niet al te veel mollen/kruizen bevat.)

Laat ik nu twee willekeurige modi pakken:

  * **Ionisch**:** **G &#8211; Am &#8211; Bm &#8211; C &#8211; D &#8211; Em &#8211; F#7 
      * Dit is de &#8220;standaard toonladder&#8221; die iedereen die een beetje muziek maakt kent.
  * **Dorisch:** Gm &#8211; Am &#8211; Bb &#8211; C &#8211; Dm &#8211; Edim &#8211; F

Het kan allemaal nog ingewikkelder worden door de septiem toe te voegen. Aangezien kerstnummers dat leuk vinden, doen we dat:

  * **Ionisch:** Gmaj7 &#8211; Am7 &#8211; Bm7 &#8211; Cmaj7 &#8211; D7 &#8211; Em7 &#8211; F#7(b5)
  * **Dorisch: **Gm7 &#8211; Am7 &#8211; Bbmaj7 &#8211; C7 &#8211; Dm7 &#8211; Edim7 &#8211; Fmaj7

Dat lijkt me genoeg akkoorden.

## Het akkoordenschema

Nadat ik een aantal akkoorden aan elkaar heb geregen, krijg ik:

<p style="padding-left: 30px;">
  <strong>Couplet:<br /> </strong>Gmaj7 &#8211; F#7 &#8211; Bm7 &#8211; Cmaj7<br /> C7 &#8211; Edim7 &#8211; F &#8211; (Am) &#8211; Dm<br /> D7 &#8211; Gm &#8211; D7 &#8211; G
</p>

<p style="padding-left: 30px;">
  <strong>Refrein:</strong><br /> C &#8211; D &#8211; D7 &#8211; G<br /> C &#8211; D &#8211; D7 &#8211; G<br /> Em7 &#8211; Edim7 &#8211; Fmaj7 &#8211; Fmaj7<br /> Gm7 &#8211; Am7 &#8211; Bb7 &#8211; (C) &#8211; Dm<br /> D(7) &#8211; G
</p>

(Ik heb er natuurlijk wel even doorheen gespeeld om te kijken of ik er iets mee kon. Het zou heel bijzonder zijn als deze akkoorden bij de eerste poging uit de losse pols waren gegooid :p Het zou ook heel bijzonder zijn als dat daadwerkelijk een uitspraak was. Wat is het? Iets uit de losse pols _doen_? Iets uit de losse pols _proberen_? Ik weet het even niet.)

## De melodie

In plaats van een patroon te pakken, heb ik een tijdje geïmproviseerd en zo een melodie gevonden voor couplet + refrein. Ik ben er wel trots op. Hoewel het meer een combinatie Jazz + Musicalmuziek is geworden.

Hieronder de bladmuziek + een audio speler met het liedje.

[abcjs engraver=&#8221;{ responsive: &#8216;resize&#8217; }&#8221;]X:1  
T: Just like last Christmas  
M:4/4  
K:G  
L:1/8  
Q:1/4=135  
V:T1 clef=treble-8 name=&#8221;Melodie&#8221; snm=&#8221;M&#8221;  
V:T2 middle=d clef=bass name=&#8221;Akkoorden&#8221; snm=&#8221;A&#8221;  
% Strofe 1  
[V:T1] | z4 Bdef | e3/2^c3/2^A3/2 A3 z/2 | z4 Bdfa-|a2 a/2b/2g4 g |  
w: I don&#8217;t real-ly know you that much you don&#8217;t ful-ly* re-a-lize that  
[V:T2] | [g,,8b,,8d,,8f,,8] | [f,,8^a,,8^C8e,,8] | [b,,8d,,8f,,8a,,8] | [c,,8e,,8g,,8b,,8] |  
% Strofe 2  
[V:T1] | ^a2 =a2 g2 e2 | ^a2 =a g3 c&#8217;2 | a4 ag=fg-| g2 =f4 fd |  
w: e-very-thing you gave me was a chance just like last christ-mas when you  
\[V:T2] | [c,,8e,,8g,,8^a,,8] | [e,,8g,,8^a,,8] | [=f,,4a,,4c,,4e,,4\] \[e,,4g,,4a,,4c,,4\] | [d,,8=f,,8a,,8] |  
% Strofe 3  
[V:T1] | f2 g2 a2 c&#8217;2 | [Q:100] ^a2 =a2 g2 f2 | f2 e2 d2 c2 | d8 ||  
w: held the door for a-ny-one but held no doors for me  
\[V:T2] | [d,,8f,,8a,,8c,,8] | [Q:100\] \[d,,8g,,8^a,,8\] | [d,,8f,,8a,,8c,,8] | [g,,8b,,8d,,8f,,8] ||  
% Refrein 1  
[V:T1] | [Q:135] d2 e2 edef-| f g3 c&#8217;2 c&#8217;2 | c&#8217;4 b4-| b6 z c|  
w: Closed eyes, sit by the fi\*~re, let me sing this\* as  
\[V:T2] | [Q:135\] \[c,,8e,,8g,,8\] | \[d,,4f,,4a,,4\] \[d,,4f,,4a,,4c,,4\] | [g,,8b,,8d,,8] | [g,,8b,,8d,,8] |  
% Refrein 2  
[V:T1] | e2 e4 fg | f3 c c2 B2 | d8- | d6 z2 |  
w: snow-flakes make their way a-cross the sky  
\[V:T2] | [c,,8e,,8g,,8] | [d,,4f,,4a,,4\] \[d,,4f,,4a,,4c,,4\] | [g,,8b,,8d,,8] | [g,,8b,,8d,,8] |  
% Refrein 3  
[V:T1] | e2 g2 b2 d&#8217;2 | ^a2 =a2 g2 =f2 | e&#8217;4 a4- | a6 z2 |  
w: won&#8217;t you be my grea-test gift this Christ-mas  
[V:T2] | [e,,8g,,8b,,8d,,8] | [e,,8g,,8^a,,8] | [=F,8A,8c,8e,8] | [=F,8A,8c,8e,8] |  
% Refrein 4  
[V:T1] | ^a2 =a g3 =f2 | g2 a2 c4 | d2 e2 =f2 g2 | [Q:100] a2 g2 =f2 e2 |  
w: look at me from where you are sing with me un-til we spend Christ-  
\[V:T2] | [d,,8g,,8^a,,8] | [a,,8c,,8e,,8g,,8] | [^A,,8d,,8=f,,8=a,,8] | [Q:100\] \[c,,8e,,8g,,8\] |  
% Refrein 5  
[V:T1] | c2 d2 B2 A2 | G8 |  
w: mas to-ge-ther now  
[V:T2] | [d,,8f,,8a,,8c,,8] | [g,,8b,,8d,,8] |  
% Afronding[/abcjs]

[abcjs-midi]X:1  
M:4/4  
K:G  
L:1/8  
Q:1/4=135  
V:T1 clef=treble-8 name=&#8221;Melodie&#8221; snm=&#8221;M&#8221;  
V:T2 middle=d clef=bass name=&#8221;Akkoorden&#8221; snm=&#8221;A&#8221;  
% Strofe 1  
[V:T1] | z4 Bdef | e3/2^c3/2^A3/2 A3 z/2 | z4 Bdfa-|a2 a/2b/2g4 g |  
w: I don&#8217;t real-ly know you that much you don&#8217;t ful-ly* re-a-lize that  
[V:T2] | [g,,8b,,8d,,8f,,8] | [f,,8^a,,8^C8e,,8] | [b,,8d,,8f,,8a,,8] | [c,,8e,,8g,,8b,,8] |  
% Strofe 2  
[V:T1] | ^a2 =a2 g2 e2 | ^a2 =a g3 c&#8217;2 | a4 ag=fg-| g2 =f4 fd |  
w: e-very-thing you gave me was a chance just like last christ-mas when you  
\[V:T2] | [c,,8e,,8g,,8^a,,8] | [e,,8g,,8^a,,8] | [=f,,4a,,4c,,4e,,4\] \[e,,4g,,4a,,4c,,4\] | [d,,8=f,,8a,,8] |  
% Strofe 3  
[V:T1] | f2 g2 a2 c&#8217;2 | [Q:100] ^a2 =a2 g2 f2 | f2 e2 d2 c2 | d8 ||  
w: held the door for a-ny-one but held no doors for me  
\[V:T2] | [d,,8f,,8a,,8c,,8] | [Q:100\] \[d,,8g,,8^a,,8\] | [d,,8f,,8a,,8c,,8] | [g,,8b,,8d,,8f,,8] ||  
% Refrein 1  
[V:T1] | [Q:135] d2 e2 edef-| f g3 c&#8217;2 c&#8217;2 | c&#8217;4 b4-| b6 z c|  
w: Closed eyes, sit by the fi\*~re, let me sing this\* as  
\[V:T2] | [Q:135\] \[c,,8e,,8g,,8\] | \[d,,4f,,4a,,4\] \[d,,4f,,4a,,4c,,4\] | [g,,8b,,8d,,8] | [g,,8b,,8d,,8] |  
% Refrein 2  
[V:T1] | e2 e4 fg | f3 c c2 B2 | d8- | d6 z2 |  
w: snow-flakes make their way a-cross the sky  
\[V:T2] | [c,,8e,,8g,,8] | [d,,4f,,4a,,4\] \[d,,4f,,4a,,4c,,4\] | [g,,8b,,8d,,8] | [g,,8b,,8d,,8] |  
% Refrein 3  
[V:T1] | e2 g2 b2 d&#8217;2 | ^a2 =a2 g2 =f2 | e&#8217;4 a4- | a6 z2 |  
w: won&#8217;t you be my grea-test gift this Christ-mas  
[V:T2] | [e,,8g,,8b,,8d,,8] | [e,,8g,,8^a,,8] | [=F,8A,8c,8e,8] | [=F,8A,8c,8e,8] |  
% Refrein 4  
[V:T1] | ^a2 =a g3 =f2 | g2 a2 c4 | d2 e2 =f2 g2 | [Q:100] a2 g2 =f2 e2 |  
w: look at me from where you are sing with me un-til we spend Christ-  
\[V:T2] | [d,,8g,,8^a,,8] | [a,,8c,,8e,,8g,,8] | [^A,,8d,,8=f,,8=a,,8] | [Q:100\] \[c,,8e,,8g,,8\] |  
% Refrein 5  
[V:T1] | c2 d2 B2 A2 | G8 |  
w: mas to-ge-ther now  
[V:T2] | [d,,8f,,8a,,8c,,8] | [g,,8b,,8d,,8] |  
% Afronding[/abcjs-midi]

&nbsp;

Mocht je jezelf afvragen: huh, waar gaat die tekst over? _Ik heb geen idee_. Ik laat het aan de verbeelding van de luisteraar over. Fijne feestdagen!

P.S. Ooit ga ik uitvinden hoe ik deze bladmuziek-programmeertaal akkoorden kan laten spelen. En hoe ik een verschillend volume voor de achtergrond akkoorden/melodie kan instellen. Ik probeerde namelijk een leuke baslijn mee te geven, met gebroken akkoorden, maar toen was de melodie niet meer goed te horen.

&nbsp;