---
title: Goeie zak haki
author: hetisdepanda
type: post
date: 2019-03-06T13:41:26+00:00
url: /visuele-fratsen/goeie-zak-haki/
categories:
  - Gewoon een Gedachte
  - Visuele Fratsen

---
Onlangs ging ik met het gezin naar een museum. Onderweg daarnaartoe zag ik meerdere keren onderstaand reclamebord langs de weg staan.

<div id="attachment_8608" style="width: 330px" class="wp-caption aligncenter">
  <a href="http://nietdathetuitmaakt.nl/wp-content/uploads/2019/03/goeie-zak-haki_result.webp"><img aria-describedby="caption-attachment-8608" decoding="async" loading="lazy" class="wp-image-8608 size-full" src="http://nietdathetuitmaakt.nl/wp-content/uploads/2019/03/goeie-zak-haki_result.webp" alt="" width="320" height="320" /></a>
  
  <p id="caption-attachment-8608" class="wp-caption-text">
    (De foto heb ik niet gemaakt, want ik had niks bij om foto&#8217;s mee te maken. Gelukkig had een internetvreemdeling wél een foto gemaakt.)
  </p>
</div>

Van dichtbij is nog vrij duidelijk wat er staat: &#8220;GOEIE ZAK HAK!&#8221;

Als je in een rijdende auto zit, echter, leek het alsof er stond: &#8220;GOEIE ZAK HAKI&#8221;

Ik heb me de hele weg afgevraagd wat een &#8220;haki&#8221; is en waarom het in een zak zit :p Pas achteraf besefte ik dat op de foto daaronder &#8220;HAK&#8221; stond, wat gewoon een bekend merk is.

_Waarom gebeurt dit?_ Omdat alles in hoofdletters is. Daardoor is het moeilijker te lezen en lijkt het uitroepteken heel erg op een hoofdletter I. Daarnaast is de ruimte tussen de vertical streep en het bolletje eronder niet groot genoeg: op afstand verdwijnt die ruimte en lijkt het al helemaal niet meer op een uitroepteken. Ze hadden meer moeten doen om het uitroepteken onderscheidend te maken.

_Waarom is dit interessant?_ Ik vind het interessant. Te veel mensen kiezen een lettertype dat ze leuk vinden en denken er verder niet meer over na, terwijl de kans bestaat dat een tekst onleesbaar wordt of verkeerd wordt geïnterpreteerd. Dus hopelijk maak jij &#8211; mijn trouwe lezer &#8211; deze fout nooit meer!

_En wat als ik dat niet doe?_ Dan zeggen we: opgeruimd haat netjes.

<div id="attachment_8610" style="width: 830px" class="wp-caption aligncenter">
  <a href="http://nietdathetuitmaakt.nl/wp-content/uploads/2019/03/OPGERUIMD-HAAT-NETJES-1_result.webp"><img aria-describedby="caption-attachment-8610" decoding="async" loading="lazy" class="wp-image-8610 size-full" src="http://nietdathetuitmaakt.nl/wp-content/uploads/2019/03/OPGERUIMD-HAAT-NETJES-1_result.webp" alt="" width="820" height="460" /></a>
  
  <p id="caption-attachment-8610" class="wp-caption-text">
    (Dit tijdschrift lag in de wachtkamer van het ziekenhuis. De rest van het ontwerp was verder hartstikke mooi en duidelijk, beter dan ik op dit moment kan waarschijnlijk. Maar dit vond ik gewoon grappig.)
  </p>
</div>