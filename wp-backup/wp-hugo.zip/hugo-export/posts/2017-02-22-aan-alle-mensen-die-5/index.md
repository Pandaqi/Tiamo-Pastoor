---
title: Aan alle mensen die…
author: hetisdepanda
type: post
date: 2017-02-22T10:48:02+00:00
url: /gewoon-een-gedachte/aan-alle-mensen-die-5/
categories:
  - Gewoon een Gedachte

---
&#8230; websites maken met van die cookies-meldingen, terwijl er niks is waar jij cookies voor nodig hebt, en als je op akkoord klikt laadt ie de hele pagina opnieuw. Jullie zijn monsters. Vaak ben ik net lekker iets aan het lezen, maar op een gegeven moment zit die melding over de tekst heen, dus ik klik maar (met grote tegenzin) akkoord, en vervolgens moet ik een paar seconden wachten totdat ik weer helemaal aan het begin sta.

En oké, ik begrijp dat jullie verplicht zijn (voor nu, althans) om naar die cookies te vragen, maar ik heb een klein ideetje voor jullie: gebruik geen cookies! Veel sites waarop toestemming over cookies wordt gevraagd, hoeft de gebruiker niet in te loggen of is de bedoeling niet dat er iets wordt bijgehouden. Dus, als er cookies worden gebruikt, dan doet de website dat alleen maar zodat ze gebruikers kunnen volgen, en advertenties op hen kunnen afstemmen, en kunnen achterhalen wat mensen allemaal doen op hun website.

<!--more-->

<p style="color:gray;">
  Overigens, zelfs voor dingen als inloggen kan een website makkelijk andere dingen gebruiken dan cookies (zoals <em>sessions</em>), en voortgang van een spel bijhouden kan ook met iets anders (zoals <em>localStorage</em>), dus ga er maar van uit dat cookies meestal niet meteen in jouw voordeel zijn.
</p>

Dat is de hele reden dat die cookie-vermeldingen in eerste instantie zijn ingevoerd, maar als iedereen toch meteen akkoord is, en mensen anders de website niet mogen zien, heeft het geen zin. Het is ook niet per sé heel schadelijk, maar ik kan me best voorstellen dat mensen geen zin hebben in websites die van alles van ze bijhouden. Ze hebben geen andere keuze dan die onzin-cookies accepteren, anders kunnen ze niet op de website.

Dus ik herhaal nogmaals: jullie zijn monsters. Ga in de hoek staan en denk eens goed na over wat je hebt gedaan.