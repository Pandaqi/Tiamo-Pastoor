---
title: Machteloos
author: hetisdepanda
type: post
date: 2016-10-24T15:00:59+00:00
url: /gewoon-een-gedachte/machteloos/
categories:
  - Gewoon een Gedachte

---
Er is één groot fundamenteel probleem met kind zijn. (Nouja, er zijn wel meer problemen, maar zoals je al verwacht ga ik het er maar over eentje hebben hier). Iemand anders heeft de controle over jou.

En dat heeft natuurlijk goede en slechte kanten. Als baby van een paar jaar oud kun je nauwelijks praten of dingen oppakken zonder ze te laten vallen, dus dan is het fijn dat mensen je eten, en onderdak, en schone kleding geven. Als kind op de basisschool krijg je misschien soms al met keuzes te maken die tegen je zin in gaan (&#8220;aaah waarom mag ik niet afspreken met Henkje?&#8221;), maar nog steeds verzorgen je ouders je veiligheid en gezondheid. Je gaat elke dag netjes naar school, want je weet niet beter. Je speelt na school gekke spelletjes met kinderen die je niet kent, want je weet niet beter.

<!--more-->

Maar dan komt de puberperiode, die overigens een stuk langer en heftiger is (in veel gevallen) dan mensen denken. De pubers zijn hebben constant honger en slaaptekort, maar van hun ouders mogen ze niet alles wat los en vast zit eten, en zeker geen school missen. De pubers worden verliefd, maar de ouders vinden sommige meisjes wel of niet passen, en besluiten of je mag afspreken of niet. De pubers ontdekken andere dingen in het leven dan school. Ze willen misschien met vrienden op vakantie naar een ver tropisch oord. Of ze willen de ene maand op voetbal, en de andere maand willen ze harp leren spelen. En dat kost de ouders allemaal geld. Of ze gaan naar feesten en moeten in het donker naar huis, en dan maken de ouders zich grote zorgen.

Het hangt heel erg van je ouders af, hoe je opgroeit als kind. Je bent misschien zestien, achttien, hoogstens twintig jaar kind, en tot die tijd hebben je ouders het grotendeels voor het zeggen. Jij wilt iets, zij zeggen nee, en het gebeurt niet. Zij willen wat het beste is voor jou (of wat hun het minste hartkloppingen en paniekaanvallen geeft), maar jij wil wat jij denkt dat het beste is voor jezelf. Zonder dat je het doorhebt, ben je misschien een kwart van je leven onder directe invloed van je ouders en thuisomgeving.

En dan kan het natuurlijk twee kanten op klappen: je doet braaf wat je ouders zegt, maar er knaagt die vermoeidheid, onvrede en machteloosheid, of je wordt rebels en begint school, je ouders en de wereld de rug toe te keren. Men zegt vaak dat het erg is dat er best veel kinderen spijbelen, of hun schoolcarrière helemaal halen op alleen maar vijfjes en zesjes halen, of nul interesse tonen in huiswerk of school. In mijn mening, echter, zijn er verdacht weinig rebellen.

Voor veel mensen is het gewoon geen optie. Als je niet doet wat je ouders zeggen, heb je misschien geen eten, of moet je alles zelf gaan doen en betalen.  Als je gezinsleden en ouders dingen doen waar jij het niet mee eens bent of aan stoort, kun je er niks aan doen, want jij bent jonger en hebt niet de leiding. Deze machteloosheid over je omgeving en omstandigheden leidt vaak juist tot depressies en recalcitrant gedrag.

Toen er een keer een grote rondvraag werd gesteld aan middelbare scholieren, reageerde het overgrote deel dat ze helemaal kapot, overwerkt, vermoeid, en verveeld waren. En ze zijn machteloos, want ze kunnen het schoolsysteem niet veranderen, en zeker niet van ouders switchen. Dat is toch raar? Sterker nog, dat is toch verschrikkelijk? Waarom leren we kinderen dat het leven stressvol is, en dat andere mensen de baas over je mogen spelen, en dat wat jij vindt of doet niks uitmaakt? Waarom leren we kinderen dat kennis opdoen saai en vervelend moet zijn? Waarom denkt niemand beter na over de omgeving waarin kinderen twintig jaar opgroeien?

Ik kan de vragen stellen, maar geen antwoorden geven. In dat opzicht ben ik nog steeds machteloos.