---
title: De toilet-tyrannie
author: hetisdepanda
type: post
date: 2016-10-12T15:00:50+00:00
url: /gewoon-een-gedachte/de-toilet-tyrannie/
categories:
  - Gewoon een Gedachte

---
Laatst viel mij iets op. Het leek eerst van weinig belang, maar na het wat aandacht te hebben gegeven, ben ik achter een groot geheim gekomen.

Vrijwel elke dag ben ik voor (relatief) lange tijd op de universiteit, wat betekent dat ik toch wel minstens één keer naar de WC moet. Nou heeft mijn universiteit werkelijk overal toiletten (&#8230;dus dáár gaat hun budget naar toe&#8230;), dus is dat op zich geen probleem, alleen heb ik gemerkt dat ik vrijwel altijd naar het toilet ga als ik bij onze studievereniging ben. Om de hoek van onze verenigingsruimte zit een WC, en onbewust ga ik daar dus vrijwel altijd heen, zelfs als ik eerder op de dag al nodig naar het toilet moet.

<!--more-->

Toen ik er over nadacht, zag ik in dat die specifieke WC vrijwel nooit helemaal bezet is. En, het ruikt er ook altijd lekker en het is er opgeruimd en netjes. In andere woorden: het is er niet zo&#8217;n gore zooi als in veel andere &#8220;openbare&#8221; toiletten. Blijkbaar heeft die onbewuste indruk van het toilet zo&#8217;n impact op mij, dat ik ineens alle andere toiletten negeer, en zelfs eerder naar die specifieke studieruimte ga (en er ook langer blijf).

_&#8230;dus?_ Nou, waarom oh waarom, passen bedrijven of andere gebouwen dit niet toe? Als een geurtje spuiten op de WC en een schoonmaker inhuren zo&#8217;n verschil maakt, dan moet het toch ongelofelijk voordelig zijn door met schone toiletten meer bezoekers aan te trekken? Bijvoorbeeld, er zijn meerdere winkels in elke grote winkelstraat waarvan iedereen weet dat ze een toilet hebben, maar ook dat je er voor moet betalen. En betalen voor toiletteren vinden mensen onzin, dus ze houden het liever urenlang op en gaan thuis. (Of, in ergere gevallen, in de bosjes.)

Maar, als je in plaats daarvan je toiletten gratis zou maken, en zorgt dat het een genot is om er te zijn (voor zover naar de WC gaan natuurlijk het beste onderdeel van iedereens dag is), kun je ongelofelijk veel klanten aantrekken. Die ook nog eens positieve reviews achterlaten, want dat is ook de hele hype tegenwoordig.

Sterker nog, ik denk dat sommige bedrijven dit al doorhebben en slinks toepassen. Immers, klanten met een volle blaas rushen de winkel door en kopen veel minder dan ze wilden, omdat ze zo nodig moeten. Vermoeide klanten die door de winkelstraat sleuren en zien dat jij gratis faciliteiten aanbiedt, zullen de winkel binnenhoppen en misschien zelfs in hun vermoeidheid onverwacht vijf iPhones kopen.

Of niet. Als _iedereen_ het zou doen, zou men het weer niet als privilege zien. Er zouden zelfs een aantal echte Hollanders komen die gaan zeiken als een winkel géén superschoon toilet aanbiedt. Tel hier de kosten bij op, en vanuit een bedrijfs-oogpunt kan ik dus ook wel begrijpen waarom ze het niet doen. Desalniettemin, als er eens een bedrijf zou zijn dat door het hele land deze geweldige toiletdienst verzorgt, zal deze de alleenheerser zijn van het onbewust positief beïnvloeden van al het winkelpubliek.

&nbsp;