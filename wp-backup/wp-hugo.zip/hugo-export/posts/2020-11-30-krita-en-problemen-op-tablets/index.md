---
title: Krita en problemen op Tablets
author: hetisdepanda
type: post
date: 2020-11-30T16:00:48+00:00
url: /visuele-fratsen/krita-en-problemen-op-tablets/
categories:
  - Gewoon een Gedachte
  - Visuele Fratsen

---
De gratis tekensoftware&nbsp;[**Krita**][1] maakt al jarenlang steeds meer indruk op mij, elke keer als ik een nieuwe update voorbij zie komen.

(Bovendien hebben ze een mooie website. Niet eentje die eruit ziet alsof het uit 1990 komt, wat doorgaans jammer genoeg het geval is bij gratis software.)

Dus ik wilde dit programma proberen!

Binnen een minuut was het gedownload en geïnstalleerd, maar toen ik wilde tekenen op mijn&nbsp;**Surface Pro**&nbsp;&#8230; ging er van alles mis.

De lijn was haperig, vertraagd, soms niet eens waar ik tekende. Hij reageerde nauwelijks op verschil in druk. Nog raarder: hij deed het&nbsp;_perfect_ in het &#8220;testgebied&#8221; van elke brush, maar&nbsp;_compleet verkeerd_ als ik op een andere plek ging tekenen.

Hoe lossen we dit op? Laat mij jou een frustrerende paar uur besparen en uitleggen hoe ik dat heb gedaan!

Deze stappen zijn voor&nbsp;**Krita 4.4.1** en de&nbsp;**Surface Pro 4**, maar ze zullen nuttig zijn voor de meeste softwareversies en de meeste tablets.

<!--more-->

## Stap 0

**Stap 0:**&nbsp;Als je het programma&nbsp;_niet_ in het Engels hebt staan, verander dat dan zo snel mogelijk.

Ik zie oprecht het nut niet van dit soort software in het Nederlands gebruiken. Alle informatie die je online vindt is niet (direct) bruikbaar. De gebruikte termen zijn in de hele industrie hetzelfde, dus die moet je toch kennen.

Ga naar Settings > Switch Application Language > American English. Hij vraagt automatisch of je wilt herstarten, accepteer dat.

## Stap 1

**Stap 1:** Ga naar Settings (menu aan de bovenkant, richting het einde) > Configure Krita > Tablet Settings.

Verander de setting naar&nbsp;**Windows 8+ Pointer Input**.

Herstart het programma! (Heel belangrijk. Anders merk je geen enkel verschil. Deze keer doet hij het _niet_ automatisch.)

## Stap 2

**Stap 2:** Nog steeds in de settings, ga naar General > Tools > **Enable Touch Painting**.

Zet dit uit.

Anders denkt het programma dat elke aanraking met je vingers of muis óók een poging tot tekenen is. (Nu kan je het scherm inzoomen, draaien, etc.&nbsp;_zonder_ bang te zijn voor rare stippen en lijnen.)

## Stap 3

**Stap 3:**&nbsp;selecteer de Brush tool (het penceelicoontje, of druk op B).

Ga nu naar het venster rechtsboven, daar moet je een tabblad &#8220;Tool Options&#8221; zien. Selecteer dat.

Hier kan je de &#8220;**Brush Smoothing**&#8221; kiezen. Als je merkt dat je lijnen nog steeds haperig/lelijk/hard zijn, en je vindt dat niet leuk, zet dit dan naar iets anders dan &#8220;None&#8221;.

In mijn geval was &#8220;Basic&#8221; helemaal prima.

(Als alternatief kan je de Dynamic Brush kiezen, die staat een stukje rechtsonder de Brush. Deze doet iets soortgelijks automatisch, maar je hebt iets van vertraging in je lijn zitten omdat hij deze moet corrigeren.)

## Stap 4

**Stap 4:**&nbsp;teken erop los!

Dit is een soort wereldkaart die ik vanochtend tekende voor een prentenboek waaraan ik werk. (Ik moet nog een beetje leren wat alle verschillende&nbsp;_brushes_ doen en hoe je ze het beste gebruikt, maar op zich vind ik het resultaat redelijk.)

<div class="wp-block-image">
  <figure class="alignleft size-large"><a href="https://nietdathetuitmaakt.nl/wp-content/uploads/2020/11/Kaart_result.webp"><img decoding="async" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2020/11/Kaart_result.webp" alt="" /></a></figure>
</div>

Zo, dit was even een korte aankondiging. Ik heb&nbsp;_urenlang_ in groeiende frustratie geprobeerd dit programma normaal te laten functioneren met mijn tablet, wetende dat er niks mis was met de pen of de rest van het apparaat. De stappen hierboven hebben uiteindelijk alles opgelost.

 [1]: https://krita.org/en/