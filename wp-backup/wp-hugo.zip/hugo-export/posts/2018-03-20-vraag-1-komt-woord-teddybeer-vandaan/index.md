---
title: 'Vraag: Waar komt het woord teddybeer vandaan?'
author: hetisdepanda
type: post
date: 2018-03-20T15:00:28+00:00
url: /gewoon-een-gedachte/vraag-1-komt-woord-teddybeer-vandaan/
categories:
  - Gewoon een Gedachte

---
<p style="color: #aaaaaa;">
  Opmerking: ik neem natuurlijk enige vrijheden bij het beantwoorden van vragen. Theodore had bijvoorbeeld helemaal geen Duitse vriend die met hem door de bossen liep op die dag. (Hermann was wel degelijk een vriend van hem.) Maar ik vind alles verantwoord voor een leuk verhaal, zolang ik uiteindelijk maar de vraag juist beantwoord :p
</p>

Het was een zonnige zomerdag in 1902 toen Theodore Roosevelt in de bossen op berenjacht ging. Hij wist zelf hoe hopeloos hij was met jagen, dus hij nam zijn vrienden Edward en Hermann mee.

<p style="padding-left: 30px;">
  Edward: &#8220;Zeg, Teddy, ben jij niet de 26e president van de Verenigde Staten?&#8221;<br /> Theodore: &#8220;Ja, hoezo?&#8221;<br /> Edward: &#8220;Gewoon, even een feitje voor de lezer van dit stuk.&#8221;<br /> Theodore: &#8220;Edward, je bent een malle jongen. Hebben we al iets gevangen?&#8221;<br /> Hermann: &#8220;Nein! Al die beren lijken spörlösch verdweinen!&#8221;<br /> Edward: &#8220;Hmm. Maar even heus, daarmee kunnen we natuurlijk niet thuiskomen. Je zou maar een president hebben die niet eens een beer kan afschieten!&#8221;<br /> Hermann: &#8220;Preciesch! Straksch krijgt Amerika nog een president die niet eens normaal kan praten en alleen maar Twittert!&#8221;<br /> Edward: &#8220;Dat zou <em>walgelijk </em>zijn. Maar even heus, Teddy, hoe komen wij zo snel aan een beer?&#8221;<br /> Hermann: &#8220;Natürlich! We vangen een schattig, weerloos baby beertchen! Die moet toch wel te pakken zijn? En dan mag jij, mein beste Teddy, die afschieten!&#8221;
</p>

En voordat Theodore kon tegenpruttelen, stormden zijn vrienden het bos in.

<!--more-->

Hij wachtte, en wachtte, en wachtte, totdat de zon bijna onder ging en zijn vrienden eindelijk terugkwamen. In hun armen droegen ze de schattigste, liefste beer die hij ooit had gezien. Zijn grote, schitterende ogen keken hem hoopvol aan, alsof de beer niet wist wat hem te wachten stond, en dacht dat ze met hem gingen spelen.

Theodore hield het niet meer.

<p style="padding-left: 30px;">
  Theodore: &#8220;Nee. Nee! Zo&#8217;n lief beest kan ik toch niet doodschieten? Dan komen we maar zonder vangst thuis.&#8221;<br /> Hermann: &#8220;Dan doe ich das wel!&#8221;<br /> Theodore: &#8220;Nee!&#8221;<br /> Edward: &#8220;Maar &#8230; we kunnen deze schattige babybeer nu niet ineens teruggeven aan zijn moeder! Die gaat sowieso vragen stellen!&#8221;<br /> Theodore: &#8220;Dan brengen we hem naar een andere plek waar hij goed zal worden verzorgd.&#8221;
</p>

Dit verhaal bereikte al snel de pers, en liep als een sneltreinvuurtje door heel Amerika. Meerdere knuffelmakers &#8211; in die tijd vaak nog vrouwen met toegang tot stof en naaigerei &#8211; pakten de hype op, en begonnen beren te maken onder de naam &#8220;Teddy&#8217;s beer&#8221;. De beer was zo schattig en zacht, en had ook nog eens zo&#8217;n interessant verhaal, dat het meteen een gigantische hit werd. Over tijd vervormde het woord tot _teddybeer_, en omdat het ook gewoon goed klinkt, is het altijd blijven hangen.

**Opmerking!** Ik heb een nieuw stappenplan voor mijn leven: ik word heel beroemd, ga dan naar een wildreservaat ver weg, red een rode panda, kom thuis en maak een film over mijn belevenis, en hoop heel hard dat ze bergen rode-panda-knuffels gaan maken met mijn naam. (En _natuurlijk_ krijg ik ze dan gratis.)