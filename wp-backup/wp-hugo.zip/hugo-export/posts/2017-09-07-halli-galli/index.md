---
title: Halli Galli
author: hetisdepanda
type: post
date: 2017-09-07T16:48:40+00:00
url: /superieure-spellen/proberen-programmeren/halli-galli/
categories:
  - Proberen Programmeren

---
Wat een naar spel. Daarom ga ik het kapot analyseren zodat ik niet meer uitgelachen kan worden om mijn matige reactiesnelheden. (En het feit dat ik als wiskundige belachelijk slecht kan tellen.)

Oftewel, we gaan kijken of je kan winnen zonder dat reactiesnelheid een rol speelt. Bijvoorbeeld, door gewoon standaard om de drie kaarten op de bel te slaan.

## De Spelregels

Er is een stapel met kaarten. Op een kaart is een _fruitsoort_ afgebeeld (er zijn er 4 in totaal), in een bepaalde&nbsp;_hoeveelheid_ (1 t/m 5). Deze stapel wordt opgedeeld onder de spelers. Zij leggen die gedekt voor zich. (Ook staat er een bel in het midden van de tafel.)

<!--more-->

Om de beurt draait men de bovenste kaart van zijn stapel om, en legt die voor zich, bovenop zijn vorige open kaart.

  * Als in totaal exact 5 symbolen van een bepaalde fruitsoort te zien zijn op tafel, is er een _Halli Galli_.&nbsp;Iedere speler probeert op de bel te slaan. Diegene die dat als eerste lukt, krijgt alle open kaarten, en voegt die aan zijn gedekte trekstapel toe. Hij begint de volgende ronde.
  * Als er geen&nbsp;_Halli Galli_ is, speelt men gewoon door. Als iemand toch foutief op de bel slaat, moet deze voor straf één kaart aan elke andere speler geven.

Als iemand geen kaarten meer heeft, is deze uit het spel, tenzij die persoon het huidige potje weet te winnen. De persoon die uiteindelijk alle kaarten heeft, wint het spel.

(Een variant is dat de laatste twee spelers nog één ronde spelen, en wie die ronde wint is de uiteindelijke winnaar. Anders kan het einde van het spel superlang duren. Looking at you, Risk.)

_Opmerking_: ik heb geen spel bij de hand om precies de kaarten te tellen. Ik weet dat er 56 kaarten zijn. Verdeeld over 4 vruchten, geeft dat 14 kaarten per soort. Ik ga er vanuit dat de makers zoveel mogelijk uitkomsten willen die in de buurt van 5 zitten. Dus, 3 zit er het meest in, daarna 2 en 4, en daarna 1 en 5. Ik kom zo uit op de volgende verdeling: 2, 3, 4, 3, 2.

## En hoe ga jij zo&#8217;n spel analyseren?

Aha! Nu wordt het interessant. Als ik een fatsoenlijk kaartspel zou analyseren, waarbij men bijvoorbeeld uit eigen hand kiest wat men speelt, dan kan ik gewoon een simulatie maken die willekeurig 1 van de X kaarten in iemands hand kiest.

Omdat dit spel te maken heeft met&nbsp;_reactiesnelheid_ — zowel het zien van een _Halli Galli_, als wel het succesvol slaan van de bel — kan dat niet.&nbsp;In plaats daarvan moet iedere speler volgens een bepaalde kansverdeling reageren. Het zou onrealistisch zijn om te zeggen dat elke speler _altijd precies_ een halve seconde doet over op de bel slaan.

De meest bekende kansverdeling is de&nbsp;_normaalverdeling_. (De naam komt ook van dat hij zo veel wordt gebruikt dat het normaal is.) Maar die kan niet. Dan bestaat er namelijk een kans dat de reactiesnelheid negatief wordt, en het lijkt me sterk dat iemand nog voordat hij een kaart heeft gezien, weet dat het een Halli Galli wordt. (Tenzij diegene vals speelt, natuurlijk.)

Dus, wat doen we? De exponentiële verdeling! Deze wordt vrijwel altijd gebruikt als het gaat om (wacht)tijden, omdat hij altijd positief is. Een ander voordeel is dat berekeningen heel makkelijk gaan.

## Een simpel spelletje

We spelen met drie spelers.<figure class="wp-block-table">

<table>
  <tr>
    <td>
      <em>Naam</em>
    </td>
    
    <td>
      <em>Halli-Galli-spot tijd</em>
    </td>
    
    <td>
      <em>Op-de-bel-slaan tijd</em>
    </td>
    
    <td>
      <em>Opmerking</em>
    </td>
  </tr>
  
  <tr>
    <td>
      <strong>A</strong>rnoud
    </td>
    
    <td>
      0.5
    </td>
    
    <td>
      0.8
    </td>
    
    <td>
      Een gemiddelde jongen
    </td>
  </tr>
  
  <tr>
    <td>
      <strong>B</strong>eatrice
    </td>
    
    <td>
      0.2
    </td>
    
    <td>
      1.3
    </td>
    
    <td>
      Rekent snel, motorische vaardigheden blijven achter
    </td>
  </tr>
  
  <tr>
    <td>
      <strong>C</strong>oen
    </td>
    
    <td>
      1.0
    </td>
    
    <td>
      0.4
    </td>
    
    <td>
      Heeft nooit wiskunde gehad, maar bezit snelle vingers
    </td>
  </tr>
</table></figure> 

Wat is de kans dat A als eerste de bel slaat? Nouja, het kan zijn dat hij de Halli-Galli pas als laatste ziet, maar zo snel is dat hij als eerste de bel raakt. Andersom, hij kan de Halli-Galli als eerste zien, en alsnog niet als eerste de bel raken. Dus je kunt de twee dingen niet los zien.

Gelukkig mag je ze samennemen met de exponentiële verdeling. Dus, A heeft als gemiddelde win-tijd 0.5 + 0.8 = 1.3. (Vervolgens heeft B als win-tijd 1.5, en C heeft 1.4)

De kansen worden (volgens een standaardformule waarvan ik het bewijs schuldig ben):

<div class="wp-block-image">
  <figure class="aligncenter size-full"><a href="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/latex-image-12.png"><img decoding="async" loading="lazy" width="509" height="256" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/latex-image-12.png" alt="" class="wp-image-10930" /></a></figure>
</div>

A heeft de grootste kans een ronde te winnen. Dat was te verwachten, maar het betekent zeker niet dat hij altijd het spel wint. Hij kan namelijk fouten maken, én het hangt af van hoe groot de stapel is die hij wint.

## Een minder simpel spelletje

We introduceren de kans op een fout. Dus, iemand ziet een Halli-Galli terwijl die er niet is, of andersom. Ook veranderen we de win-tijden om het wat interessanter te maken.<figure class="wp-block-table">

<table>
  <tr>
    <td>
      <em>Naam</em>
    </td>
    
    <td>
      <em>Win-tijd</em>
    </td>
    
    <td>
      <em>Fout-kans</em>
    </td>
    
    <td>
      <em>Opmerking</em>
    </td>
  </tr>
  
  <tr>
    <td>
      <strong>A</strong>rnoud
    </td>
    
    <td>
      1.5
    </td>
    
    <td>
      0.025
    </td>
    
    <td>
      Steady as a rock
    </td>
  </tr>
  
  <tr>
    <td>
      <strong>B</strong>eatrice
    </td>
    
    <td>
      1.3
    </td>
    
    <td>
      0.075
    </td>
    
    <td>
      Steady as a slightly less steady rock
    </td>
  </tr>
  
  <tr>
    <td>
      <strong>C</strong>oen
    </td>
    
    <td>
      1.1
    </td>
    
    <td>
      0.15
    </td>
    
    <td>
      Steady as a wobbly chair
    </td>
  </tr>
</table></figure> 

De berekeningen worden lastiger (let er maar niet te veel op):

<div class="wp-block-image">
  <figure class="aligncenter size-full"><a href="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/latex-image-13.png"><img decoding="async" loading="lazy" width="578" height="516" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/latex-image-13.png" alt="" class="wp-image-10931" /></a></figure>
</div>

Datzelfde doen voor alle drie de spelers geeft de volgende resultaten:

  * Kans dat A een ronde wint = 0.318
  * Kans dat B een ronde wint = 0.336
  * Kans dat C een ronde wint = 0.346

Ondanks de enorme foutkans, wint C alsnog de meeste rondes vanwege zijn voordelige reactiesnelheid. Echter, dit zijn alleen de rondes waarin daadwerkelijk een Halli-Galli plaatsvindt.

Op dezelfde manier kunnen we de kans berekenen dat iemand een willekeurige ronde wint, terwijl diegene fout zit (en dus kaarten moet weggeven):

  * Kans dat A een ronde verliest = 0.022
  * Kans dat B een ronde verliest = 0.068
  * Kans dat C een ronde verliest = 0.85

Dit telt niet op tot 1, omdat er natuurlijk rondes zijn waarin niemand verliest, en er gewoon wordt doorgespeeld. Zoals je ziet is C er nu erg slecht vanaf, en moet in 85% van de gevallen twee kaarten weggeven. Ik ga er vanuit dat dit niet opweegt tegen het aantal kaarten dat hij wint, dus ik roep A uit tot de winnaar! Jeej! En nu?

## Een realistisch spelletje

Als laatste hoeven we alleen nog maar de kaarten te introduceren. Dit is het lastigste onderdeel. We moeten namelijk weten wat de kans is dat een Halli-Galli op het speelveld verschijnt. Omdat kaarten steeds opnieuw terug worden gestopt in iemands stapel, ga ik even geen rekening houden met welke kaarten al gespeeld zijn.

Laten we kijken wat de kans is dat een bepaalde soort er vijf op tafel heeft liggen (met drie personen):

<div class="wp-block-image">
  <figure class="aligncenter size-full"><a href="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/latex-image-14.png"><img decoding="async" loading="lazy" width="749" height="353" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/latex-image-14.png" alt="" class="wp-image-10933" /></a></figure>
</div>

Aangezien er vier fruitsoorten zijn, is de kans op een Halli-Galli: 0.027 * 4 = 0.108.

Het gemiddelde aantal kaarten dat iemand wint is dan ook 11 (afgerond), omdat je verwacht 1 in de 11 rondes een Halli-Galli tegen te komen.

_Opmerking_: dit klopt niet helemaal, omdat we dus volgorde niet meenemen. We gaan er nu vanuit dat de aardbeikaarten als eerste werden opgelegd, in een bepaalde volgorde. Uiteindelijk maakt het niet bijzonder veel verschil; het gaat me toch om de schatting.

## Wat moeten we hiermee?

Van deze getallen uitgaand, kunnen we het verwachte kaartverloop beschrijven van onze drie spelers. Elke keer als iemand een kaart speelt gelden de volgende kansen

  * A verliest 2 kaarten met kans 0.022 * (1 &#8211; 0.108) = 0.020  
    A wint (gemiddeld) 11 kaarten met kans 0.318 * 0.108 = 0.034
  * B verliest 2 kaarten met kans 0.065 * (1 &#8211; 0.108) = 0.058  
    B wint (gemiddeld) 11 kaarten met kans 0.336 * 0.108 = 0.036
  * C verliest 2 kaarten met kans 0.85 * (1 &#8211; 0.108) = 0.758  
    C wint (gemiddeld) 11 kaarten met kans 0.346 * 0.108 = 0.037

Natuurlijk heeft elke speler kans 1/3 om een kaart te verliezen. Namelijk, als ze aan de beurt zijn. Ofwel, de gemiddelde winst van de spelers is als volgt. (Waarbij een &#8220;ronde&#8221; even betekent elke keer dat een nieuwe speler een kaart oplegt.)

  * A heeft +0.04 winst elke ronde
  * B heeft -0.05 winst elke ronde
  * C heeft -1.439 winst elke ronde.

Dus, ja, A wint. Meestal. Gemiddeld genomen. Opvallend is dat bijna iedereen negatieve winst maakt, gemiddeld, dus de enige reden dat er iemand uiteindelijk wint is omdat ie toevallig een paar keer een abnormaal grote stapel wint.

_Wat moeten we&nbsp;**hiermee?**_**&nbsp;**Nu kunnen we flauw gaan doen.

Stel we hebben een speler die zijn hand bij de bel houdt, en er elke elf rondes meteen op slaat, zonder überhaupt te kijken wat de nieuwe kaart is. Die speler is zeker weten de eerste.

Zijn winst elke ronde is 1/11 \* (11 \* 0.108 &#8211; 2 * (1 &#8211; 0.108) &#8211; 3) = -0.33. Dat valt een beetje tegen. Het is veel beter dan speler C, en soort van in de buurt van B, maar toch niet heel erg goed.

Ofwel, ik denk dat het best kan werken om gewoon volgens een vast patroon te slaan, maar je moet dan wel een beetje geluk aan je zijde hebben dat je een keer een grote stapel kaarten wint. (En dat de medespelers niet bijzonder goed opletten, en dus een hoop fouten maken.)

## Dus voortaan gewoon random slaan en hopen op het beste?

Mwah, nee, ik denk dat er nog betere methodes zijn. Namelijk: **kaarten tellen**! Je telt welke kaarten al zijn geweest, en berekent daarmee de kans dat er een Halli-Galli aankomt. Ook sla je sneller als de stapel groter wordt; als jij een stapel van twintig kaarten wint, maakt het niet uit als je daarvoor 8 kaarten weg moest geven omdat je fout sloeg.

Ik wilde alles gewoon met de hand uitrekenen, maar ben bang dat ik nu toch een simulatie moet inzetten. Achja, kunnen we meteen de andere resultaten verifiëren. Én kunnen we met andere spelersaantallen werken, want ik heb geen zin om al die berekeningen opnieuw te doen voor 4 spelers, en dan weer voor 5, enzovoort.

## De Simulatie

De simulatie met onze 4 spelers (die 3 normale, en eentje die gewoon om de elf rondes een keer slaat) geeft het resultaat dat we zelf ook hadden gevonden (jeej, ik ben niet helemaal gek):<figure class="is-layout-flex wp-block-gallery-35 wp-block-gallery columns-2 is-cropped">

<ul class="blocks-gallery-grid">
  <li class="blocks-gallery-item">
    <figure><img decoding="async" loading="lazy" width="1031" height="529" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2017/09/CheckWiskunde.png" alt="" data-id="6850" class="wp-image-6850" /></figure>
  </li>
  <li class="blocks-gallery-item">
    <figure><img decoding="async" loading="lazy" width="1031" height="529" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2017/09/CheckWiskundePlot.png" alt="" data-id="6851" class="wp-image-6851" /></figure>
  </li>
</ul></figure> 

Speler 1 gaat het best, speler 2 en 4 minder goed, en speler 3 wint gewoon helemaal niks.

_Opmerking_: in de grafiek lijkt het alsof spelers terugkomen uit de dood. De regels stellen dat een speler die geen kaarten meer heeft in leven blijft totdat het huidige potje is afgelopen. Als de speler dit potje wint, namelijk, heeft ie weer kaarten en kan nog meedoen. Daarnaast zat er hier nog wel een fout in de grafiek-maak-code, maar die heb ik er pas later uitgehaald :p

Ik heb hem nog een keer gedaan, voor de zekerheid:<figure class="is-layout-flex wp-block-gallery-37 wp-block-gallery columns-2 is-cropped">

<ul class="blocks-gallery-grid">
  <li class="blocks-gallery-item">
    <figure><img decoding="async" loading="lazy" width="1031" height="529" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2017/09/MetFlauwStrategie.png" alt="" data-id="6853" class="wp-image-6853" /></figure>
  </li>
  <li class="blocks-gallery-item">
    <figure><img decoding="async" loading="lazy" width="1031" height="529" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2017/09/CheckFlauwStrategiePlot.png" alt="" data-id="6852" class="wp-image-6852" /></figure>
  </li>
</ul></figure> 

En dat geeft hetzelfde beeld. Zoals je ziet gaat onze flauwe speler 4 de hele tijd op en neer in het spelverloop (grafiek rechts) &#8211; maar in dit specifieke potje komt hij daarmee wel als winnaar uit de bus!

Hoe dan ook, speler 1 blijft de overduidelijke winnaar. Dat moet veranderen.

  * We verwisselen speler 3 met een flauwe speler die elke ronde op de bel slaat wanneer de stapel 11 of meer kaarten bevat.
  * We verwisselen speler 2 met een flauwe speler die om de vijf rondes op de bel slaat, alleen wanneer de stapel 11 of meer kaarten bevat.<figure class="is-layout-flex wp-block-gallery-39 wp-block-gallery columns-2 is-cropped">

<ul class="blocks-gallery-grid">
  <li class="blocks-gallery-item">
    <figure><img decoding="async" loading="lazy" width="1030" height="529" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2017/09/FlauweSpelerHogeStapel.png" alt="" data-id="6855" class="wp-image-6855" /></figure>
  </li>
  <li class="blocks-gallery-item">
    <figure><img decoding="async" loading="lazy" width="1030" height="529" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2017/09/FlauweSpelerHogeStapelPlot-1.png" alt="" data-id="6857" class="wp-image-6857" /></figure>
  </li>
</ul></figure> 

Zoals je ziet, speler 3 is niet bepaald succesvol, maar speler 2 wel degelijk! Ze slaat alleen op de bel als de stapel groot is, maar ze spreid haar kansen, en slaat alleen eens in de vijf beurten. Dat lijkt te werken. In het spelverloop zien we waarom: speler 3 gaat vrij snel ten onder, terwijl speler 2 steeds en grote slag slaat en het lang volhoudt. (De potjes worden wel lang zeg.)

Hoewel onze zeer flauwe speler die gewoon om de 11 rondes slaat (speler 4) het ook niet onaardig doet, wint speler 1 nog steeds. Dit kan beter!

## De Beste Strategie

We verwisselen speler 3 met een speler die alleen speelt als de kans groot is dat er een Halli-Galli aankomt.

_Hoe kan hij dat ooit weten?_ Kaarten tellen, en een beetje logica. Ik introduceer drie mogelijke situaties:

  * _Onmogelijk_:&nbsp;Als er al (meer dan) 5 van een fruitsoort ligt, van de vorige ronde, kan er natuurlijk geen Halli-Galli komen in die soort.
  * _Onwaarschijnlijk:&nbsp;_Als er al een 0, 1 of 4 van die soort ligt, is de kans op Halli-Galli klein.
  * _Waarschijnlijk_:&nbsp;Als er 2 of 3 van die soort ligt, is de kans groot.

Dit heb ik allemaal samen gegooid in de volgende formule: sla op de bel als

_Waarschijnlijk * 2 + Onwaarschijnlijk &#8211; Onmogelijk >= 4_

Bijvoorbeeld, stel je speelt met z&#8217;n vieren. De vorige drie kaarten waren 2 aardbeien, 1 framboos, en 5 bananen, dan geeft de formule 1*2 + 2 &#8211; 1 = 3. Dus niet de bel slaan!

Anderzijds, als de vorige drie kaarten 2 aardbeien, 1 framboos en 2 bananen waren, dan geeft de formule 2*2 + 2 = 6. Dus wel de bel slaan!

Dit is een doorslaand succes:<figure class="is-layout-flex wp-block-gallery-41 wp-block-gallery columns-2 is-cropped">

<ul class="blocks-gallery-grid">
  <li class="blocks-gallery-item">
    <figure><img decoding="async" loading="lazy" width="1030" height="529" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2017/09/FlauweMaarSlimmeSPeler.png" alt="" data-id="6858" class="wp-image-6858" /></figure>
  </li>
  <li class="blocks-gallery-item">
    <figure><img decoding="async" loading="lazy" width="1030" height="529" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2017/09/FlauweMaarSlimmeSpelerPlot.png" alt="" data-id="6859" class="wp-image-6859" /></figure>
  </li>
</ul></figure> 

Speler 3 degradeert de rest tot amateuristische dwergen!

## Wat hebben we geleerd?

Vergeet reactiesnelheid! Tel op je gemak wat er op tafel ligt, en pas de formule toe. Wanneer de volgende speler zijn kaart omdraait, sla jij gewoon alvast op de bel, zonder te zien wat het is &#8211; en meestal zul je gelijk hebben.

En dan wil niemand meer Halli Galli met je spelen. En dat is iets goeds, want dan heb je tijd over om goede en interessante spellen te gaan doen.

## De Code

De code + plots zijn te vinden in deze Google Drive folder: [Halli Galli (Simulatie)][1]

 [1]: https://drive.google.com/drive/folders/1IFaeB0kBHi5WnbXpwR63v3PJvkBW8sP-?usp=sharing