---
title: Freds Wilde Wereld – Deel 3
author: hetisdepanda
type: post
date: 2017-03-27T16:17:24+00:00
url: /visuele-fratsen/freds-wilde-wereld-deel-3/
categories:
  - Crappy Cartoons
  - Visuele Fratsen

---
<img decoding="async" src="http://res.cloudinary.com/nietdathetuitmaakt/image/upload/v1493117346/Fred-WW-3.jpg" />

Ja, ik weet dat Fred&#8217;s huis maar één verdieping heeft, en de postbode is gigantisch (of Fred&#8217;s ouders zijn dwergen). Maar zo gaan die dingen.