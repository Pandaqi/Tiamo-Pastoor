---
title: De Inhaalparadox
author: hetisdepanda
type: post
date: 2016-10-30T15:00:10+00:00
url: /gewoon-een-gedachte/de-inhaalparadox/
categories:
  - Gewoon een Gedachte

---
We zijn nooit alleen in het verkeer. Je vindt dat misschien ongelofelijk vervelend, zeker als je net in de file hebt gestaan of bent aangereden, maar ik denk dat je er raar van staat te kijken als er ineens _helemaal niemand_ op straat is. Niet alleen zou de hele wereld dan veranderen in een soort spookachtig, post-apocalyptisch oorlogsgebied, het zou ook vooral heel erg saai zijn om naar je bestemming te moeten reizen.

Maar daar wil ik het niet over hebben, ik wil het hebben over _De Inhaalparadox_. Je kent het wel: je bent lekker je eigen tempo aan het fietsen, en je komt iemand tegen die wat zachter fietst dan jij, dus je haalt diegene in en zet je tocht vrolijk voort. Maar dan kom je bij een stoplicht, en de goede samaritaan dat je bent, stop je netjes. Maar, de persoon die je net hebt ingehaald rijdt gewoon door rood (of het woord _net_ groen, waardoor die persoon door kan rijden en jij nog moet opstarten)! Schandalig! Nouja, het probleem is vooral dat je dan die persoon _wéér_ moet gaan inhalen.

<!--more-->

Als dit één keer gebeurt is het gewoon een beetje apart, die ander denkt waarschijnlijk dat jij gek bent (en jij denkt dat die ander een malloot is), maar dat gaat wel. Maar als je dit een aantal stoplichten na elkaar meemaakt, wordt het een beetje gênant. Ik bedoel, op dat moment ben je gewoon praktisch naast iemand aan het fietsen. Je kunt dan eigenlijk het beste die persoon niet meer inhalen, maar er gewoon naast gaan fietsen en een gesprek mee beginnen. Of alleen naast gaan fietsen, maar dat valt niet zo goed bij de meeste mensen.

Nou is deze stoplichtensituatie nog een vrij bekend fenomeen, maar er zijn tal andere situaties waarin mensen elkaar oneindig blijven inhalen. Zo gebeurt het misschien dat er ineens een groepje pubers met z&#8217;n vijven naast elkaar voor je fietst, en je weet dat er iemand achter je zit (want die heb je net ingehaald), dus je moet wachten tot hij/zij _jou_ weer heeft ingehaald voordat je zelf die pubergroep kan inhalen.

Of iemand wil afslaan, maar weet niet zeker of er iemand achter haar fietst, dus ze steekt haar hand uit maar remt toch voor de zekerheid. En ja, dan weet jij dus ook niet wat ze gaat doen, dus jij komt ook plots tot stilstand, en dan sta je daar een beetje raar een halve minuut achter iemand te wachten op niks. En al die mensen die je net had ingehaald, halen jou weer in en de cyclus begint van voor af aan.

Maar, en dit vind ik persoonlijk het vervelendste eigenlijk, je hebt altijd nog het zestig-plusser-syndroom. Ik weet niet waarom, maar ongeacht de fysieke gesteldheid of soort fiets van de zestig-plusser voor me, ze laten altijd de symptomen van het syndroom zien. Eerst fietsen ze netjes door, dan ineens besluiten ze te stoppen met trappen voor een paar seconden, want ze willen het zichzelf extra zwaar maken? Eerst fietsen ze netjes aan de rechterkant van het fietspad, en dan ineens besluiten ze in het midden te gaan fietsen, omdat ze dat kinderspelletje doen waarbij ze precies over de streep willen fietsen? Ik snap het niet, maar ouderen durf ik nooit in te halen, en ze voegen vaak dik tien minuten reistijd toe. En ik wil eigenlijk ook niet bellen, want dan schrikken ze zich vaak kapot en dan duurt het weer vijf minuten voordat de een achter de ander is gaan fietsen.

Hoe dan ook, de inhaalparadox achtervolgt menig mens elke dag, en kan soms erg vervelend zijn. Maar het voegt ook iets leuks toe aan een lange, saaie fietstocht. Ik heb regelmatig dat ik toevallig mijn hele route samen met iemand fiets, en dan vind ik het leuk om dingen uit te proberen. Zo kan ik bijvoorbeeld eerst iemand inhalen, en dan op een stuk lager tempo voor ze fietsen &#8211; kijken of ze mij weer inhalen, en dat dan herhalen. Of ik kan juist de hele route achter iemand blijven fietsen. Zeker als ik dan ga neuriën beginnen mensen vaak steeds vaker achterom te kijken waar dat gezoem toch steeds vandaan komt.

Oké, misschien ben ik soms irritant in het verkeer, maar je moet wat. Als het aan mij lag was de inhaalparadox er niet, maar andere fietsers vinden het gewoon nodig om raar te rijden :p En daar probeer ik dan maar mijn voordeel mee te doen.