---
title: Art Hockey!
author: hetisdepanda
type: post
date: 2020-03-07T17:39:49+00:00
url: /gewoon-een-gedachte/art-hockey/
featured_image: https://nietdathetuitmaakt.nl/wp-content/uploads/2020/03/art_hockey_namelogo_result.webp
categories:
  - Gewoon een Gedachte
  - Superieure Spellen

---
Zoals beloofd in mijn vorige artikel over de mobiele spelletjesmarkt, heb ik een klein mobiel spelletje gemaakt en gratis online gezet!

Het spel heet **Art Hockey** en dit is de officiële spelpagina: [Art Hockey &#8211; Multiplayer Drawing Sport][1]

Het spel is een variant op Air Hockey. Maar in plaats van een &#8220;paddle&#8221; heeft elke speler een eigen gebiedje waarin je alles mag tekenen wat je wilt! Met die lijnen moet je de bal afweren van je eigen goal én in de goal van je tegenstander zien te schieten.<figure class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-4-3 wp-has-aspect-ratio">

<div class="wp-block-embed__wrapper">
  <span class="embed-youtube" style="text-align:center; display: block;"></span>
</div></figure> 

Mijn hoofddoel voor dit spel was natuurlijk: een heel leuk spelletje maken dat je met vrienden en familie kunt spelen op één smartphone 🙂

Dat is gelukt! De mensen waarmee ik het heb gespeeld vonden het ietwat chaotisch, maar ze begrepen het idee meteen en wilden steeds nóg een potje spelen.

Mijn andere doelen met dit spel waren &#8230;

  * Een nieuw programma uitproberen (voor spellenmaken)
  * Meer ervaring opdoen met spelletjes maken, uitbrengen én marketen.
  * En informatie verzamelen over de mobiele spellenmarkt: valt er geld te verdienen met advertenties? Of toch liever betaalde apps? Je weet het pas als je de spellen maakt en de data verzamelt 🙂

Binnenkort zullen we zien of dat succesvol was, als ik mijn volgende spel maak en uitbreng.

Tot dan!

 [1]: http://pandaqi.com/art-hockey