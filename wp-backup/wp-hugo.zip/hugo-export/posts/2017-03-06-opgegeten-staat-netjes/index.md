---
title: Opgegeten staat netjes
author: hetisdepanda
type: post
date: 2017-03-06T17:08:11+00:00
url: /gewoon-een-gedachte/opgegeten-staat-netjes/
categories:
  - Gewoon een Gedachte

---
Je komt thuis van een lange, zware dag werk, en je hebt honger. Je herinnert je vaag dat er vanochtend nog twee lekkere broden lagen, en een pak pure vlokken. Heerlijk, je hebt er zin in. Verwachtingsvol sla je de deur open, en wat tref jij met grote verbazing aan? Er liggen alleen nog twee kontjes van het brood, en er zit nog maar een mini beetje in het pak vlokken. Je hele humeur is verpest, en je vervloekt alle mensen die bij jou in huis leven. Je besluit naar de supermarkt te gaan, maar niet om brood of vlokken te kopen, maar een reep chocolade om je humeur weer op peil te brengen. Want als zij het niet opmaken of nieuw voedsel halen, doe jij het ook niet.

Waarom doen mensen dat? Waarom laat iedereen altijd een piepklein beetje in een pak zitten? Ik heb het meerdere malen gevraagd aan experts op dit gebied (mijn gezinsleden), en het antwoord is altijd: &#8220;dat doe ik niet expreeees, dat laatste beetje paste gewoon echt niet op mijn brood er bij.&#8221; Natuurlijk is dat niet waar. Het echte antwoord is: &#8220;we zijn lui en willen de verpakking niet opruimen, en ook niet er op aan worden gekeken dat we geen boodschappen doen.&#8221;

<!--more-->

Ik bemerk dit probleem vaak. En hoewel ik me er van tijd tot tijd wel aan stoor (omdat het betekent dat ik gewoon veel te weinig eten heb voor die dag), heb ik gemerkt dat ik het ook wel weer fijn vindt. Als iets bijna leeg is, dan maak ik het _juist_ op. Als er drie bijna-lege pakken in de kast staan, gebruik ik ze lekker allemaal, gooi ze in de prullenbak, en ineens is de hele keuken een stuk opgeruimder. Als er nog maar een paar sneetjes brood in de broodtrommel liggen, verspreid over drie verschillende zakken, maak ik er een tosti van en ineens is de hele aanrecht weer spic en span.

Sterker nog, als jij je enorm stoort aan dit fenomeen, kun je deze techniek in jouw voordeel gebruiken! Stel je ziet &#8217;s avonds nog iets lekkers in de koelkast staan, iets dat je morgenochtend bij het ontbijt wil eten. Dan maak je dat expres nét niet op. Op die manier zal geen van je huisgenoten het opeten, want ze hebben geen zin om het weg te gooien en/of zelf nieuwe boodschappen te doen, en kan jij met een gerust hart je bed in duiken. Op deze manier kun je eten voor jezelf reserveren, door het een beetje op te eten, maar niet helemaal.

Een andere optie is natuurlijk gewoon mensen er op aanspreken en er op vertrouwen dat mensen daadwerkelijk luisteren en moreel juiste acties trachten te ondernemen. Oh nee, wacht, dat was een droom van mij.

<p style="color:gray;">
  Het werkt natuurlijk niet als twee (of meer) mensen ditzelfde idee hebben. In dat geval is het ieder voor zich, en kun je het beste iets maar meteen helemaal opvreten het moment dat het er nog is. Ik weet het, ik heb zoveel vertrouwen in de mensheid.
</p>