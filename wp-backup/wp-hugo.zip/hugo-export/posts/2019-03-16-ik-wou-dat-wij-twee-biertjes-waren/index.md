---
title: Ik wou dat wij twee biertjes waren
author: hetisdepanda
type: post
date: 2019-03-16T16:00:36+00:00
url: /toverende-taal/genezende-gedichten/ik-wou-dat-wij-twee-biertjes-waren/
categories:
  - Genezende Gedichten

---
ik wou dat wij twee biertjes waren  
samen in een krat  
jij die nooit meer weg mocht rijden  
en ik was jou nooit (ladder) zat

&nbsp;

(_Dit is een heel oud gedicht dat ik zojuist terugvond. En ja, het klopt niet echt, want als ik een biertje was in een krat, was ik juist altijd ladderzat (denk ik). Maar het idee is lief._)