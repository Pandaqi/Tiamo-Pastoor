---
title: De Apostrof-s
author: hetisdepanda
type: post
date: 2017-09-27T14:47:42+00:00
url: /gewoon-een-gedachte/de-apostrof-s/
categories:
  - Gewoon een Gedachte
  - Toverende Taal

---
Het kan zijn dat ik vroeger nooit goed oplette, maar ik kwam er pas laatst achter dat één van de grammaticaregels in mijn hoofd van geen kant klopt. Ik dacht dus: als je wil laten zien dat iets bezittelijk is, dan doe je er een apostrof + s achter — _altijd_. Bijvoorbeeld:

<p style="padding-left: 30px;">
  Die fiets is van Jan => Het is Jan&#8217;s fiets<br /> Van wie is die olifant? => Het is Laura&#8217;s olifant!<br /> Heb jij Dennis nog gezien? => Nee, maar ik heb wel Dennis&#8217;s auto gezien. (Ik wist dat dit niet klopte, maar ik wist vroeger niet hoe het wel moest, dus ik vermeed gewoon alle woorden die eindigden op een sisklank.)
</p>

Blijkbaar is dit dus niet helemaal waar. Mijn wereld staat op zijn kop. _Hoe kwam ik hier achter?_ Word bleef maar rode kringeltjes onder mijn bezittelijke woorden zetten, terwijl ik dacht dat ik niks verkeerd deed. Toen ik het opzocht, bleek het de **genitief-s** te heten, en heel wat meer regeltjes te hebben. (Ik wilde dit artikel dan ook eerst &#8220;Ah, op die genitiefiets&#8221; noemen.)

<!--more-->

Overal waar ik zocht kwam ik een lange lijst van uitzonderingen en regels tegen. Dat vond ik erg verwarrend en moeilijk te onthouden. Dus, ik heb voor mezelf alles samengevat met twee regels:

<p style="padding-left: 30px;">
  <em>Als het de uitspraak van het woord niet verandert, moet je de apostrof weglaten.<br /> Als het woord eindigt op een sisklank, zet je juist alleen de apostrof er achter.</em>
</p>

Wat bedoel ik hiermee? Nou, laten we de voorbeelden van daarboven corrigeren:

<p style="padding-left: 30px;">
  Die fiets is van Jan => Het is <strong>Jans</strong> fiets.
</p>

<p style="padding-left: 60px;">
  Of je nou <strong>Jans</strong> of <strong>Jan&#8217;s</strong> schrijft, je zegt hetzelfde, dus de apostrof moet weg.
</p>

<p style="padding-left: 30px;">
  Van wie is die olifant? => Het is <strong>Laura&#8217;s</strong> olifant.
</p>

<p style="padding-left: 60px;">
  De laatste <strong>-a</strong> van Laura, is een lange a. (Als in <em>kaas</em>.) Als je de apostrof weglaat, en dus <em>Lauras</em> schrijft, krijg je een korte a. (Als in <em>ananas</em>.) Dus de apostrof moet blijven.
</p>

<p style="padding-left: 30px;">
  Heb jij Dennis nog gezien? => Nee, maar ik heb wel <strong>Dennis&#8217;</strong> auto gezien.
</p>

<p style="padding-left: 60px;">
  De laatste letter van Dennis is een <strong>-s</strong>, en dat is natuurlijk een sisklank. (Net als, bijvoorbeeld, <strong>-z</strong>). Dus we zetten alleen een apostrof neer, en klaar is kees.
</p>

Ik denk dat ik deze simpele grammaticaregel vroeger heb genegeerd omdat ik het er gewoon niet mee eens was. Het lijkt me namelijk sterk dat dit niet zo is uitgelegd op de basisschool. Ja, en, wat ook raar is, is dat ik het waarschijnlijk de hele middelbare school lang verkeerd heb gedaan zonder er een opmerking over te krijgen. Vroeger vond ik waarschijnlijk iets als _&#8220;Het is de gemeentes fout_.&#8221; lelijk, en schreef ik alles in de uitgebreide vorm: &#8220;_Het is de fout van de gemeente.&#8221;_ (Hoewel ik betwijfel dat ik als kind de gemeente overal de schuld van gaf.)

Maar, nu ik het weet, vind ik het eigenlijk wel mooier. Nu ik volwassen ben, vind ik apostrofs lelijk! Het onderbreekt de mooie flow van de letters en de woorden, net als dat ik een Engels woord door een Nederlandse zin wel begrijp, maar erg storend vind.

Voorbeeldje: laten we eens kijken naar de eerste zin van het boek _Spijt!_ van _Carry Slee._

<p style="padding-left: 30px;">
  <em>Met zijn jack nog halfopen en een snee brood in zijn hand racet David de straat uit.</em>
</p>

Het kostte mij vele pogingen aleer ik besefte dat _racet_ geen oubollig Nederlands woord was (&#8220;ach en wee, ik ben mijn schleutels verlooren&#8221; &#8220;ach, schat, heb je al in de racet gekeken?&#8221;), en dat David ook geen _racket_ in zijn hand droeg.