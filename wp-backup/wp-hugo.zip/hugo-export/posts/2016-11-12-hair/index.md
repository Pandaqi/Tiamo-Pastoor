---
title: Hair
author: hetisdepanda
type: post
date: 2016-11-12T22:27:51+00:00
url: /gewoon-een-gedachte/hair/
categories:
  - Gewoon een Gedachte

---
Als iemand &#8220;Hair&#8221; noemt, dan zegt vrijwel iedereen meteen &#8220;oh dat is die hippie-musical&#8221;. Velen kunnen waarschijnlijk zelfs meerdere nummers noemen en zingen, zoals Aquarius en Let The Sun Shine. Van al die honderden grote musicals die er zijn gemaakt, is Hair blijkbaar eentje die heeft overleeft en bij iedereen is blijven hangen. Jaren geleden, als klein kind, zag ik de musical (in Nederland, in het Engels), en ik snapte er niks van en dacht &#8220;dit is vast iets wat je alleen begrijpt als je volwassen bent&#8221;. Vanavond zag ik de musical voor de tweede keer (half-Nederlands, half-Engels? het was raar), en ik kan concluderen: nee, dit is niet iets wat alleen volwassenen begrijpen.

Ik ging naar Hair met de gedachte dat het een echte klassieker was. Beren van nummers volgden elkaar op, monologen en dialogen die mensen aan het denken zetten, sterk acteerwerk, zeer emotionele elementen &#8211; noem het maar op. Ik verwachtte iets van het niveau Les Miserables, maar ik kreeg iets dat ik niet eens kan classificeren.

<!--more-->

In het kort, Hair gaat over een groep hippies die problemen krijgen. Om de sfeer er meteen in te krijgen begint het met het nummer Aquarius, waarin vooral astrologische feitjes worden opgedreund. Niks mis mee natuurlijk, maar dit nummer wordt snel opgevolgd door nog een nummer om de sfeer te zetten. En nog een nummer, waarin middels allerlei ordinaire handelingen nogmaals de hippie-sfeer wordt versterkt en duidelijk wordt dat werkelijk alle karakters _exact_ dezelfde persoonlijkheid hebben.

Ik ben niet tegen elke vorm van vunzigheid op het toneel, maar het is gewoon vaak niet nodig. Ik vind het jammer als een musical niks goeds meer kan bedenken en het daar maar mee opvult. In dit geval stond op een gegeven moment één van de personages letterlijk naakt op het toneel te dansen. Terwijl het een redelijk persoonlijk nummer was dat door één persoon werd gezongen.

Maar goed, natuurlijk zit er wel een verhaal in. Mensen leven het goede hippie-leven, maar beseffen dat ze dan van school worden getrapt en niks meer mogen, en hebben dan geen doel meer in het leven en worden gek. Eén van hen moet het leger in, wil niet, maar wil uiteindelijk toch wel. De ander komt er op dat moment achter dat hij niet weet wat hij moet, al helemaal niet als die andere persoon weg is. Ondertussen slapen alle meisjes met iedereen. Hoe het eindigt? Je kunt het waarschijnlijk raden, maar ik zal het niet verklappen :p

Het punt is, dat het geen musical voor het verhaal is. Het thema is de oorlog, en dat mensen dat helemaal niet willen, en het gaat over de jeugd en uitvinden wat je met je leven moet. Maar dit wordt helemaal niet sterk gebracht, of actueel gemaakt. In plaats daarvan willen dansende mensen de hele musical het juiste gevoel opwekken van vrijheid, en liefde, en vrede op aarde. Ook prima, maar waarom kiezen voor de moeilijke weg als het via het verhaal veel makkelijker en beter kan? Je had iedereen een eigen karakter kunnen geven dat op een manier bijdraagt en confronteert, je had nummers betekenisvolle tekst kunnen geven _én_ sfeer, je had een logisch verhaal kunnen hebben dat niet langzaam op gang komt en dan plots in tien minuten _supersnel_ er doorheen word gejaagd.

Iedereen zijn ding, dus ik zal geen harde mening vellen over de musical. Maar ik zal wel zeggen dat ik niet snap waarom dit zo&#8217;n klassieker is. Ik heb vele kleine producties gezien, die misschien hoogstens een jaartje toeren en een cast van zeven mensen hebben, die in alle opzichten Hair voorbij streven. En toch word Hair keer op keer teruggehaald en steeds nóg uitbundiger, nóg ordinairder, nóg swingender uitgevoerd. (Deze keer hadden ze zelfs projecties op allerlei beeldschermen!) Kortom; als mij de kans werd gegeven, zou ik niet opnieuw naar Hair gaan, ik heb liever dat mensen tijd en geld steken in originele, kleine producties.

(Het moet wel gezegd worden dat William Spaaij weer fantastisch was. Hij danst, zingt, springt, acteert alsof het niets is. Aan de andere kant, was er één figuur dat steeds een coupletje had in elk nummer (ze was de geest? het geweten? de ziel? iemand die werk nodig had?), maar _veel_ te hard stond en niet laag kon zingen. Dus dan was je lekker aan het luisteren, en dan hoorde je ineens een superhoge schelle toon overal doorheen snijden. En dan moest ze een andere, iets lagere toon zingen, maar dan kreeg ze ineens een halve fluisterstem die om de juiste noot heen wobbelde. Natuurlijk, het is gênant zoiets tegen iemand te zeggen (nadat ze de rol heeft gekregen), maar het lijkt me sterk dat de rest van de cast deze vocale missers niet opvielen. Of ze vielen wel op, maar ze dachten &#8220;meh, het gaat toch om de sfeer&#8221;. In dat opzicht deden ze het hartstikke goed.)

&nbsp;