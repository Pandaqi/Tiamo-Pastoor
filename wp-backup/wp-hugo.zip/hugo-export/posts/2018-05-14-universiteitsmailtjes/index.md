---
title: Universiteitsmailtjes
author: hetisdepanda
type: post
date: 2018-05-14T11:15:14+00:00
url: /toverende-taal/aardige-anekdotes/universiteitsmailtjes/
categories:
  - Aardige Anekdotes
  - Gewoon een Gedachte
  - Toverende Taal

---
Hier is een harde waarheid: de meeste instellingen vertrouwen vrijwel volledig op email, maar weten niet hoe ze het moeten gebruiken. Ze weten wel hoe ze ontvangers kunnen opgeven, of hoe verzenden werkt, maar missen het meest cruciale onderdeel: _de informatie die ze willen communiceren daadwerkelijk overbrengen._

Eén van de grote boosdoeners is de universiteit. Elf dagen geleden kreeg ik een mailtje met het volgende onderwerp: **Wachtwoord wijzigen**.

Ik denk: &#8220;_oeh, zal er misschien iets gehackt zijn? Moet ik voor de zekerheid mijn wachtwoord veranderen?&#8221;_

Ik klik erop en wordt begroet door een horrorshow van een mailtje. (Merk op: door het mailtje heen stonden ook enkele referenties naar hetzelfde mailtje in het Engels, maar die heb ik voor de duidelijkheid weggelaten.)

<!--more-->

<div style="border-left: 2px solid gray; padding-left: 5px; margin: 10px 20px 10px 20px;">
  <strong>Wachtwoord wijzigen</strong><br /> Beste student,<br /> Om ervoor te zorgen dat niemand anders toegang krijgt tot jouw informatie heb je een sterk en goed onderhouden wachtwoord nodig. (<em>Hier verandert ineens het lettertype.</em>) Daarom vraagt de universiteit nu alle studenten om eenmalig het wachtwoord te wijzigen. (<em>Hier verandert ineens weer het lettertype.</em>)
</div>

<div style="border-left: 2px solid gray; padding-left: 5px; margin: 10px 20px 10px 20px;">
  <strong>Hoe kun je je wachtwoord wijzigen?</strong><br /> Wijzig je wachtwoord als je aanwezig bent op de campus en ingelogd op het campusnetwerk, dat werkt gemakkelijker dan buiten de campus. Ga daarvoor naar _deze pagina_.Kies de optie ‘change password’. Je kunt een wachtwoord kiezen dat minstens 8 tekens lang is en minimaal een hoofdletter, een cijfer en speciaal teken bevat. Na het wijzigen wordt je wachtwoord gelijk in alle universiteitsapplicaties zoals Canvas en Osiris aangepast en werkt op verreweg de meeste apparaten optimaal.
</div>

Daaronder staat nog een hoop tekst, maar dat is gewoon de vriendelijke groet en alle functietitels van de mailschrijver. (En dus dezelfde mail in het Engels.)

Ik zie het alweer. Precies wat ik dacht: veiligheidsmaatregelen. Altijd maar die websites die willen dat je elk half jaar een ander wachtwoord neemt &#8211; verschrikkelijk!

Ook herinnerde ik dat ik ooit mijn wachtwoord wilde veranderen op mijn studielaptop (want het standaardwachtwoord was moeilijk te onthouden), EN DAT MOCHT NIET. Dus nu zit dat verschrikkelijke wachtwoord voor eeuwig in mijn hoofd (en typevingers) gebrand. Ik ging het echt niet meer veranderen. Niet zo vlak voor de finish (van mijn studie; ik ging er niet vanuit dat mijn laptop het binnenkort zou begeven).

## Elf dagen later &#8230;

Elf dagen vliegen voorbij, waarin ik gewoon naar buiten ga, andere dingen doe en een leven buiten de campus leef. Ineens ontvang ik niks meer van de universiteit. Ik kan ook nergens meer inloggen. Wat? Toch maar dat mailtje verder lezen.

<div style="margin: 10px 20px 10px 20px; border-left: 2px solid gray; padding-left: 5px;">
  <strong>Tien dagen de tijd</strong><br /> Na ontvangst van deze e-mail heb je 10 dagen de tijd om je wachtwoord te wijzigen, daarna kun je met het oude wachtwoord niet meer inloggen en word je bij het opstarten gevraagd eerst je wachtwoord te wijzigen. Voor meer informatie en veel gestelde vragen over het wijzigen van je wachtwoord kun je op _deze intranetpagina_ kijken.
</div>

<div style="margin: 10px 20px 10px 20px; border-left: 2px solid gray; padding-left: 5px;">
  Met vriendelijke groet,<br /> Henkiepenkie Tekorthempie (<em>niet de echte naam natuurlijk; zou wel humor zijn overigens</em>)<br /> Chief Information Security en Privacy Officer
</div>

AAAAH. Dus ik snel proberen mijn wachtwoord te wijzigen, maar ja, dat was geen succes. Het was niet alleen _moeilijker_ buiten de campus, het was ONMOGELIJK buiten de campus. Ik kreeg steeds de (voorspelbare) error: &#8220;je moet op de campus zijn om deze pagina te bezoeken&#8221;. Dus nu moet ik wachten tot ik op de campus terugkeer om überhaupt iets studiegerelateerds te doen.

De eerste vraag is natuurlijk: _wie geeft mensen maar 10 dagen voor zoiets essentieels?_ We krijgen 30 dagen om te bedenken of dat gekochte shirt ons wel past, we krijgen zelfs 30 dagen om te bedenken of die koker tennisballen wel aan onze wensen voldoet — maar nee hoor, het wachtwoord voor al je studiegerelateerde zaken moet ineens binnen 10 dagen veranderd.

Ze hebben ook geen herinnering gestuurd. (Of wel, maar die heb ik niet binnengekregen omdat ik niet meer op mijn mail kan :p) Ik moet me nu schuldig voelen dat ik hard aan het werk was, in plaats van de hele dag mijn mail checken.

Maar de tweede vraag is: _waarom begint het mailtje daar niet mee?_ Het is niet &#8220;de universiteit vraagt of jij je wachtwoord wil veranderen&#8221;, het is &#8220;van de universiteit MOET je hem binnen 10 dagen veranderen.&#8221; Ze geven ook verder geen enkele reden.

Ik weet wel zeker dat niemand ooit mijn oude onmogelijke wachtwoord ging raden, terwijl ik ook zeker weet dat studenten hun wachtwoord nu veranderen in iets wat enorm voor de hand ligt. (Denk aan &#8220;Jantje1995!&#8221;, &#8220;Student1234@&#8221;, en &#8220;W8woord!&#8221;)

**Opmerking:** een technische universiteit zou beter moeten weten. Als je zulke restricties op het wachtwoord legt, worden ze juist makkelijker te kraken. Er zijn minder mogelijkheden voor de hacker om uit te proberen, omdat hij al zeker weet dat er een getal inzit, en een speciaal teken, etc. Je kunt het beste studenten dwingen om een zin van minstens 20 letters te nemen. (Zo gebruikte ik vroeger _de kabouterfee neemt stiekem kabouters mee_, maar dan zonder spaties.)

## Mijn versie van de mail

Dit hele mailtje is, in mijn ogen, gefaalde communicatie. (Natuurlijk, ik had zelf het bericht ook secuur moeten aflezen, maar daar gaat het even niet om.)

Die eerste zin van het bericht is onzin: het hele _doel_ van een wachtwoord is zorgen dat anderen niet bij jouw informatie komen. Vervolgens hebben de kopjes een verkeerde volgorde. Ze kunnen daarentegen ook geheel weg, want ze bevatten informatie die ook op de wachtwoord-verander pagina of additionele FAQ had gekund.

Zo&#8217;n laatste regel, die veel &#8220;professionals&#8221; bij hun mailtjes willen zetten, vind ik ook raar: _Chief Security and Privacy Officer._

Ten eerste: niemand die het leest heeft iets aan die informatie. (&#8220;Hmm, ik vertrouw dit mailtje niet helemaal &#8230; wacht, _Privacy Officer_?! JA! Ik ga _al_ mijn wachtwoorden drie keer veranderen!&#8221;)

Ten tweede: het leidt af. Omdat het de laatste regel is van de mail, en helemaal op zichzelf staat (met witruimte eromheen), krijgt het automatisch meer aandacht dan de belangrijke tekst. Visueel ontwerpen 101.

Ik zou het bericht zo herschrijven:

<div style="border-left: 2px solid gray; padding-left: 5px; margin: 10px 20px 10px 20px;">
  <b>Wachtwoord wijzigen</b><br /> Van de universiteit <em>moet</em> jij jouw wachtwoord <em>binnen 30 dagen</em> wijzigen.<br /> <strong>Waar kan ik mijn wachtwoord wijzigen?</strong> _deze link_<br /> <strong>Waar moet mijn wachtwoord aan voldoen?</strong> Minstens 20 letters, verder niks.<br /> <strong>Verder nog iets? </strong>Om de een of andere vage reden moet je op de campus zijn om het te doen.<br /> <strong>Vragen?</strong> Contacteer Henkiepenkie op &#8230;
</div>

Tada! Je hoeft niet eens uit te leggen waarom, want iedereen gaat ervan uit dat het &#8220;voor de zekerheid&#8221; en &#8220;uit beveiligingsoogpunt&#8221; is. Je kunt dit wel toevoegen, maar het is een beetje een holle frase. (Alsof iemand elke dag een krant bij jou door de brievenbus gooit, en erbij schreeuwt &#8220;OMDAT JE EEN ABONNEMENT HEBT&#8221;.)

Mocht je dit lezen en denken dat je ooit nog een formele mail gaat versturen, hou dan in je achterhoofd het motto: &#8220;communicatie kan altijd beter!&#8221;

**Update:** het is inmiddels gelukt buiten de campus. Ik weet niet precies hoe. Ik heb alle applicaties die verbonden waren met mijn universiteitsaccount opengezet, totdat ik eentje vond die het gek genoeg nog wél deed op mijn oude wachtwoord. (Outlook; dat blijft ook een raar programma.) Via Outlook kon ik het wachtwoord aanpassen, en toen heb ik mijn wachtwoord aangepast NAAR PRECIES HETZELFDE WACHTWOORD DAT IK AL HAD.

Ha, dat zal ze leren.