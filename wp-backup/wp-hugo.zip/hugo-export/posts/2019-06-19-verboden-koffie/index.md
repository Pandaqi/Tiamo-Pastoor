---
title: Verboden koffie
author: hetisdepanda
type: post
date: 2019-06-19T16:00:25+00:00
url: /toverende-taal/aardige-anekdotes/verboden-koffie/
categories:
  - Aardige Anekdotes
  - Gewoon een Gedachte
  - Visuele Fratsen

---
Ik ben sinds kort begonnen aan een revalidatietraject. In dat gebouw hebben ze een koffiezetapparaat dat er als volgt uitziet:<figure class="wp-block-image size-full">

<img decoding="async" loading="lazy" width="1702" height="1080" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2019/06/koffiezet-1.webp" alt="" class="wp-image-11715" /> </figure> 

Wat is je eerste gedachte bij het zien van deze symbooltjes? Het is natuurlijk &#8230;

<p class="indented">
  <strong>Huh, waarom is bijna alles verboden?</strong>
</p>

Voor bijna elk symbooltje zag ik een rood rondje met een witte streep erdoorheen. Een stopteken dus. Ik vroeg me heel hard af waarom je een apparaat zou maken waarop bijna alles niet beschikbaar is.

Het is al helemaal raar dat bij een &#8220;dubbele kop&#8221; de eerste dus wel mag, maar de tweede niet. Dan is het dus gewoon één kop.

Misschien was het wel een poging om mensen gezonder te krijgen. (Wat helemaal geen rare gedachte is, bij een gezondheidsinstelling.) Je mag alleen nog maar heet water :p

Ik liet het er maar bij zitten. Ik had mijn eigen drinken mee.

Maar toen drukte iemand anders op een knop, met een icoontje dat _overduidelijk_ zei dat het verboden was, en die kreeg gewoon koffie!

Bij nadere inspectie bleek dit icoontje gewoon het _logo_ van het merk dat de koffie aanleverde. _Caffé Zarazzo_ (zoek het maar op).

Wat leren we hiervan? Check eerst even of je logo niet heel veel lijkt op een universeel bekend symbool. Ook op kleine groottes.

Wat leren we hier ook van? Zarazzo maakt best lekkere warme chocomel.

_Opmerking:_ ja, de blauwe krassen door de foto zijn van mij. Iemands gezicht was duidelijk zichtbaar. Vond ik wel zo netjes om die te verhullen, hoewel er vast en zeker meer elegante methodes zijn :p