---
title: '[HdT] #1 Henk’s Belemmering'
author: hetisdepanda
type: post
date: 2017-03-12T15:00:44+00:00
url: /visuele-fratsen/hdt-1-henks-belemmering/
categories:
  - Crappy Cartoons
  - Visuele Fratsen

---
<img decoding="async" src="http://res.cloudinary.com/nietdathetuitmaakt/image/upload/v1493117329/Henk-de-Tijdreiziger-_1.png" />