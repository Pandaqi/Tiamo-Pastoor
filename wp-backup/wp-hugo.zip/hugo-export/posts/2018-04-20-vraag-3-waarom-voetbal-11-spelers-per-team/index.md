---
title: 'Vraag: Waarom heeft voetbal 11 spelers per team?'
author: hetisdepanda
type: post
date: 2018-04-20T14:00:05+00:00
url: /gewoon-een-gedachte/vraag-3-waarom-voetbal-11-spelers-per-team/
categories:
  - Gewoon een Gedachte

---
Als je dit opzoekt, kom je een hoop websites tegen die claimen dat het komt door de grootte van de slaapvertrekken in Oudengelse scholen. In de negentiger jaren sliepen daar 10 jongens samen op een kamer. Die vormden dan automatisch het team, waarbij de leraar inviel als keeper. Als je hier wat verder induikt, echter, is dit nogal onwaarschijnlijk. Het lijkt meer een opgeblazen fabel van Britten die denken dat voetbal compleet door hen is uitgevonden en dat ze zelfs patent hebben op het aantal spelers.

Dus, vergeet dat, en zie hier hoe het wél is gegaan.

In de 16e eeuw ontstond in Florence de voorloper van voetbal, genaamd &#8220;calcio fiorentina&#8221;. (Zoek het op; het wordt nog steeds gespeeld.) Hierbij mocht je zowel handen als voeten gebruiken, en moest de bal in een net over de rand van het veld. Veel indrukwekkender is het aantal spelers: er stonden 27 spelers in het veld (_per team_), waarvan 5 keepers! De grootte van het veld, daarentegen, was niet veel anders dan vandaag de dag.

<!--more-->

Deze sport waaide over naar Engeland, waar ze dachten &#8220;poeh, dat ziet eruit als een chaos, gekke Italianen &#8230; maar wel bedankt voor de leuke sport&#8221;. Ze besloten de regels een beetje te veranderen en de teams terug te brengen naar tussen de 15 en 21 spelers. Ik ga ervan uit dat beide teams in een wedstrijd hetzelfde aantal moesten hebben. Anders had deze sport niet overleefd. Alle spelers namen gefrustreerd ontslag onder het mom &#8220;zij zijn groot, en wij zijn klein, en dat is NIET EERLIJK&#8221;.

Toen werd het 1870. Meerdere voetbalorganisaties kwamen samen om te zeggen: &#8220;we hebben een probleem&#8221;. _Wat was dat probleem?_ De sport werkte niet. Hij was kapot. Niemand keek ernaar, niemand investeerde erin, en het was niets meer dan georganiseerde chaos. Je kon net zo goed alle spelers vervangen door kippen en het verschil was onmerkbaar. (Of nouja, niemand merkte het verschil omdat er dus geen toeschouwers waren.)

De vergadering die volgde liep zo:

<p style="padding-left: 30px;">
  Alfred: &#8220;We moeten meer interesse hebben voor deze sport!&#8221;<br /> Bert: &#8220;Ik heb een idee. Een grandioos idee. Wat is de meest populaire sport van dit moment? Inderdaad: <em>cricket</em>. Cricket is zó populair dat het vast over honderden jaren nog steeds de lievelingssport is van iedereen.&#8221;<br /> Cassidy: &#8220;Sowieso.&#8221;<br /> Daniël: &#8220;Kan niet anders.&#8221;<br /> Bert: &#8220;Dus, we moeten cricket na-apen! Ik zeg: 11 spelers per team!&#8221;<br /> Alfred: &#8220;Wow, wacht even. Dan hebben we dadelijk 5 keepers, en maar 6 veldspelers.&#8221;<br /> Cassidy: &#8220;Dan doen we toch gewoon 1 keeper?&#8221;<br /> Daniël: &#8220;Schandalig! Wie voetbalt er nou met 1 keeper? Dan scoort de tegenstander honderd doelpunten! Ik zeg 16 spelers: 11 veldspelers, 5 keepers. Zo is het, en zo hoort het te zijn. 5 keepers, niet meer en niet minder.&#8221;<br /> Alfred: &#8220;Kan iemand Daniël wegsturen? Beveiliging? Beveiliging?!&#8221;
</p>

(Even later.)

<p style="padding-left: 30px;">
  Alfred: &#8220;Goed, waar waren we? Oh ja. Ik kreeg klachten dat er teveel ongelukken gebeuren. Daarnaast kan het publiek de spelers niet uit elkaar houden.&#8221;<br /> Bert: &#8220;Misschien moeten we spelers scheenbeschermers geven, en tenues van de club waarbij ze spelen.&#8221;<br /> Alfred: &#8220;Bert, makker, jij krijgt een promotie.&#8221;<br /> Cassidy: &#8220;Rugnummers lijken me ook handig?&#8221;<br /> Alfred: &#8220;Doe niet zo mal, Cassidy, dat doen we pas in 1928.&#8221;<br /> Bert: &#8220;Dus, wat doen we?&#8221;<br /> Alfred: &#8220;Tja &#8230; al die extra kledij is wel duur. Het is niet alsof we in de toekomst miljarden gaan verdienen met voetbal en de spelers exorbitante salarissen kunnen geven. Ik besluit: eenmaal, andermaal, teams hebben vanaf nu 11 spelers!&#8221;
</p>

En zo werd voetbal ineens gespeeld met 1 keeper en 11 spelers in totaal — nageaapt van het toentertijd populaire _cricket_.

Een extra reden is simpelweg dat dit getal goed uitkomt. Minder spelers zorgt dat het veld niet bespeelbaar is (veel te grote afstanden), meer spelers zorgt juist dat je nauwelijks iets voor elkaar krijgt.

Het is grappig om op te merken dat de Amerikanen op een gegeven moment voetbal ontdekten, ernaar keken, en dachten — zoals echte Amerikanen betaamt — &#8220;dat kan ruiger&#8221;. Toen de regels nog grote teams toelieten, besloten ze het mooie concept van voetbal weg te gooien en er rugby van te maken. Blijkbaar zagen ze alle blessures/ongelukken in voetbal en dachten &#8220;hé, dat heeft potentie&#8221;. Even later besloot Theodore Roosevelt (toentertijd president van Amerika) alsnog dat 21 spelers toch echt te veel werd. Hij pakte de ondergrens; en daarom heeft rugby 15 spelers.

Achteraf gezien had Engeland toch vrij veel patent op de sport. Oh well.