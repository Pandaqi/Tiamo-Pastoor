---
title: Als ik nu terug kijk
author: hetisdepanda
type: post
date: 2017-11-09T16:00:53+00:00
url: /toverende-taal/genezende-gedichten/als-nu-terug-kijk/
categories:
  - Genezende Gedichten

---
Als ik nu terug kijk  
zie ik niets dan mist  
flarden van gesprekken, bewerkte beelden  
bewegingen van iemand die er niet meer is

Ik ziet niet duizenden karakteristieke beelden  
alleen jij, met je hand op je buik  
in je andere hand je telefoon  
of een spatel  
of een bakje kwark  
je zit op een stoel, altijd dezelfde plek  
jouw plek  
je ligt met je hoofd op een yoga bal  
jouw bal  
of je staat te drentelen voor het raam in de kamer  
onze kamer

Ik hoor niet honderden persoonlijke zinnen  
behalve iets met tien euro, agenda-items en de constateermeneer  
of dat je mijn universiteit belachelijk maakt  
of mijn favoriete voetbalclub  
(al veranderde die elke keer)  
of mijn unieke manier van zingen  
en aparte manier van staan

Maar dat hoeft ook niet  
één prachtige herinnering zou voldoende zijn  
maar ik heb een heel leven vol  
één mooi gevoel zou voldoende zijn  
maar ik heb bijna twintig jaar vol

Ik heb meer dan ik had  
en dat heb jij me gegeven  
een klein broertje, in jouw grote schaduw  
jij gaf hem een leven