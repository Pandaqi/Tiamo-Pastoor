---
title: '[HdT] #5 Star Wars'
author: hetisdepanda
type: post
date: 2017-07-05T18:25:41+00:00
url: /visuele-fratsen/hdt-5-star-wars/
categories:
  - Crappy Cartoons
  - Visuele Fratsen

---
<img decoding="async" src="http://res.cloudinary.com/nietdathetuitmaakt/image/upload/v1499278987/Henk-de-Tijdreiziger-_5.jpg" />