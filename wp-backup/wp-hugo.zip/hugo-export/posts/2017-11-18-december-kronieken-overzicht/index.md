---
title: De December Kronieken (Overzicht)
author: hetisdepanda
type: post
date: 2017-11-18T17:00:42+00:00
url: /toverende-taal/vluchtig-verhaal/december-kronieken-overzicht/
categories:
  - Vluchtig Verhaal

---
Lang, lang geleden schreef ik voor de grap een verhaal over Sinterklaas en zijn avonturen om het feest te redden van een stel mensen die cadeaus stelen. (Ook wel, zo origineel als ik was, &#8216;de dieven&#8217; genoemd.)

Het werd langer en serieuzer dan ik had gepland, en uiteindelijk kwam alles samen in een project genaamd _De December Kronieken_. Het verhaal telt 30,000 woorden, wat tussen de 1/2 en 1/3 van een &#8220;normaal boek&#8221; is.

Ook zou ik het nu korter, bondiger en véél beter schrijven. Ik schreef dit verhaal toen ik 15 was en dacht toentertijd &#8220;wow, dit is het beste dat ooit gemaakt is!&#8221;, maar nu ben ik teleurgesteld in mijn vroegere zelf en zou ik dit verhaal compleet anders schrijven. Grappig hoe je onopgemerkt over tijd verbeterd, maar op het moment zelf denkt dat je al heel goed bent in wat je doet.

Al met al vond ik het verhaal leuk en belangrijk genoeg om op de site te zetten.

Hier een overzicht (elk deel heeft 3 à 4 hoofdstukken):

  * [Deel 1: Sinterklaas Begint][1]
  * [Deel 2: De Donkere Dagen][2]
  * [Deel 3: De Kerstman Staat Op][3]

&nbsp;

OPMERKING: Ik denk niet dat welke hoeveelheid edits dan ook de soms kromme verhaallijn en niet helemaal uitgewerkte personages kunnen verbeteren. Het is ook bedoeld als grappig (kinder)verhaaltje.

UPDATE: Heel &#8220;Deel 1&#8221; is nagekeken op (grote) fouten of compleet onlogische zinnen.

UPDATE: Heel &#8220;Deel 2&#8221; is nagekeken. (Ik merkte dat ik erg vaak een alinea begon met de dat de deur openvloog. Maar ja, ik vond het ook zo stom om elke keer synoniemen daarvoor te zoeken. &#8220;De deur maakte een opendraaiende beweging&#8221; &#8220;De deur ging erg snel open&#8221; &#8220;De deur schoot open&#8221; &#8220;De deur kraakte los&#8221; en ga zo maar door.)

UPDATE: Heel &#8220;Deel 3&#8221; is nagekeken. Ja, dit had ofwel een veel korter/simpeler verhaal moeten zijn, of een veel langer/uitgebreider verhaal. Want nu begin ik heel veel leuke dingen, om ze vervolgens half af te ronden of niet echt door te zetten. Ach ja, leerpuntjes, leerpuntjes.

 [1]: http://nietdathetuitmaakt.nl/vluchtig-verhaal/december-kronieken-sinterklaas-begint-deel-1/
 [2]: http://nietdathetuitmaakt.nl/vluchtig-verhaal/december-kronieken-donkere-dagen-deel-2/
 [3]: http://nietdathetuitmaakt.nl/vluchtig-verhaal/december-kronieken-kerstman-staat-op-deel-3/