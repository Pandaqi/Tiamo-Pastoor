---
title: De Boekensleur
author: hetisdepanda
type: post
date: 2016-10-20T15:00:45+00:00
url: /gewoon-een-gedachte/de-boekensleur/
categories:
  - Gewoon een Gedachte

---
Steeds minder mensen lezen boeken &#8211; je hoort het overal. Nog minder mensen gaan naar de bibliotheek, of kopen de fysieke versie van een boek. Mede daarom hebben ze op de middelbare school het idee dat kinderen verplicht elk jaar een aantal boeken moeten lezen. Om er zeker van te zijn dat deze boeken &#8220;goed&#8221; zijn, moeten ze op een bepaalde lijst staan. En om er zeker van te zijn dat deze boeken daadwerkelijk doorgeploeterd worden, moet men er een verslag over schrijven of toets over maken.

Wat raar eigenlijk.

<!--more-->

Een boek lezen kost veel tijd. Ik kan toevallig snel lezen, en doe gemiddeld een aantal uur over een boek (als ik stevig doorlees). Andere mensen willen ook daadwerkelijk helemaal begrijpen wat ze lezen, en doen er een week over. Nou is het natuurlijk prima om zoveel tijd aan studie te besteden&#8230;mits het daadwerkelijk goed bestede tijd was. Normaal gesproken, als je een informatief boek doorleest, of sommen oefent, wordt je beter naarmate je het meer doet. En hoe verder je komt, hoe groter je kennisvlak.

Maar, als je een roman moet lezen die je totaal niet interessant vindt, leer je er helemaal niks van. Je leert geen nieuwe taal, want Nederlands (of, heel soms, Engels) kon je al. Je leert geen nieuwe concepten of vaardigheden, want het is een fictief verhaaltje uit het hoofd van een schrijver. (Al helemaal erg is het als de roman zogenaamd &#8220;waarheidsgetrouw&#8221; of &#8220;realistisch&#8221; is door alles in een bepaald dialect/accent te schrijven, waardoor je dus gewoon géén idee hebt wat ze zeggen, maar na een week praten wel alle kinderen ineens cowboy-Engels.) Dus waarom oh waarom, zijn kinderen verplicht uren tijd te verspillen aan zoiets zinloos, educatief gezien?

Natuurlijk, een boek lezen is goed voor je. Je krijgt misschien meer gevoel voor taal, en je leert eens een nieuw woord, of komt op grappige ideeën voor eigen projecten. Maar als school daar blijkbaar iets om geeft, moeten ze ook drama, of muziek, of beeldende vorming verplichten. Dan moeten ze ook verplicht kinderen leren hoe je gezond leeft, en leren over het leven en hun dromen najagen, en over je eigen verhalen schrijven en aardig en respectvol je medemens behandelen.

Sterker nog, door kinderen verplicht boeken te laten lezen over een psychisch gestoord iemand die rare dingen doet en uiteindelijk altijd dood gaat (want dat zijn de favorieten onder de literaire elite), beroof je kinderen die toch al boeken lazen van hun tijd. Die kunnen nu &#8217;s avonds niet hun eigen boek lezen, of hun eigen verhaal schrijven, omdat ze een prutboek voor school moeten lezen.

En, dit zal niet als een verrassing komen, de mensen die al hebben vastgesteld nul interesse te hebben in taal, verhalen of literatuur, die lezen zo&#8217;n boek toch niet &#8211; die kijken de film. Of die bedenken zelf een leuk verhaaltje voor hun verslag en hopen op een zesje.

De Boekensleur is een reliek uit vervlogen tijden. Als men het wil behouden, moeten scholieren meer vrije keus hebben, en moeten veel meer andere &#8220;creatieve wetenschappen&#8221; verplicht aan bod komen. Als ik ooit in de problemen kom, had ik liever geleerd over zelfverzekerd zijn en zelfverdediging, in plaats van dat ik alleen een oud-Nederlands gedicht over een gemene vos kan opdreunen richting mijn overvallers.