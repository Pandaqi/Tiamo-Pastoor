---
title: Wachten bij de fysio (deel 2)
author: hetisdepanda
type: post
date: 2019-04-04T16:00:12+00:00
url: /toverende-taal/aardige-anekdotes/wachten-bij-de-fysio-deel-2/
categories:
  - Aardige Anekdotes
  - Gewoon een Gedachte

---
Vandaag was ik weer bij de fysio. (Zoals je verwacht waren mijn problemen niet na de eerste afspraak opgelost.)

Toen ik de fietsenstalling opreedt, stonden er al twee fietsen. Ik ben erg genereus als ik &#8220;fietsenstalling&#8221; zeg, aangezien er maar drie plekken zijn, maar ik weet geen beter woord.

In het vorige artikel schreef ik over de ongeschreven zitregel:

<p style="padding-left: 30px;">
  <em>Als je wilt gaan zitten, en er zijn genoeg vrije plekken, ga je niet direct naast iemand anders zitten.</em>
</p>

Ditzelfde geldt natuurlijk ook voor fietsen. De ene fiets stond op plek 1, de andere op plek 3, waardoor ik mijn fiets precies ertussen kon proppen (op plek 2). Ze hadden netjes een ruimte ertussen gelaten. Mooi!

Ik ging binnen zitten en dacht er verder niet meer over na.

Totdat er twee eksters op de eerste fiets gingen zitten. Deze had een stoffen zadel, alsof iemand een teddybeer over het zadel had gegooid. Hoewel de panterprint op het zadel die vergelijking een beetje verpest.

De eksters begonnen aan het zadel te pulken. Met elke stoot trokken ze een paar haren uit het zadel, om deze vervolgens toe te voegen aan de grote verzameling die ze al hadden. Als je niet wist wat ze aan het doen waren, leken het twee eksters met een snor en een baard. Mijn medewachtenden merkten het ook op, maar niemand vond het nodig om het zadel te redden :p

<!--more-->

Waarom deden de eksters dit? Mijn theorie: ze zochten materiaal voor hun nestje. Mijn konijn trekt ook altijd in de lente stukjes uit haar eigen vacht om een warm nest te bouwen. (Geen zorgen, het is een langharig konijn, ze kan het _prima_ missen. Scheelt ons ook weer scheerwerk.)

Keer op keer kwamen de eksters terug. In de tien minuten dat ik moest wachten, hadden ze al vijf keer een nieuwe verzameling haren uit het zadel geplukt.

Maar het wordt nog leuker. Een oud echtpaar nam afscheid van de fysiotherapeut en liep naar buiten. De man pakte de fiets op plek 3, de vrouw pakte haar fiets op plek 1. Wacht eens even &#8230; ze horen bij elkaar! Waarom hebben ze hun fietsen dan uit elkaar gezet?! Dit is het _enige moment_ waarop je fietsen bij elkaar kan plaatsen! Ugh, niemand houdt zich ook aan de ongeschreven fietsplaatsetiquette.

Het echtpaar stapte op de fiets en reed weg. Een minuut later kwamen de eksters terug.

Ik denk dat ik de eerste persoon ter wereld ben die weet hoe het eruitziet als twee eksters COMPLEET VERBAASD kijken.

<p style="padding-left: 30px;">
  &#8220;Huh, hier was net nog een fiets toch?&#8221;<br /> *draait 4 rondjes om de eigen as*<br /> &#8220;Ik weet het zeker Frida. Hier was net nog een pluizig zadel!&#8221;<br /> &#8220;WAAR IS HET HEEN?! WAAR IS ONS NEST?!&#8221;<br /> &#8220;Frida, calm down. We moeten hierover logisch nadenken.&#8221;<br /> *draait weer 7 rondjes om de eigen as*<br /> *hupst heen en weer over de fietsenstalling*<br /> &#8220;Oh &#8230; zadelgoden &#8230; help ons! Waar zijn onze pluisjes heen?!&#8221;<br /> *gooit het hoofd van links naar rechts, alsof het op een wipwap staat*<br /> *loopt nog een rondje over de hele fietsenstalling*<br /> &#8220;Ga anders wat hoger staan&#8221;<br /> *springt op het zadel van <em>mijn</em> fiets*<br /> &#8220;Nee, ik zie hem hier ook niet.&#8221;<br /> &#8220;Ach en wee, daar gaat onze pluizigheid&#8221;
</p>

Toen werd ik geroepen door de fysio. Ergens ben ik benieuwd wat er daarna is gebeurd. Misschien zagen ze de fiets in de verte, is er een gekke achtervolging geweest, en zitten ze nu op diezelfde fiets, maar dan in de garage van die vrouw. Of misschien ook niet.

&nbsp;

&nbsp;