---
title: Korting op Korting
author: hetisdepanda
type: post
date: 2018-12-16T16:00:24+00:00
url: /gewoon-een-gedachte/korting-op-korting/
categories:
  - Gewoon een Gedachte
  - Toverende Taal

---
Ik krijg al wekenlang allerlei reclamemails met ongeveer dezelfde titel:

<p id=":14f" class="hP" style="padding-left: 30px;" tabindex="-1" data-thread-perm-id="thread-f:1619907992871161644" data-legacy-thread-id="167b11bca3e6cf2c">
  <strong>Mis Kerstmis niet! Bestel op tijd en krijg korting op korting!</strong>
</p>

<p tabindex="-1" data-thread-perm-id="thread-f:1619907992871161644" data-legacy-thread-id="167b11bca3e6cf2c">
  Ik wil even drie dingen mededelen:
</p>

<ol type="a">
  <li tabindex="-1" data-thread-perm-id="thread-f:1619907992871161644" data-legacy-thread-id="167b11bca3e6cf2c">
    Ik ben niet van plan Kerstmis te missen. Het is fijn dat ze mij commanderen om niet voor Eerste Kerstdag te sterven of in een coma te geraken, maar het is onnodig. Het stond al op de agenda, zeg maar. (Kerstmis bedoel ik dan; niet het comagedeelte.)
  </li>
  <li tabindex="-1" data-thread-perm-id="thread-f:1619907992871161644" data-legacy-thread-id="167b11bca3e6cf2c">
    Wie bestelt er nou weer expres te laat? (&#8220;Kijk eens, deze tv is nu honderd euro goedkoper. Maar misschien als ik vlak na het aflopen van de actie bestel, is ie wel nóg goedkoper! Ja, topplan.&#8221;)
  </li>
  <li tabindex="-1" data-thread-perm-id="thread-f:1619907992871161644" data-legacy-thread-id="167b11bca3e6cf2c">
    <em>Korting op korting</em> betekent niet wat ze denken dat het betekent. Korting betekent namelijk dat iets wordt gereduceerd, ingekort, verkleind, verminderd. Als je korting op korting krijgt, heb je dus <em>minder korting</em>. Niet bepaald een succesvolle reclamecampagne. Het is alsof een winkel zegt &#8220;Wees er snel bij, want 1 + 1 voor de dubbele prijs!&#8221; (Of &#8220;Eén halen, twee betalen!&#8221;)
  </li>
</ol>

De titel was correcter geweest als er stond &#8220;bestel voor Kerstmis en krijg veel korting!&#8221;. Maar, toegegeven, dat bekt toch minder lekker.

Tot zover mijn advies aan alle webwinkels.

&nbsp;