---
title: Mag ik van je houden?
author: hetisdepanda
type: post
date: 2017-07-24T15:00:55+00:00
url: /toverende-taal/genezende-gedichten/mag-ik-van-je-houden/
categories:
  - Genezende Gedichten

---
Mag ik van je houden?  
Zoals de maan de zon opvangt  
Een stille kracht, ver weg  
Door jou op het juiste pad beland

Mag ik van je houden?  
Dag na dag zeggen wat ik voel  
Soms verdraaid en vaak verstoord  
Maar jij weet altijd wat ik bedoel

Mag ik van je houden?  
Honderd liedjes voor je schrijven  
Uren voor je raam  
Hopend dat eentje zal beklijven

Mag ik van je houden?  
Ik red één keer je leven  
Dan tot in de late uurtjes praten  
Avonturen die we nooit beleven

Mag ik van je houden?  
Mag ik één maal het laatste woord  
Al durf ik niet toe te geven  
Je hebt het kind in mij vermoord

Mag ik van je houden?  
Want dromen gaat niet meer  
De sterke storm zal nooit gaan liggen  
Maar ik heb nu mijn verweer

Mag ik van je houden?  
Of kwam ik te laat of juist te vroeg  
Toch hoop ik dat je weet  
Dat ik elke dag nog voor je zwoeg