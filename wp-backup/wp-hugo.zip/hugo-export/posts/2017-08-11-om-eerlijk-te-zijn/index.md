---
title: Om eerlijk te zijn
author: hetisdepanda
type: post
date: 2017-08-11T12:38:37+00:00
url: /gewoon-een-gedachte/om-eerlijk-te-zijn/
categories:
  - Gewoon een Gedachte
  - Toverende Taal

---
Ik begin erg vaak een zin met &#8220;om eerlijk te zijn&#8221;. Waarom? Ik heb geen idee. Laatst vond ik een aantal oude verhalen terug van mezelf &#8211; en dan heb ik het over verhalen die ik schreef toen ik nog niet eens wist hoe ik chauffeur spelde &#8211; en zelfs daarin strooide ik het al links en rechts in het rond. Misschien dacht ik dat het mij volwassener over deed komen, of dat mensen me dan serieuzer zouden nemen. Het klonk namelijk als iets dat een wijs en vooral eerlijk karakter zou zeggen.

Toen ik er laatst goed over nadacht, echter, besefte ik dat het eigenlijk raar is om het überhaupt te zeggen. Als jij een zin begint met &#8220;om eerlijk te zijn&#8221; of &#8220;als ik eerlijk ben&#8221;, dan geeft dat in principe de indruk dat _alle andere zinnen_ die je zegt leugens zijn. Als jij het nodig vindt om eens in de zoveel tijd te vermelden dat je eerlijk bent, dan ruikt iedereen na een tijdje onraad. Het is alsof de premier constant staat te roepen dat hij écht wel weet wat hij aan het doen is. Of alsof een leraar steeds zegt &#8220;oké, nu even opletten jongens!&#8221; &#8211; het geeft toch het gevoel dat je het overige halfuur helemaal niet op hoefde te letten.

<!--more-->

Ik begon er op te letten, en ik kwam er achter dat die specifieke zin eigenlijk een verborgen betekenis heeft. Sterker nog, men bedoelt eigenlijk iets compleet anders dan wat de woorden letterlijk suggereren. Wanneer iemand zegt &#8220;om eerlijk te zijn&#8221;, bedoelen ze eigenlijk iets in de richting van &#8220;om serieus te zijn&#8221;. Wat ze daarvoor zeiden was grappend bedoeld, of dwaalde even af op een zijspoor, maar nu gaan ze terug naar het algemene onderwerp; nu gaan ze even zeggen waar het op staat.

Dit kan bijvoorbeeld: &#8220;Zeg Henk, heb jij nog eens gekeken naar die rekenfout in onze jaarcijfers?&#8221; &#8220;Ha, Truus, je weet toch dat ik veruit de slechtste ben in hoofdrekenen. Ik ben waarschijnlijk degene die de rekenfout heeft gemaakt! Om eerlijk te zijn heb ik nog geen tijd gehad om er naar te kijken.&#8221;

Dit kan ook: &#8220;Truus, als je klaar bent met je studie, wat wil je dan eigenlijk gaan doen?&#8221; &#8220;_Als_ ik ooit mijn studie af weet te maken. Ik merk dat ik echt geen motivatie meer heb voor die laatste loodjes, mijn hoofd zit veel te vol. Om eerlijk te zijn, ik heb eigenlijk geen idee wat ik hierna wil gaan doen. (Misschien iets met communicatie.)&#8221;

Dit heb ik nooit zien gebeuren: &#8220;Henk, wat vind je van onze nieuwe website lay-out?&#8221; &#8220;Hmm, eekhoorns hebben vleugels, mijn huis heeft zesentachtig verdiepingen, en rood is geen kleur. Om eerlijk te zijn, olifanten bestaan wel.&#8221;

Iets om over na te denken.

&nbsp;