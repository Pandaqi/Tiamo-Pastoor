---
title: Konijnengeheimen
author: hetisdepanda
type: post
date: 2016-10-11T15:00:06+00:00
url: /gewoon-een-gedachte/konijnengeheimen/
categories:
  - Gewoon een Gedachte

---
Ik geef de konijnen elke dag te eten. &#8217;s Ochtends doe ik de bekende korrels in een bak, en zet die in hun hok neer, en door de dag heen geef ik ze regelmatig stukjes brood of groente.

Wat raar is, is dat ze na al die jaren nog niet door hebben hoe ze met voedsel om moeten gaan. Als ze mij met hun voerbak aan zien komen lopen, zijn ze slim genoeg om te weten dat er eten komt, en springen ze tegen de zijkant aan en kijken enthousiast omhoog. Maar, ze gaan altijd _precies_ op de plek zitten waar de bak altijd staat. Als ik dan de klep open doe, en probeer de voerbak er in te zetten, moet ik hem dus zo ongeveer onder hun pootjes duwen. Maar dat vinden ze vervelend, dus dan gaan ze tegen de voerbak slaan en ligt al het voer door hun hok. (Of op de grond.)

<!--more-->

Als ik met brood aan kom lopen, en het schuifje aan de zijkant open doe, gaan ze er uit hangen om zo snel mogelijk het stukje uit mijn hand te pakken. Dat doen ze echter zo snel, dat ze de helft van de tijd het stukje brood weer laten vallen. En in plaats van dat ze even voor zich kijken en het oppakken en verder eten, kijken ze meteen weer naar mij en verwachten dat ik magisch nog een stukje tevoorschijn tover. Als ik dat niet doe, druipen ze verdrietig af. Maar als ik het stukje brood onder ze vandaan probeer te pakken, raken ze weer gefrustreerd en denken dat mijn vinger eten is.

En als dat niet erg genoeg is, zijn er heel soms momenten dat allebei de konijnen met de neusjes tegen elkaar aan staan, en gewoon urenlang alleen maar staan te snuffelen, zonder verder ook maar enige beweging te maken. Als je dan aan komt lopen, reageren ze niet. Als je ze eten probeert te geven, reageren ze niet. Als je hun hele hok verbouwt en verschoont zullen ze hoogstens als een Siamese tweeling een paar centimeter opschuiven/ Pas als je ze oppakt schieten ze ineens wakker. Maar dan verwachten ze wel meteen eten.