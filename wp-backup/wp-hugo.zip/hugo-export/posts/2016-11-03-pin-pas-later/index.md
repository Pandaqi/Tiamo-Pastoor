---
title: Pin pas later
author: hetisdepanda
type: post
date: 2016-11-03T15:00:55+00:00
url: /gewoon-een-gedachte/pin-pas-later/
categories:
  - Gewoon een Gedachte

---
Regelmatig ga ik naar de supermarkt, of de dierenwinkel, of een andere winkel waar ze goedkope dingen verkopen, om iets kleins te halen. Misschien is er geen brood meer, misschien hebben mijn konijnen voer nodig, misschien heb ik nog wat zakken chips voor een feest nodig &#8211; de bedragen komen vrijwel nooit boven de 5 à 10 euro uit. Het voelt dan ook erg lullig om elke keer weer met mijn pinpas aan te komen zetten. Al het geld dat ik binnenkrijg komt digitaal binnen, dus ik heb al in geen jaren meer contant geld in mijn bezit gehad, en dat is best wel onhandig.

Niet alleen is het onhandig omdat de caissière je aankijkt met een blik van &#8220;echt? pinnen voor dit pak hagelslag? alweer?&#8221; (wat ik meestal oplos door maar gewoon alvast boodschappen voor de komende paar eeuwen te doen, dan wordt het bedrag tenminste een beetje opgehoogd), het is ook onhandig omdat ik nauwelijks zicht op mijn geld heb. Ik weet nooit precies hoeveel geld ik heb, ik heb alleen een vaag vermoeden. Als ik inlog op de website van mijn bank, staat daar een mooi getalletje, maar vrijwel constant worden er dingen afgeschreven en bijgeschreven, dus je weet het nooit zeker. Het zal je maar gebeuren: dat je kijkt, en je ziet dat je nog een paar honderd euro hebt, en vrolijk fluitend naar de supermarkt vertrekt, maar als je eenmaal bij de kassa bent blijkt dat te zijn afgeschreven door je zorgverzekering. Dan mag je weer achterstevoren de supermarkt door en alles netjes terugleggen.

<!--more-->

Hoe dan ook, ben ik nog wel net oud genoeg om dat besef te hebben. Ik weet dat geld op kan. Ik weet wat dat getalletje voorstelt. Ik weet dat een negatief getal niet alleen betekent dat je geen geld hebt, maar dat je schuld hebt. Ik weet dat een miezerig briefje van 50 meer waard is dan een hele berg één euro muntjes. Maar steeds meer mensen verliezen dat besef.

Laatst stond in de krant dat steeds meer en meer mensen, zowel jongeren als volwassenen, in de schuld stonden en daar totaal niet uit kwamen. In plaats van dat ze hun verdriet wegdrinken, kopen ze allerlei spullen met geld dat ze niet hebben. Echter, ze merken er niks van, want het enige wat er gebeurt is dat ze een getalletje op een beeldscherm elke maand zien slinken. Als ze een grote pot geld zouden hebben, zouden ze die pot elke dag leeg zien gaan, en er niks bij zien komen, en beseffen dat het zo niet door kan gaan. Maar door de digitalisering van geld is dit weg, en dat is best een probleem.

Dus, mocht je een kind moeten opvoeden, of het idee hebben dat je je vrienden moet opvoeden, hou dan zeker het financiële aspect in de gaten. Kinderen mogen best vanaf hele jonge leeftijd zakgeld krijgen, of helemaal zelf hun geld beheren, want daar leren ze heel veel van. Maar doe het wel met contant geld. Elke maand zeggen dat je tien euro op hun rekening hebt gestort brengt niks teweeg bij een kind. Mocht je een vriend(in) hebben die oeverloos geld spendeert, zeg dat tegen die persoon, en om het te demonstreren, kun je vragen of hij/zij een maandje alles contant betaalt. Probeer zo vroeg mogelijk besef van de waarde en invloed van geld te hebben, en pin pas later.