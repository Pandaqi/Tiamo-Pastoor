---
title: Kijk, mijner kinder
author: hetisdepanda
type: post
date: 2018-02-11T16:00:06+00:00
url: /toverende-taal/genezende-gedichten/kijk-mijner-kinder/
categories:
  - Genezende Gedichten

---
Kijk, mijner kinder  
een politicus wand&#8217;lt aldaar  
zijner tas in hand  
zijner hand in zak  
neeme problemen waar  
met grootsch gemak

Kijk, mijner kinder  
politici wand&#8217;len daarheen  
hunner arm om arm  
hunner oog in oog  
zij vergeete meteen  
dat ieder loog

Kijk, mijner kinder  
politici spreeke elkaar  
vuil woord na woord  
vuile blik na blik  
gene oplossing klaar  
maar die hele land stik

Kijk, mijner kinder  
politici jakk&#8217;ren naar bed  
zij denke zij gewonnen  
zij denke zij geen fout  
generlei heeft opgelet  
poetse slechts vuil tot goud

Kijk, mijner kinder  
politici wakk&#8217;ren het vuur  
de een spreeke vals  
de een kleede raar  
maar met ieder uur  
verlieze zij elkaar

Kijk, mijner kinder  
politici helpe niet  
zij zeure over wissewas  
zij klaage over niemendal  
waar het echte leed geschiedt  
gener politicus die spreeke zal