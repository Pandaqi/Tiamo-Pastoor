---
title: Ik hoop dat je niet boos bent
author: hetisdepanda
type: post
date: 2017-09-09T16:00:40+00:00
url: /toverende-taal/genezende-gedichten/hoop-boos-bent/
categories:
  - Genezende Gedichten

---
Ik hoop dat je niet boos bent  
dat ik niet mee ging klimmen  
dat we maar één keer Risk hebben gespeeld  
en dat je niet eens een beetje kon winnen

Ik hoop dat je niet boos bent  
dat ik niet mee ben gaan fietsen  
dat ik agenda-items opwierp  
terwijl ik eigenlijk zat te nietsen

Ik hoop dat je niet boos bent  
dat ik niet naar Tilburg ben gegaan  
dat ik je kookkunsten maar half waardeerde  
en met mijn gitaar onder je slaapkamer ging staan

Ik hoop dat je niet boos bent  
al maakt die passie je tot wie je bent  
je kunt alles wel kapot relativeren  
maar ik ga je missen, grote rare vent

Ik hoop dat een zachte zon  
zo nu en dan op je schijnt  
dat je warme winters en zwoele zomers  
waar je ook bent zult blijven voelen

Dat je rust vindt in het heden  
en de kerstverlichting in je ogen twinkelt  
dat je terugkijkt op een gelukkig verleden  
en niet meer zoveel twijfelt.