---
title: Boven-de-mond-praat
author: hetisdepanda
type: post
date: 2019-02-10T16:00:56+00:00
url: /toverende-taal/aardige-anekdotes/boven-de-mond-praat/
categories:
  - Aardige Anekdotes
  - Gewoon een Gedachte

---
Ik was onlangs bij de tandarts. Er was iets mis gegaan met een vulling (_&#8230; voor de derde keer in anderhalf jaar &#8230;_), dus die moesten ze weer repareren.

Het proces begint altijd heel zakelijk. Ze vragen vriendelijk je mond open te doen, beginnen langzaam van alles in je mond te proppen, en gaan in relatieve stilte aan het werk.

Tot halverwege het proces. Uit het niets zegt mijn tandarts ineens: &#8220;Had je nog gehoord hoe Frank z&#8217;n vakantie was?&#8221; Ik denk: &#8220;Wie is Frank? Welke vakantie?&#8221; Toen realiseerde ik dat ze het niet tegen mij had, maar tegen haar assistente.

Frank was blijkbaar een van de &#8220;hoofdtandartsen&#8221;. Hij was de persoon die mij jarenlang heeft gecontroleerd, totdat ik een paar jaar geleden een nieuwe kreeg. (Sorry Frank, ik onthoud de namen van mijn tandartsen niet.) Hij was op wintersport geweest en had daarbij iets gebroken. _Het zat nu in het gips._ Dat was de cryptische informatie die ik opving.

(Het was heel raar. Alsof ze niet durfden te zeggen _wat_ hij gebroken had. &#8220;Ah ja, dus _het_ zit nu in het gips?&#8221; &#8220;Ja, hij baalt wel dat hij _het_ nu niet meer kan gebruiken._&#8221;_ Bijna alsof ze spionnen waren die een bericht overdroegen. &#8220;De tandarts zit in het gips! Ik herhaal: de tandarts zit in het gips!&#8221;)

<!--more-->

Ik ging ervan uit dat het zijn arm/pols was, want hij kon niet meer werken. Hij moest zijn vakantie een paar maandjes uitbreiden om zijn blessure te laten genezen. Hij had er de pest in.

Terwijl ze dit hele verhaal afratelden gingen ze natuurlijk door met mij behandelen. Maar ze gaven geen commando&#8217;s meer en vroegen niks meer. Ineens moest ik de hele tijd gokken wat ze gingen doen en wat ik dan moest doen. (&#8220;Oh shit, ze pakken nu dat gereedschap. Eh, eh, mond verder open en kin omhoog!&#8221;) Zij bleven maar verhalen lullen, waarvan ik me soms afvroeg of ze niet privacygevoelig waren, terwijl ik ineens mijn eigen kiesvulproces moest gaan dirigeren.

Om het nog erger te maken: ik heb de laatste tijd geoefend met meditatie en was halverwege de behandeling helemaal zen. Mijn ogen vielen dicht en ik begon te knikkebollen. Gelukkig wist ik mezelf streng toe te spreken, anders was ik in slaap gevallen. (Die strenge toespraak was natuurlijk in mijn hoofd. &#8220;Oké, dan gaan we nu je gaatje —&#8221; &#8220;WAKKER BLIJVEN, TIAMO! HOU VOL JONGE! HOU VOL!&#8221; &#8220;— eh, ja, eh, ja, dus we gingen je gaatje vullen.&#8221;

Altijd fascinerend, die pratende tandartsen boven je open mond.

_Opmerking:_ je krijgt haast de neiging om er de volgende keer op terug te komen. &#8220;Ah, welkom, je bent er weer voor de controle.&#8221; &#8220;Vergeet die controle — hoe is het afgelopen met Frank!?&#8221;