---
title: NOS – De onbedoelde standup comedian
author: hetisdepanda
type: post
date: 2018-05-06T20:37:09+00:00
url: /toverende-taal/aardige-anekdotes/nos-de-onbedoelde-standup-comedian/
categories:
  - Aardige Anekdotes
  - Gewoon een Gedachte

---
Ik hou van de NOS om twee redenen:

  * Je kunt alle uitzendingen live meekijken of makkelijk terugkijken.
  * Ze zijn soms zo ongelofelijk droog.

Een tijdje geleden kwam ik een artikel tegen over de belastingdienst. Er was een verslag geschreven over de fouten en misstanden binnen de belastingdienst, en het NOS opende met:

<p style="padding-left: 30px;">
  &#8220;De structurele problemen bij de Belastingdienst zijn door een commissie samengevat in 176 pagina&#8217;s.&#8221;
</p>

Als dat de samenvatting is, denk ik dat de belastingdienst niet lang meer overeind blijft.

Of deze, over de frustratie van iemand jegens journalisten die almaar vragen bleven stellen:

<p style="padding-left: 30px;">
  Ook de ervaren NRC-journalist Stephane Alonso kreeg een sneer. Hij kon fluiten naar antwoorden omdat hij volgens Schinas nog maar kort in Brussel was en niets van de EU begreep. <em>In al zijn frustratie leek de persvoorlichter even te vergeten dat Alonso al vier jaar werkzaam is in de Belgische hoofdstad.</em>
</p>

Dat droge, betweterige toontje. Heerlijk.

Of over het vertrek van de kinderombudsman:

<p style="padding-left: 30px;">
  Na afloop van een besloten gesprek met Kamerleden wilde Van Zutphen de wachtende pers niet te woord staan. <em>&#8220;Ik zeg niets&#8221;, zei Van Zutphen.</em>
</p>

Vandaag hadden ze het weer voor elkaar:

<p style="padding-left: 30px;">
  &#8220;De Syriër die gisteren in Den Haag drie mensen neerstak, gooide in februari zijn huisraad naar buiten. <em>Dat doet vermoeden dat de man psychische problemen had.</em>&#8220;
</p>

No way! Normaal gesproken, als iemand zijn sofa door het raam van de tweede verdieping flikkert, denk ik &#8220;oh, die zal wel een onredelijke aversie jegens zitbaar meubilair hebben&#8221;. Maar psychische problemen &#8230; ja, dat heeft ook wel wat.