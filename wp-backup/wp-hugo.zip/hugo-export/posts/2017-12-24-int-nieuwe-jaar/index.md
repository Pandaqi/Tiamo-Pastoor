---
title: In’t nieuwe jaar
author: hetisdepanda
type: post
date: 2017-12-24T16:00:16+00:00
url: /toverende-taal/genezende-gedichten/int-nieuwe-jaar/
categories:
  - Genezende Gedichten

---
Linkervoet voor rechtervoet,  
kom ik ’s ochtends uit mijn bed  
maar ik wil alleen maar slapen,  
vast en zeker ben ik besmet.

Wat doe ik nou op een dag als deze?  
Een beetje staren, een beetje turen.  
Ik eet, wacht, eet en slaap  
en voel mij langzaamaan verzuren.

Maar dan loop ik over straat  
en merk ik Uwen haren op:  
bruin en golvend door de wind.  
Ge zegt me niks; en toch ik stop.

Ge lacht naar me en Ge spreekt,  
niets dan wijze woorden kan ik horen.  
Uwen lach betovert en Uwen stem  
verfrist mijn geest, maar maakt verloren.

En als ik in Uwen ogen stare  
&#8211; man, dan kan ik slechts verliezen.  
Dan zwicht ik, val ik en kniel ik neder  
want ied’re man zou U toch kiezen?

Ik zal dichten voor U maken  
en schrijf voor U een mooi verhaal!  
Ik zal mijn mooiste noten spelen,  
en spreek voor U de vreemdste taal!

Ik zal mijn best doen, in’t nieuwe jaar,  
om braaf en goed en lief te zijn.  
Want als ik mijn best maar doe,  
dan is dit jaar de liefde mijn.

(Credits voor dit gedicht gaan naar Erik.)