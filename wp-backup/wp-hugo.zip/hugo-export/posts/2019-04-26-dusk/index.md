---
title: Dusk
author: hetisdepanda
type: post
date: 2019-04-26T10:04:37+00:00
url: /gewoon-een-gedachte/dusk/
categories:
  - Gewoon een Gedachte
  - Muzikale Meesterwerken

---
Het is weer zover! Ik heb een nieuw instrumentaal album uitgebracht!

Dit album heet **Dusk**, bevat 4 nummers (2 piano, 2 gitaar), en zal later dit jaar worden gevolgd door een bijbehorend album genaamd **Dawn**.

Het album (plus aanvullende informatie) is te vinden op deze pagina: [**[Album] Dusk**][1]

Als je het album gewoon snel wilt luisteren, staat hieronder een BandCamp widget.

 [1]: http://nietdathetuitmaakt.nl/album-dusk/