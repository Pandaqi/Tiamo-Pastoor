---
title: Gemeentegoed
author: hetisdepanda
type: post
date: 2017-08-17T15:51:41+00:00
url: /toverende-taal/aardige-anekdotes/gemeentegoed/
categories:
  - Aardige Anekdotes

---
Op mijn weg naar de universiteit &#8211; en de terugweg, natuurlijk &#8211; kom ik langs een elektronisch bord. Enkele jaren geleden dacht de gemeente &#8220;goh, dit stukje stoep is leeg&#8221;, en ze gooiden de weg een aantal weken dicht om zo&#8217;n apparaat neer te pleuren.

Het apparaat laat drie dingen zien: de huidige tijd, hoeveel mensen _die dag_ zijn langsgefietst, en hoeveel mensen _in totaal_ zijn langsgefietst.

Op zich vond ik het een toevoeging aan mijn fietsrit. Normaal gesproken kon ik slechts de tijd zien door naar twee kerkklokken langs de route te kijken. Deze staan, echter, vlak na elkaar, waardoor ik nog steeds niet wist of ik te laat op school aan zou komen. En, als ik zo&#8217;n hoge klok goed wilde zien, moest ik uit het zadel gaan en wegkijken, en had ik kans per ongeluk in het wiel van de persoon voor mij te belandden (of de bosjes te begroeten). Dus het was fijn om de tijd fatsoenlijk te kunnen zien. (Oplettende lezers zouden tegen kunnen sputteren dat ik een horloge had kunnen kopen, maar het is niet alsof het minder gevaarlijk is om die tijdens het fietsen te bekijken.)

Nu wil het lot dat dit apparaat al vrij snel kapot ging. Binnen enkele maanden bleef hij steken op bepaalde getallen, of ververste zich niet elke dag, en liet als resultaat gekke getallen zien. (Tenzij er echt vóór acht uur &#8217;s ochtends vijftig duizend fietsers langs zijn gekomen, dan neem ik mijn woorden terug.) De gemeente besloot hem tijdelijk te &#8220;sluiten&#8221;. Ze lieten het apparaat staan, maar gooiden er een bord overheen met de tekst &#8220;ik tel even niet meer mee&#8221;

<!--more-->

Hilarisch.  Het zou oprecht een goede tussenoplossing zijn geweest, _als het ook een tussenoplossing was_. Maar dat was het niet. Het apparaat bleef lang dicht. Erg lang. Op een gegeven moment werd het &#8220;ik tel niet meer mee&#8221;. Een bord met depressieve periodes, geweldig. Hij bleef maar dicht, maand na maand, totdat ik een tijdje niet meer langs had gefietst, en hij er ineens weer stond. Miraculeus! Ik voelde gewoon dat al het verkeer weer vrolijk naar zijn werk ging omdat de fietsenteller slash klok weer trots meedeed.

Totdat hij na enkele dagen weer stuk ging, vlak voor de zomervakantie. Het communicatieteam van de gemeente had weer een dolle tijd toen ze op de proppen kwamen met de tekst &#8220;ik ben nog even op vakantie&#8221;. Het bord hangt er nu nog steeds.

Ik verdenk ze er van dat ze het veel te leuk vinden om die slogans te bedenken, en expres het apparaat steeds kapot laten gaan. Of het is goedkoper om eens in de zoveel tijd een nieuw groot bord te drukken, dan het apparaat daadwerkelijk te fiksen. Of een experiment met zelfstandige stagiaires is uit de hand gelopen, en ze hebben het mysterie van het niet-werkende apparaat nog steeds niet aan hun leiders doorgegeven. Waarom zouden ze ook, de situatie met het bord is al een jaar lang beter vermaak dan de rest van mijn route.

UPDATE: Iemand heeft er met stift ondergezet &#8220;nog steeds? :)&#8221;