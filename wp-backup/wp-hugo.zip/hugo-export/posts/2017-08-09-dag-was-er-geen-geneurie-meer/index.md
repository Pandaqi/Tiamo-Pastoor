---
title: Die dag was er geen geneurie meer
author: hetisdepanda
type: post
date: 2017-08-09T16:00:06+00:00
url: /toverende-taal/genezende-gedichten/dag-was-er-geen-geneurie-meer/
categories:
  - Genezende Gedichten

---
De politieman vertelde het  
herhaalde het keer op keer  
hij wist het deed zo&#8217;n pijn  
hij begreep het deed zo&#8217;n zeer  
hij wist dat we hem wilden zien  
mooie woorden werden gesproken  
maar elk aanbod sloeg men neer  
die dag was er geen geneurie meer

De politievrouw vertelde het  
bevestigde keer op keer  
ze wist dit slaat een gaat  
dit gemis doet veel te zeer  
ze wist dat we niks meer wilden voelen  
mooie herinneringen aangebroken  
maar alle ogen sloegen waterig neer  
die dag was er geen geneurie meer