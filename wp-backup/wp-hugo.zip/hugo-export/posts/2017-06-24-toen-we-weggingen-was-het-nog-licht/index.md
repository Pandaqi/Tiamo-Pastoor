---
title: Toen we weggingen was het nog licht
author: hetisdepanda
type: post
date: 2017-06-24T15:00:43+00:00
url: /toverende-taal/genezende-gedichten/toen-we-weggingen-was-het-nog-licht/
categories:
  - Genezende Gedichten

---
Toen we weggingen was het nog licht  
Wanneer we aankomen weet ik niet

Druppels glijden langs het raam  
Ik schrijf je naam  
vinger tegen glas  
Maar dankzij de regen  
en wind tegen  
zal deze snel weer vergaan

Toen we vertrokken was het nog licht  
Wanneer we aankomen wil ik niet weten

Deze reis is te fijn  
de dagen te kort  
Mijn wereld te klein  
zicht op horizon ontnomen  
Door de problemen op mijn bord  
weet ik niet  
of ik ooit wel thuis wil komen

Toen we opstapten was het nog licht  
Of we ooit aankomen kan me niks schelen

Soms is eindbestemming  
einde teleurstelling  
maar vaak valt het tegen  
wil je weer wind in je haren  
en verder varen  
op hoop van zegen  
voorbij elke planning

Toen we slechte grappen maakten  
deels om tijd te doden  
deels uit nervositeit  
Lag voor ons nog een eeuwigheid  
om te wennen, gek te doen  
doelloos samen rond te dolen

Toen ik hopeloos verliefd raakte  
was het nog licht  
Toen jij wegging  
werd het weer donker