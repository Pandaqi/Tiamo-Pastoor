---
title: Personages Bedenken II
author: hetisdepanda
type: post
date: 2018-06-02T23:17:57+00:00
url: /gewoon-een-gedachte/personages-bedenken-ii/
categories:
  - Gewoon een Gedachte
  - Toverende Taal

---
Je wilt een goed verhaal schrijven. Je gaat naar je oude vriend Google en tikt in &#8220;how to write good characters&#8221;. Vervolgens wordt je begroet door een overvloed aan websites met schrijfadvies en je ziet door de tegenstrijdige verhalen het bos niet meer.

Dat was mijn situatie toen ik rond mijn twaalfde serieus wilde gaan schrijven. Iedereen zei iets anders, en uiteindelijk werden alle personages in mijn verhalen gewoon een mini-versie van mezelf. (Op dat moment zag ik dat overigens niet. Ik dichtte mezelf ook veel goede eigenschappen toe: &#8220;ha, ik ga het hoofdpersonage baseren op mij, dan is het tenminste realistisch! Oh kijk, in hoofdstuk 10 kunnen we wel een draak toevoegen, en die verslaat het hoofdpersonage _natuurlijk_.&#8221;)

## Vragenlijsten I

Bepaalde websites boden mij een &#8220;vragenlijst&#8221; aan die ik voor elk personage zou moeten beantwoorden. Blijkbaar was het _essentieel_ om te weten welke kleur haar ogen hebben, of haar kapsel een knot is, en of ze lange of korte benen heeft. Blijkbaar werd ieder persoon gedefinieerd door zijn huidskleur, haarkleur, lievelingsdier en medische afwijkingen. Blijkbaar waren talloze boeken gevuld met scenes als deze:

<!--more-->

<p style="padding-left: 30px;">
  &#8220;Henriette. Maak <em>nu</em> een keuze! Geef mij het geld, en ik laat je man en kinderen gaan.&#8221;<br /> Henriette stond stokstijf stil. Ze keek uit het raam. Honderd miljoen euro; ze kon er makkelijk de rest van haar leven luxe van leven. Maar kon ze het over haar hart verkrijgen om haar man en kinderen te laten vermoorden? Ze keek naar haar lange benen, wreef in haar gespierde handen en trok aan haar felrode haar. Natuurlijk, hoe kon ze zo dom zijn.<br /> &#8220;Een gemene streek, Hans, je weet dat ik lange benen heb. Ik geef je het geld.&#8221;
</p>

Aan sommige van deze eigenschappen kun je nog een goed verhaal verbinden. Zo kan iemand gespierde handen hebben omdat ze een getrainde ninja is. Maar meestal stopte ik halverwege de lijst omdat het gewoon echt niet zo behulpzaam of interessant was.

**Interessant**. Dat is een belangrijk woord, onthoudt het.

## Vragenlijsten II

Dus ik zocht verder en kreeg vragenlijsten van een andere variëteit. Eentje met diepgaande, interessantere vragen. Bijvoorbeeld:

<p style="padding-left: 30px;">
  Hoe was haar jeugd?<br /> Waar is ze het meest bang voor?<br /> Waar wordt ze het gelukkigst van?<br /> Waarmee is ze geobsedeerd?<br /> Op wat/wie is ze verliefd?
</p>

Dus ik kopieerde de vragenlijst en begon naar hartenlust (ik typte eerst per ongeluk _hartenlijst_) in te vullen. Ook hier liep ik al snel tegen obstakels aan. Niet iedereen is heel bang voor dingen, of geobsedeerd met iets, of verliefd. Niet iedereen heeft een enorm spannende jeugd waarin duizend interessante dingen gebeurden. Niet iedereen wordt gedefinieerd door de antwoorden op een twintigtal vragen.

Eerst was ik nog koppig. Ik dacht dat ik niet creatief genoeg was en besloot alsnog antwoorden te forceren. Maar wat je dan krijgt is niet bepaald een vooruitgang:

  * &#8220;Waar is ze het meest bang voor?&#8221; => &#8220;Eh &#8230; olifanten! Ja! Want die kunnen op je gaan staan!&#8221;
  * &#8220;Waarmee is ze geobsedeerd?&#8221; => &#8220;Poeh &#8230; spaaracties van supermarkten?&#8221;
  * &#8220;Op wat/wie is ze verliefd?&#8221; => &#8220;Haar &#8230; kat?&#8221;

Wederom is dit best een prima manier om op ideeën te komen. Het is een manier om creativiteit te &#8220;forceren&#8221; en een zoektocht af te leggen naar wie je karakter nou precies is. Zo kan je boek best een leuke grap bevatten door iemand te laten obsederen over spaaracties. Zo kan, tijdens de climax, iemand kiezen om haar huisdier te redden in plaats van haar vriend (wat dan weer veel zegt over dat personage).

Maar het _definieert_ je personage niet. Stel je eens voor dat de politie een onderzoek doet naar een moord die in jouw achtertuin heeft plaatsgevonden. Natuurlijk ben jij een verdachte, dus ze vragen al jouw vrienden en kennissen om te vertellen hoe jij bent als persoon. Denk je dan dat het als volgt gaat?

<p style="padding-left: 30px;">
  &#8220;Vertel eens, hoe is Peter als persoon?&#8221;<br /> &#8220;Ik ken hem al jaren. Hij is bang voor spinnen, verliefd op zijn buurmeisje, en vindt niets leuker dan &#8217;s avonds naar voetbal kijken. Hij heeft in zijn jeugd een keer een lekke band gehad waardoor hij een uur door de regen naar huis moest lopen. Bovendien zijn pannenkoeken zijn lievelingsvoedsel, kan hij voor geen meter koken, maar wél heel goed uit zijn hoofd rekenen. Maar, als je mij vraagt om Peter in één woord te omschrijven, dan ga ik toch voor: <em>pretentieus</em>. Beantwoordt dat uw vraag?&#8221;<br /> De politieman vinkte snel een hoop vakjes aan en tikte zijn pen tegen het laatste vakje, de enige die nog leeg was.<br /> &#8220;Bijna. Je hebt nog één vraag niet beantwoordt: heeft Peter een bepaald stopwoordje of stopzin?&#8221;<br /> &#8220;Ja. <em>Wie niet waagt, wie niet winter</em>. Niemand vindt het meer grappig ondertussen.&#8221;<br /> &#8220;Dan weten wij genoeg. Haal Peter even, dan kan ik hem arresteren.&#8221;
</p>

Als je zoekt op &#8220;character questions&#8221; (of &#8220;character questionaire&#8221;) vindt je meteen websites met _gigantische _lijsten. Mijn advies: begin er niet aan. Een groot deel van de vragen is of té vaag of juist té specifiek. Het antwoord op veel van die vragen is niet _interessant_, dus het heeft ook geen plek in jouw verhaal. (In de zin van: je moet geen saaie of irrelevante details door je verhaal gooien, en je hebt ook helemaal geen tijd en ruimte om een personage 100% over te brengen.)

## Vragenlijsten III

Dus vond ik het tijd worden voor een nieuw soort vragenlijst. Een simpele vragenlijst die de _kern_ van het karakter vastlegt. Al die gigantische vragenlijsten kunnen makkelijk beantwoord worden als ik eenmaal de kern heb, maar andersom zorgt het beantwoorden van die vragenlijsten niet voor een begrip van het personage. Het maakt me niet uit wat de lievelingsband is van mijn karakter, of welke kleur shirt hij draagt, of welke drie abstracte schilderijen er in zijn huis hangen, als ik niet de 5 of 10 definiërende eigenschappen weet.

Het idee voor deze soort vragenlijst ontstond toen ik half met een kaasschaaf in mijn duim sneed. Ik reageerde daar nauwelijks op. Het is een wonder dat de lichte verwonding me überhaupt opviel. (Ik ben vroeger wel eens thuis gekomen onder het bloed omdat ik van de fiets was gevallen, en mijn ouders schrokken dan enorm, maar ik was allang vergeten dat ik was gevallen :p) Andere mensen zouden anders reageren. Zij zouden meteen schreeuwen, of de kaas(schaaf) vervloeken, of als een gek door de keuken rennen op zoek naar iets van pleisters.

Eén situatie, veel verschillende reacties. En hoe graag mensen ook denken dat ze allemaal hartstikke uniek zijn, dat is niet zo. Over het algemeen kun je aan de reactie op zo&#8217;n situatie (een wond, pijn, jezelf snijden) al delen van iemands personage aflezen en induceren. Door een aantal herkenbare of juist extreme situaties voor te leggen, en daar _eerlijke_ antwoorden op te geven, weet je wie iemand in de kern is.

Mijn vragenlijst(je) bestaat dan ook alleen uit het volgende formaat probleem: **&#8220;gegeven deze situatie, welke keuze maakt dit personage?&#8221;** Het idee is dat je alles mag invullen wat je kan bedenken. Je moet niet van tevoren iets bedenken als &#8220;dit personage is altijd chagrijnig&#8221; en dat dan in alle antwoorden proberen te verwerken. Vul alles in zoals het in je opkomt, en bedenk dan, op basis van die informatie, _waarom_ je personage is zoals ze is en wat je er voor interessante backstory of details aan kunt verbinden.

_Opmerking:_ vaak is het verstandig om je eigenschappen te spreiden over personages, en om de belangrijkste personages tot tegenpolen te maken op bepaalde vlakken. Als jij een groep van 3 avonturiers hebt, is hun chemie het meest interessant als ze allemaal zo ver mogelijk uit elkaar liggen, en zo veel mogelijk tegenovergesteld denken over dingen.

Stel je komt in een donkere grot. Dan kan het ene personage misschien bang zijn, terughoudend, passief, stil staan. Een ander personage is heel praktisch; ze zoekt meteen licht en kijkt of bepaalde delen van de grot op instorten staat. Het derde personage kan misschien overmoedig of te gehaast zijn, en al meteen blind de grot inrennen en alles kort en klein slaan. Je moet natuurlijk niet altijd zulke extremen nemen, want dan krijg je een verhaal waarin personages alleen maar zeuren, debatteren en schreeuwen over meningsverschillen. Maar het helpt enorm als je deze techniek gebruikt op een paar belangrijke punten.

## Dé vragenlijst

Hieronder zijn de leukste (of interessantste) die ik kan bedenken. Denk dus achter elke probleemstelling: &#8220;wat doet je personage?&#8221;

_Opmerking:_ je mag zo gedetailleerd antwoorden als je wilt. In de meeste situaties zijn er namelijk best uitzonderingen te bedenken. Bijvoorbeeld: je personage wordt uitgenodigd voor een feest. Wat doet hij? Nou, dat ligt aan zijn relatie met de persoon die het feest geeft. Of misschien aan het thema/datum van het feest. Ander voorbeeld: je personage krijgt te horen dat iemand verliefd op hem is. Zijn reactie kan dan afhangen van of het zijn beste vriendin is, of een collega die hij nauwelijks gesproken heeft.

_Opmerking:_ deze lijst kan natuurlijk worden uitgebreid. Dat zal ik over tijd vanzelf doen, als me iets nieuws of beters te binnen schiet. (Natuurlijk mag je zelf ook suggesties geven!)

  * &#8220;Je personage moet om 2 uur &#8217;s nachts plassen. De wc is helemaal beneden en alles is donker en verlaten.&#8221;
  * &#8220;Je personage snijdt zichzelf in zijn vinger.&#8221;
  * &#8220;Je personage wordt aangereden en ligt met zware verwondingen op de grond.&#8221;
  * &#8220;Je personage _ziet_ iemand anders die aangereden wordt.&#8221;
  * &#8220;Je personage is &#8217;s nachts nog beneden aan het werk, als er ingebroken wordt.&#8221;
  * &#8220;Je personage komt een donkere grot binnen.&#8221;
  * &#8220;Je personage is verliefd op iemand anders.&#8221;
  * &#8220;Je personage krijgt te horen van iemand anders dat hij/zij verliefd is op diegene.&#8221;
  * &#8220;Je personage is alleen thuis en heeft een avond voor hemzelf.&#8221;
  * &#8220;Je personage voelt dat het pak yoghurt dat hij aan het schenken is bijna op is.&#8221;
  * &#8220;Je personage speelt een (bord)spel en is aan het verliezen.&#8221;
  * &#8220;Je personage zit op de wc, heeft z&#8217;n ding gedaan &#8230; en ziet dan pas dat het wc-papier op is.&#8221;
  * &#8220;Je personage heeft gefaald bij een zekere beproeving (een test slecht gemaakt, een sollicitatie/auditie verknald, het monster niet verslagen, et cetera).&#8221;
  * &#8220;Je personage komt op bezoek bij de meest wrede, egoïstische koning van het land, om hem een vriendelijke gunst te vragen.&#8221;
  * &#8220;Je personage heeft net de keuken schoongemaakt en gestofzuigd, als een gezinslid binnen banjert met vieze laarzen.&#8221;
  * &#8220;Je personage krijgt de tijd/ruimte/geld om een uitje te organiseren.&#8221;
  * &#8220;Je personage krijgt een uitnodiging voor een feest.&#8221;
  * &#8220;Je personage heeft zich verslapen (of een fout gemaakt op het werk) en wordt daarop aangesproken.&#8221;
  * &#8220;Je personage zit aan het begin van het schooljaar ineens naast een nieuw persoon in de klas.&#8221;

Hopelijk heb je hier iets aan 🙂