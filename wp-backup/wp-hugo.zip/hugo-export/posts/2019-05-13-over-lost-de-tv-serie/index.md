---
title: Over LOST (de TV serie)
author: hetisdepanda
type: post
date: 2019-05-13T13:16:27+00:00
url: /visuele-fratsen/over-lost-de-tv-serie/
categories:
  - Gewoon een Gedachte
  - Toverende Taal
  - Visuele Fratsen

---
Onlangs heb ik een recensie gepubliceerd van de serie LOST. Het is een van de weinige series die ik van begin tot eind heb gekeken, maar ik geef het uiteindelijk een voorzichtige 7. De eerste seizoenen zijn GEWELDIG, daarna blijkt alles een grote rommelige grap.

Ik vond dat interessant en wilde de serie verder analyseren. Ik ben een schrijver die steeds probeert te verbeteren, dus ik vind het leuk om hier lekker diep op in te gaan.

Waarom is het zo slecht? Waarom is het enerzijds heel goed, maar anderzijds een grote teleurstelling? Hoe zou ik het verhaal anders hebben geschreven of het idee anders hebben uitgewerkt?

Lees verder, lees verder!

_Opmerking:_ als je alleen de _spoilervrije recensie_ wilt lezen, klik dan hier: [**Serierecensie: LOST (2004-2010)**][1]

<!--more-->

## De belangrijkste elementen

Ik zal alles behandelen aan de hand van de belangrijkste elementen voor zo&#8217;n serie (in mijn ogen):

  * **Samenhang** (of &#8220;structuur&#8221;)
  * **Worldbuilding**
  * **Personages**
  * **Plot** (vooral &#8220;tempo&#8221; en &#8220;spanningsboog&#8221;)
  * **De rode draad**

Daarnaast zal ik uitleggen waarom het lijkt alsof de schrijvers van de serie _geen idee hadden wat ze aan het doen waren_ (en waarom dat vervelend is). Ik zal het artikel afsluiten met mijn eigen uitwerking van het idee (&#8220;vliegtuigcrash op mysterieus eiland&#8221;).

Deze serie heeft véél inhoud (121 afleveringen van ~40 minuten). Daarnaast vinden de schrijvers het leuk om afleveringen vol te proppen met mysteries, vaagheden, nieuwe verhaallijnen, nieuwe karakters, etc.

Dit artikel is uiteindelijk vrij lang geworden en ik heb nog steeds maar een klein deel van de serie en zijn mythologie besproken. Daarom heb ik besloten om alleen de hoofdzaken te behandelen. Daarna vind ik het handiger om een eigen versie van het verhaal te laten zien, dan om vijftigduizend woorden te besteden aan elk detail van de serie blootleggen.

## Een belangrijke disclaimer

Ik wil alvast een **disclaimer** maken. Eén van de grootste kritiekpunten jegens deze serie is dat &#8220;niet alle mysteries worden opgelost&#8221; en &#8220;de schrijvers geen master plan hadden&#8221;. Vaak wordt deze kritiek weerlegt met het argument dat &#8220;je niet kunt verwachten dat ze elk detail en elk plotpunt al zes jaar van tevoren weten&#8221; en dat &#8220;een verhaal niet alle vragen moet beantwoorden&#8221;.

Ik ben het hiermee eens. Niemand is perfect, waardoor een aantal fouten, plot holes en inconsistenties altijd aanwezig zullen zijn. Daarnaast weet niemand van tevoren exact hoe het verhaal loopt, _want ze moeten het verhaal nog schrijven_. Je moet improviseren, je moet mysteries openen waarvan je nog lang niet weet hoe ze gaan eindigen, je moet wat proberen om in een creatieve flow te blijven. Soms dwingen omstandigheden je om ter plekke je plan te veranderen.

<p style="padding-left: 30px;">
  Dit document is een navertelling van één van de schrijvers gedurende de eerste twee seizoenen: <a href="http://okbjgm.weebly.com/uploads/3/1/5/0/31506003/lost_will_final.pdf"><strong>Lost Will and Testament</strong></a> (&#8230; hilarische woordgrap). Het laat goed zien in hoeverre ze een plan hadden, maar ook hoe het schrijfproces van een TV serie gaat en waarom je niet te alles kunt verwachten.
</p>

<p style="padding-left: 30px;">
  Zelfs ik weet hoe lastig het is. Ik schrijf veel kortere verhalen dan zo&#8217;n TV serie, maar heb met regelmaat iets in het verhaal gegooid met het idee &#8220;dit klinkt spannend &#8211; ik zoek later wel uit wat het betekent&#8221;. Een beetje alsof je een personage een pistool geeft, maar nog niet weet waarom het personage dat pistool heeft.
</p>

Maar er is een grens. Een schrijver hoort wel degelijk de belangrijkste punten van zijn verhaal van tevoren te weten. Rowling (de schrijfster van Harry Potter) wist niet precies hoe haar verhaal zou lopen, maar het idee erachter en de belangrijkste punten stonden al vast. Ze wist dat het een strijd ging worden tussen goed (Harry & Co) en kwaad (Voldemort). Een overgroot deel van de magische wereld was al uitgedacht en met elkaar verbonden. De meeste personages en hun ontwikkeling waren al bekend, evenals enkele grote gebeurtenissen in de verschillende delen. Ik weet wel zeker dat dit voor een groot deel heeft bijgedragen aan het succes van Harry Potter.

De schrijver moet alles wat hij begint zoveel mogelijk afmaken. Een verhaal is namelijk niets meer dan het _beginnen van mysteries_ en het vervolgens _oplossen van mysteries_. Als je irrelevante of onopgeloste mysteries toevoegt, stopt het hele verhaal met werken. Denk bijvoorbeeld aan een simpele romantische komedie (&#8220;romcom&#8221;). De mysteries aan het begin zijn vaak: Wie zijn deze twee mensen? Hoe komen deze personages samen? En hoe gaat deze liefde aflopen? Als de romcom al deze vragen opwerpt, maar vervolgens eindigt _zonder antwoord te geven_, dan voelt het niet als een fatsoenlijk verhaal toch? Dan heb je twee mensen dingen zien doen (zonder ze te leren kennen), toen waren ze ineens samen (zonder dat je weet hoe), en dan stopt de film ineens (zonder dat je weet hoe het afloopt)

Het punt wat ik probeer te maken in dit artikel is dat de schrijvers van LOST ver voorbij de grens zijn gegaan. Je mag fouten maken, je mag dingen open laten, je mag gaandeweg je idee veranderen, maar er is een grens.

_Opmerking 1:_ Het argument wat men dan geeft is &#8220;ja maar, ze wisten niet hoeveel afleveringen ze gingen krijgen!&#8221; Inderdaad, TV series weten van tevoren niet exact hoeveel tijd ze krijgen. Ten eerste: dit is geen heel groot probleem, zolang je seizoenen op zichzelf laat staan en een goede structuur in de afleveringen brengt. Dan kun je op elk moment stoppen. Ten tweede: ik geef hier niks om. In dit artikel analyseer ik de serie zelf en wat ik uiteindelijk voorgeschoteld krijg &#8211; ik ben niet op zoek naar excuses of verklaringen voor de gebreken. (Hoewel ik begrijp dat een grote en complexe serie schrijven geen makkelijke taak is.)

_Opmerking 2:_ Als dat nog niet genoeg is, vallen veel fans terug op het argument der argumenten: &#8220;you just didn&#8217;t get it&#8221; (of &#8220;you&#8217;re not smart enough&#8221;). Nee, nooit doen. Dat is een doodzonde. Als je een verhaal schrijft, en een significant deel van je lezers begrijpt het niet, dan moet je niet zeggen dat het aan de lezers ligt. Dan had je zelf meer moeite moeten doen om alles duidelijker en simpeler te houden. Dit betekent niet dat je de gelaagdheid of complexiteit weg hoeft te halen &#8211; dat zou ik zelfs nog slechter vinden. Dit betekent dat je duidelijker moet schrijven, en hoofdzaken van bijzaken moet scheiden, iets waar ik later nog even op terugkom.

## Samenhang

Een serie als geheel moet veel samenhang hebben. Een gemiddelde serie heeft misschien wel 100 uur beeldmateriaal; je wilt dat het als een geheel voelt en dat een kijker zijn tijd niet verspild. Als jij twintig uur investeert in een serie, en vervolgens blijken de schrijvers geen idee te hebben of op een compleet andere voet verder te gaan, ben je daar niet blij mee.

Daarnaast is dit een &#8220;mysterie&#8221;, en als die niet klopt valt je hele verhaal uiteen, want dan blijft het mysterie voor eeuwig een mysterie.

### Goede samenhang

In _deel 1_ van de serie zit een leuke samenhang, waarvan ik altijd een groot fan ben. Elke aflevering begint met een close-up van iemands ogen. Gedurende de aflevering leer je die persoon kennen via flashbacks, terwijl die persoon op het eiland zelf ook een belangrijke rol vervult.

(Er zit een geluidseffectje bij de overgang tussen &#8220;flashback&#8221; en &#8220;huidige tijd&#8221; en dat geluidje zit inmiddels zó in mijn hersenen gebrand dat ik het overal hoor. Maar het is wel effectief, want het is vrijwel altijd meteen duidelijk in welke tijd je zit.)

In _deel 2_ switchen we van flashbacks naar &#8220;flashforwards&#8221;. Je bent in de huidige tijd (op het eiland) en in de toekomstige tijd (wanneer enkele personages van het eiland zijn gekomen). Ik vond dit een leuke wissel, precies halverwege de serie, ware het niet dat ze deze flashforwards compleet weggooien richting het einde van de serie. Dan worden de afleveringen steeds rommeliger en zit dit patroon er niet meer zo goed in.

Aan de andere kant snap ik waarom ze het hebben gedaan: in de laatste seizoenen wordt veel gespeeld met tijd, waardoor niet duidelijk is wat nou een &#8220;flashback&#8221; is en wat een &#8220;flashforward&#8221;.

Deze algemene samenhang is leuk en maakt de serie uniek en herkenbaar. Waar gaat het mis? Nou, er is verder nauwelijks samenhang.

### Minder goede samenhang

Ik kan hier duizenden voorbeelden geven van dingen die niet kloppen of niet opgelost worden in de serie, maar het lijkt me handiger om op het hoofdprobleem te focussen.

**De serie heeft géén duidelijk doel of antagonist.**

De serie leunt vooral op het &#8220;mysterie&#8221; gedeelte en dat je meer van de personages wilt weten (waar komen ze vandaan en hoe loopt het met ze af). Het doel en de antagonist (&#8220;hetgeen de personages tegenhoudt om dit doel te bereiken&#8221;), verandert constant gedurende de serie.

Het ene moment willen ze van het eiland af, het andere moment willen ze dat niet meer, en dan ineens zijn ze van het eiland en willen ze weer terug!

Het ene moment vechten ze tegen &#8220;the Others&#8221;, maar dan staan die ineens aan hun kant als ze tegen iemand anders vechten, en het volgende seizoen komt er _weer_ een nieuwe groep mensen naar het eiland om er een rotzooi van te maken.

Er is veel conflict &#8230; maar het voelt inhoudsloos. Al het vechten van de ene aflevering, wordt weer ongedaan gemaakt de volgende aflevering. Je werkt niet duidelijk ergens naartoe en soms moet je drie afleveringen wachten voordat één van de verhaallijnen weer wordt opgepakt. Als je middenin een seizoen zit, voelt het daardoor heel rommelig en moeilijk om te volgen.

Meerdere keren was ik halverwege een seizoen compleet de draad kwijt en twijfelde ik of ik wel moest doorkijken. Het voelde niet alsof de serie ergens heen ging en ik had weinig hoop op een goede afloop.

Dit vind ik raar, aangezien dit probleem misschien wel het makkelijkst is om op te lossen (van alle problemen). Hier, ik zal het even voordoen.

_Wat is ons doel?_ Van het eiland afkomen! _Wat houdt ons tegen?_ Het &#8220;monster&#8221; op het eiland heeft ons nodig en laat ons niet vertrekken. Bam, werk het uit, spreid het over 6 seizoenen, en je hebt een duidelijke samenhang.

Natuurlijk moet je dit indelen in &#8220;kleine doelen&#8221; en &#8220;kleine antagonisten&#8221;, maar ook dat is geen rocket science.

_Wat zijn onze kleine doelen?_ Zoek een manier om het vliegtuig te repareren, zoek een manier om contact te maken met de buitenwereld, verken het eiland op zoek naar interessante dingen, zoek naar voedsel/water, etc.

_Wat zijn onze kleine antagonisten?_ Mensen die al op het eiland leven en niet zitten te wachten op indringers, conflict binnen de groep vanwege de persoonlijkheden/verledens van verschillende mensen, etc.

Gedurende de serie kan dan steeds meer duidelijk worden dat deze &#8220;kleine antagonisten&#8221; werken voor het monster of daardoor zijn gestuurd. Ook moet elk &#8220;klein doel&#8221; leiden tot een nieuw &#8220;klein doel&#8221;, en nooit een dood eind zijn of een stap terug. Uiteindelijk zal alles zo op zijn plek vallen.

Deel 1 werkt nog soort van ergens naartoe, en behaalt veel van de kleine doelen die ik hierboven uitleg, maar daarna verliezen ze dit doel uit het oog. Zeker als blijkt dat veel van de opgezette mysteries irrelevant zijn of niet worden afgewerkt, mist het verhaal duidelijk richting. In de eerste seizoenen proberen ze wel van het eiland te komen, maar als tussendoor steeds flashbacks van 10-20 minuten zitten die uiteindelijk compleet irrelevant blijken, zou je dat hoofddoel haast vergeten.

Dit wordt goed weergegeven in het &#8220;eiland hoppen&#8221;: in seizoen 1-3 proberen ze van het eiland te komen, in seizoen 4 gaan ze eindelijk van het eiland af, om vervolgens in seizoen 5 weer terug te komen, en in seizoen 6 weer te vertrekken. Nog erger: John Locke wil als enige niet van het eiland af, maar gaat in seizoen 5 toch van het eiland, om ook in datzelfde seizoen weer terug te worden gebracht.

Ik heb gewoon niet het idee dat de schrijvers hier van tevoren goed over hebben nagedacht. Als ze dat wel hadden gedaan, had de serie een veel grotere samenhang gehad en sterker gevoeld. (Aan het einde van dit artikel zal ik wat bewijs leveren dat de schrijvers echt geen idee hadden, maar die informatie vond ik pas nadat ik deze hele recensie had geschreven.)

Hiermee komen we op ons tweede punt &#8230;

## Worldbuilding

De serie is grotendeels realistisch, maar heeft ook redelijk wat fantasierijke elementen. Het begint vooral als een _science fiction_, maar blijkt richting het einde eigenlijk een _fantasy_ te zijn. In het begin verwacht je een hele logische en wetenschappelijke verklaring voor alles wat er gebeurt, aan het einde blijkt dat dingen gewoon zijn wat ze zijn en iemand een beetje God loopt te spelen.

Uit deze woordkeuze kun je mijn mening over de worldbuilding al wel opmaken, denk ik.

Dit is hoe het werkt: als je een nieuwe/andere wereld opbouwt in je verhaal, wil je dat deze zo realistisch en levendig mogelijk overkomend. Dit doe je door zoveel mogelijk details juist te krijgen. De echte wereld is consistent in zijn regels, in de echte wereld gedraagt men zich op een bepaalde manier, en dat wil je zoveel mogelijk overhevelen naar je fantasiewereld.

(Een leuk voorbeeld wat ik laatst zag, was een schrijfster die bepaalde uitspraken uit de echte wereld vertaalde naar haar fantasiewereld. Vergelijkbaar met J.K. Rowling die uitspraken als &#8220;Merlin&#8217;s beard!&#8221; in Harry Potter stopte, waar we in het echt iets van &#8220;Oh my god&#8221; of &#8220;Oh lord!&#8221; zouden zeggen. Als je erop let, zul je zien dat een goede fantasiewereld heel veel details goedkrijgt.)

Nou, dat doen ze in deze serie niet echt.

De regels van de wereld worden _niet duidelijk gemaakt_, worden _niet consistent nageleefd_, en hebben vaak _geen oplossing of logisch vervolg._

Er zijn ontelbaar veel vragen die deze serie overduidelijk opwerpt, maar nooit beantwoord. Het ene moment zegt men &#8220;dood is dood&#8221;, maar even later blijkt dat niet altijd zo te zijn? Het ene moment zegt men &#8220;whatever happened, happened&#8221; (om aan te geven dat tijdreizen niks verandert aan wat er is gebeurt), maar ergens anders blijkt dat men wel degelijk invloed heeft op dingen? De lijst van vragen is eindeloos.

Als er dan een uitleg of bespreking komt, zeggen ze &#8220;het eiland wil dit&#8221; of &#8220;dat is nou eenmaal hoe het eiland werkt&#8221;. Het voelt allemaal nep, ter plekke bedacht door de schrijvers.

Natuurlijk doen ze ook dingen goed. In de laatste seizoenen proberen ze in alle haast zoveel mogelijk dingen te verklaren, en soms lukt dat best goed. De introductie van Jacob en zijn broer (die het monster blijkt te zijn) geeft wat meer richting en samenhang aan het verhaal. Het vertelt iets meer over het ontstaan en de werking van het eiland &#8230; maar laat nog steeds veel onduidelijk. Als ze dit _vanaf het begin_ hadden meegenomen en laten zien, had het een hele sterke verhaallijn kunnen zijn. Maar ik denk dat de schrijvers simpelweg niet wisten dat ze hiernaartoe zouden schrijven.

Uiteindelijk voelt het als een **gemiste kans**. Ze hadden de hele historie en werking van het eiland kunnen bedenken, voordat ze überhaupt begonnen met seizoen 1. (Om J.K. Rowling er nog eens bij te halen: zij heeft jarenlang haar Harry Potter wereld uitgebouwd en doorgedacht over de gevolgen van magie, voordat ze überhaupt het eerste boek schrijf.) Daarmee hadden ze een hele sterke en overtuigende wereld kunnen bouwen.

Ook weet ik zeker dat er dan een goed verhaal uit was gekomen. Gedurende de serie spelen ze bijvoorbeeld soms met _tijdreizen._ Als de schrijvers de hele geschiedenis van het eiland hadden uitgedacht, hadden ze supercoole dingen kunnen doen. Misschien hoorden de karakters in seizoen 1 en 2 over &#8220;de Grote Storm&#8221;, en in seizoen 5 gaan ze terug in de tijd en moeten ineens een paar afleveringen in die grote storm zien te overleven. Een beetje goede schrijver had deze storm dan ook nog een belangrijk gevolg gegeven. Misschien was een deel van het eiland verwoest of veranderd.

Tijdens het kijken van deze serie, kreeg ik de hele tijd zin om &#8220;mijn eigen LOST&#8221; te schrijven. Het is gewoon een heel goed idee waar ik meer potentie in zag dan wat ik uiteindelijk voorgeschoteld kreeg. (Toegegeven, ik heb echt niet genoeg ervaring om zo&#8217;n serie als LOST te schrijven, maar het is leuk om te denken alsof ik een &#8220;betere LOST&#8221; zou kunnen maken :p)

Nou weet ik wel dat de regisseur van de serie, J.J. Abrams, bekend staat om zijn onvermogen mysteries op te lossen. Hij is héél goed in mysteries bedenken, zoals dit eiland, maar héél slecht in het op bevredigende manier oplossen of afronden. (Hij heeft zelfs een TED Talk gegeven over zijn &#8220;mystery box&#8221;.) Misschien draagt dat bij aan mijn gevoel over de serie: deel 1 roept heel veel interessante vragen en mogelijkheden op, en voelt daarom heel sterk, maar deel 2 lost nauwelijks iets op en voelt daardoor inhoudsloos.

## Personages

### De goede kanten

Ik ben voorheen vol lof geweest over de personages. Het is voor mij ook duidelijk het sterkste punt van de serie. (Online gebruiken ook veel mensen het als een verdediging, zoals &#8220;het gaat niet om het plot of het eiland, het gaat om de personages!&#8221;, maar dat vind ik te ver gaan.)

Je wilt dat kijkers van een serie de personages van binnen en buiten leren kennen. Ze moeten voelen alsof ze samen met de personages op een avontuur gaan, alsof ze ermee bevriend raken of een goede band opbouwen. De kijkers moeten geven om elk personage om een unieke reden. (Als je alle personages &#8220;superlief&#8221; maakt, dan vinden de kijkers ze vast ook lief, maar het maakt geen goede en interessante serie.)

Daarnaast moeten de personages alles in gang zetten. Het verhaal wordt vooruitgestuurd door de acties van de karakters. Als je het andersom doet, en zomaar iets laat gebeuren waar de karakters volgens op moeten reageren, ga ik me daar enorm aan ergeren :p

Gelukkig zit dit grotendeels goed bij deze serie. Alle karakters zijn heel uniek, met een eigen achtergrond, eigen persoonlijkheid, eigen vaardigheden, etc. Diezelfde achtergrond/persoonlijkheid bepaald vaak ook hun beslissingen en acties, die vervolgens het verhaal weer doen veranderen.

Je kent de karakters, je voelt voor ze, je wilt dat het goed afloopt. Sommige sterfscenes werd ik best emotioneel van, zeker als het net mijn lievelingskarakter was. (Andere sterfscenes waren gehaast en slecht uitgewerkt, zoals ik hierboven al zei, maar je kunt ook niet alles hebben.)

_Opmerking:_ hierboven vertelde ik dat de schrijvers vaak uit het niets iets toevoegen aan de serie. De personages willen iets doen &#8230; maar ineens blijkt het eiland een nieuwe regel te hebben! De personages komen bijna van het eiland &#8230; maar ineens komt er een nieuwe slechterik! Dat blijft een beetje vervelend, maar gelukkig tast het de personages niet heel erg aan. Het zijn meer overduidelijke technieken om het verhaal interessanter te maken en een nieuwe boost energie te geven. Leuke personages zijn leuk, maar ze hebben ook obstakels nodig, anders heb je ze na tien afleveringen wel gezien.

_Opmerking:_ één van mijn favoriete delen van de serie was wanneer de personages iets deden wat heel &#8220;silly&#8221; was, maar juist ook heel menselijk. Zoals wanneer ze een tafeltennistafel neerzetten, of een golfbaan maken. Ik had daar best meer van willen zien. Dat ze een karaoke avond houden op het strand, ofzo.

### De minder goede kanten

Het enige wat mij opviel is dat de schrijvers een beetje in herhaling vielen. Ontelbare keren begint een gesprek met &#8220;you wouldn&#8217;t believe me if I told you the truth&#8221;, waarop de ander reageert met &#8220;try me&#8221;. Ontelbare keren wordt iemand met een geweer knockout geslagen, meestal van achter, en meestal wanneer diegene het net niet verwacht. (Gek genoeg lukt deze actie altijd en heeft niemand bulten op z&#8217;n hoofd, hersenschuddingen, of langdurige schade.)

Hoewel de meeste hoofdpersonages een eigen &#8220;stem&#8221; hebben (qua praatstijl, intonatie, woordkeuze, etc.), voelt alle dialoog op een gegeven moment ook hetzelfde. Deze serie heeft een hoog gehalte &#8220;we staan in een kring en discussiëren op boze toon over onze volgende stap&#8221;. (Ik ben hier zelf ook schuldig aan, daarom viel het me op. In mijn oude verhalen was bijna de helft van de hoofdstukken een &#8220;vergadering&#8221; of &#8220;bijeenkomst van vrienden&#8221;.)

_Opmerking:_ vooral James Sawyer vond ik leuk, met zijn bijnamen voor iedereen en slimme uitspraken met referenties. Onthoudt: dialoog in verhalen moet niet extreem realistisch zijn, het moet extreem interessant en leuk zijn. In boeken heeft iedereen een geniale comeback :p

Waar ik me het meest aan stoor, echter, is mensen die _liegen_ of _informatie achterhouden_ zonder goede reden. WAAROM!? Zeg gewoon hoe het zit. Je zult er geen last van hebben en het zal iedereen helpen. In de echte wereld durven mensen soms ook iets niet te zeggen &#8230; maar niet zó vaak als in deze serie. (En meestal met een betere reden dan &#8220;ik wilde je niet bang maken&#8221; of &#8220;je zou me toch niet geloven&#8221;.)

### De gemiste kansen

Richting het einde van de serie staat de _ontwikkeling_ van de karakters grotendeels stil. Je hebt ze leren kennen, en sommige karakters hebben een belangrijke ontwikkeling doorgemaakt, maar er is geen duidelijk &#8220;eindstation&#8221;. Het is niet alsof het &#8220;bange karakter&#8221; na zes seizoenen had geleerd om zijn angsten te overwinnen, of dat het &#8220;boze karakter&#8221; na zes seizoenen eindelijk rust had gevonden. De meeste karakters zijn grotendeels hetzelfde gebleven.

Dat vind ik een grote gemist kans. Het verklaart ook waarom ik het einde van de serie redelijk teleurstellend vond. Een verhaal draait om personages en een goed einde moet de &#8220;character arc&#8221; van de personages bevredigend afronden. Je mag best een open einde hebben, of veel vragen onbeantwoord laten, maar de karakters waarmee je 100 uur een avontuur hebt beleefd moeten een fatsoenlijk einde krijgen.

Bijvoorbeeld: _Sayid_ heeft de hele serie lang een innerlijke tweestrijd. Enerzijds is hij een martelaar en heel goed in vechten/vermoorden, anderzijds wil hij daarmee ophouden en een goed mens worden. Het was logisch geweest als hij gedurende de serie steeds meer zijn oude slechte gewoontes afschudde en leerde om een goed en vredig mens te zijn. In sommige afleveringen lijken de schrijvers deze transitie ook op te zetten. Maar in het laatste seizoen &#8230; is hij gewoon weer op en top slecht? Hij laat de grote slechterik (&#8220;the smoke monster&#8221;) binnen, hij vermoord links en rechts allemaal mensen, en zelfs in de &#8220;flashbacks&#8221; begint hij uiteindelijk weer met moorden.

Ik vond Sayid een goed karakter en had hem een veel sterkere karakterboog en afrondig gegund.

Datzelfde geldt voor een groot deel van de andere hoofdpersonages.

## Plot (Tempo & Spanningsboog)

Veel series maken een heel sterk/spannend/cliffhangerig begin en einde van het seizoen &#8230; maar laten het midden vergaan in saaiheid en stilstand. (Als je kijkt naar de kijkcijfers van TV series, zie je vaak dat het begin van het seizoen supersterk is, maar ook het einde. Mensen willen weten hoe het afloopt, maar weten dat het middenstuk saai is en niet het kijken waard.)

Deze serie heeft grotendeels hetzelfde probleem. De schrijvers weten heel goed hoe je een seizoen sterk begint en opent. Vaak zijn dit de allerbeste afleveringen van de hele serie. Tussen deze afleveringen wordt het vaak wat zwakker en lijkt het tempo een beetje mood swings te hebben. De ene aflevering gaan ineens twee belangrijke karakters dood, daarna gebeurt vijf afleveringen niks noemenswaardigs.

Enerzijds vind ik het prijzenswaardig dat de schrijvers niet elke aflevering met een stomme cliffhanger eindigen en niet op een moordend tempo door het verhaal gaan (om &#8220;de spanning erin te houden&#8221;). Anderzijds zijn ze iets te vaak bezig met opvulling. Daarom vind ik het tempo beter in deel 2 van de serie dan deel 1, want die heeft kortere seizoenen en werkt duidelijker en consistenter ergens naartoe.

Alles samengenomen zijn de schrijvers heel goed in een _onderhoudende serie_ schrijven. Ze weten goed waar je cliffhangers moet stoppen, hoe je moet temporiseren, hoe je gedurende het seizoen een spanningsboog moet opzetten.  De laatste afleveringen van een seizoen kun je haast niet stoppen met kijken, zo goed is die spanningsboog opgezet.

Ze bereiken hierdoor weinig dieptepunten &#8230; maar ook wat weinig hoogtepunten. Dit haakt allemaal terug op mijn eerdere opmerkingen over het plot en gebrek aan samenhang. Tot mijn verbazing vindt de belangrijkste gebeurtenis van een seizoen soms plaats bij aflevering 4 of 8 of iets dergelijks. Tot mijn verbazing spenderen we een half seizoen aan het opbouwen van een spanningsboog, die daarna compleet wordt vergeten of irrelevant blijkt. Richting het einde van de serie verloor ik daardoor al dat gevoel van spanning. Ik had weinig vertrouwen meer dat de schrijvers iets goeds gingen opzetten en dat alles wat ik zeg echt iets uitmaakte.

Bijvoorbeeld, de helft van seizoen 3 zitten de belangrijkste hoofdpersonen vast in dierenkooien. Ze doen niks. Ze zitten vast en lopen een beetje rond, terwijl ze sarcastische opmerkingen maken.

Of wat denk je van het hele mysterie rondom &#8220;er kunnen geen baby&#8217;s worden geboren op dit eiland!&#8221; Seizoenen lang wordt het opgezet, daarna compleet vergeten en genegeerd.

Of wat denk je van alle spanning die wordt opgebouwd rondom &#8220;the Others&#8221;? De eerste paar seizoenen raakt men al gestresst als iemand hun naam noemt, maar dan ineens blijken ze ook gewoon mensen die helemaal niet zo angstaanjagend zijn.

Of wat denk je van _Walt_? Seizoenenlang krijgen we te zien dat hij gekke krachten heeft en wordt gehint naar het feit dat hij superbelangrijk en speciaal is. Daarna wordt hij gewoon compleet vergeten. De paar keer dat hij terugkomt is het irrelevant of compleet onverklaarbaar.

Of, de hele serie lang zegt men dingen als &#8220;war is coming&#8221; of &#8220;they&#8217;re coming&#8221; of ander onheilspellende onzin. Uiteindelijk komt er geen oorlog of groot conflict en hebben we geen idee wat ze bedoelden. (Als er al iets gebeurt hebben de hoofdpersonages dat helemaal zelf veroorzaakt.) Uiteindelijk hebben we _Charles Widmore_ als een soort slechterik, maar zijn motivatie is onduidelijk en zijn acties extreem onlogisch. (&#8220;Dit eiland is van mij! Ik stuur mannen om het te vernietigen en iedereen te vermoorden die er leeft!&#8221; &#8211; 1 seizoen later &#8211; &#8220;Het eiland is verplaatst en onmogelijk om te vinden&#8221; &#8211; 1 seizoen later &#8211; &#8220;TADA! Ik ben Charles Widmore, en ik heb op magische wijze het eiland teruggevonden, precies toen het plot mij nodig had.&#8221;)

Ik blijf het zeggen: meer samenhang en meer worldbuilding, had voor een algemene spanningsboog gezorgd en daardoor ook een beter plot. Als de schrijvers van tevoren de serie goed hadden uitgedacht, hadden ze elke spanningsboog die ze begonnen ook volwaardig afgerond.

Nu blijft het een serie met twee gezichten: zeer veelbelovend idee met geweldige personages, maar ook een rommeltje dat op sommige momenten leeg en teleurstellend aanvoelt.

## Waarom de schrijvers écht geen idee hadden

De schrijvers hebben constant gezegd (in interviews en dergelijke): &#8220;we hebben een plan&#8221;, &#8220;we weten wat we doen&#8221;, en &#8220;het is allemaal onderdeel van een groot masterplan&#8221;

Ook verscheen bij elke reclame voor de serie de zin &#8220;everything happens for a reason&#8221;, &#8220;all your questions will be answered&#8221; of &#8220;all mysteries will be solved!&#8221;

Nou, hierboven heb ik al een paar grote verhaallijnen genoemd die geen reden hadden en geen einde hadden. Dit zijn niet zomaar kleine dingen: er zijn _uren_ van schermtijd besteed aan elk van deze verhaallijnen. Door deze aandacht leken ze essentieel en de investering waard, maar uiteindelijk stopten de verhaallijnen _omdat de schrijvers geen plan hadden_.

Zelfs de meest hardcore Lost fans moeten toegeven dat er nog honderden onopgeloste of onduidelijke mysteries zijn in de serie. En dat is bijzonder, aangezien een mysterie voor hen al is &#8220;opgelost&#8221; met verklaringen als &#8220;gewoon omdat Jacob dat heeft gedaan&#8221; of &#8220;je weet wel, _electromagnetism_!&#8221;

Hoe verdedigen de schrijvers dat? &#8220;Je moet niet alle antwoorden verwachten. Kunst is gemaakt om vragen te stellen, om je aan het denken te zetten. Je moet zelf op zoek gaan naar de antwoorden en dan zul je ze vinden in de kleinste dingen van deze serie.&#8221;

Daar ben ik het helemaal mee eens. Er zijn alleen twee problemen:

  * Als je veel dingen vaag en onopgelost laat, moet je niet constant beloven dat alles beantwoord gaat worden en dat je een masterplan hebt.
  * Duidelijkheid gaat voor alles.

Het is heel makkelijk om kijkers zichzelf vragen te laten stellen. Je kunt iets in je serie stoppen wat onlogisch of onmogelijk is, je kunt iets beginnen maar nooit afmaken, je kunt iets laten zien maar nooit uitleggen, je kunt onduidelijke beelden of dialoog laten zien.

Maar dat is verkeerd. Het creëert mysterie slechts door de afwezigheid van een goed en duidelijk verhaal. Doordat de schrijver zelf geen antwoorden heeft of niet duidelijk is.

In plaats daarvan moet je een _duidelijk_ verhaal vertellen. Eentje die logisch is, waarin de personages en het plot klopt, waarin wat je ziet of hoort duidelijk en begrijpelijk is. Als je dat hebt gedaan, is er nog steeds zeeën van ruimte voor interpretatie, extra mysteries, en de kijker zichzelf vragen laten stellen. Maar dan op de goede manier.

Sterker nog, de schrijvers weten dat. Seizoen 1 en 2 van de serie gaan grotendeels over de discussie tussen Jack en John Locke. Jack is een man van wetenschap, feiten, praktisch zijn, zorgen voor de groep. Locke is een man van geloof, van intuïtie, van doen wat zijn eigen gevoel ingeeft.

Hun discussie is helemaal duidelijk en logisch. Je weet waar de karakters voor staan, je snapt wat ze zeggen en doen, er is niks vaags of onduidelijks. Tegelijkertijd begin je jezelf vragen te stellen en meer antwoorden te zoeken. Met wie ben ik het eens? Wat zou ik hebben gedaan? Hoe gaat dit aflopen? Waarom zijn deze mensen zoals ze zijn?

<p style="padding-left: 30px;">
  De verhaallijn met <em>The Hatch</em> is bizar &#8211; mensen moeten elke 108 minuten op een knopje drukken om de wereld te redden &#8211; maar tegelijkertijd misschien wel de sterkste in de show. Het zorgt namelijk voor dit zeer interessante conflict, wat de serie op thematisch en emotioneel vlak enorm helpt om boven zichzelf uit te stijgen.
</p>

Dat is hoe een verhaal vragen moet stellen en de kijker in de spiegel moet laten kijken. Niet via vaagheid en onduidelijkheid.

De schrijvers van deze serie weten dat het anders kan, maar doen het alsnog verkeerd. De reden is simpel: ze wisten niet waar het verhaal heen ging. Ze introduceerden gekke en onduidelijke dingen met de gedachte: &#8220;oeh, lekker mysterieus, lekker interessant &#8211; dat lossen we later wel op!&#8221;

Het bewijs hiervoor vind je overal.

_Benjamin Linus_, één van de belangrijkste karakters in de serie, was oorspronkelijk slechts gecontracteerd voor 3 afleveringen. Hij moest zijn stukje doen maar was verder niet belangrijk. Toen ze erachter kwamen dat hij een verdomd goede acteur was, hebben ze hem maar de belangrijkste man van &#8220;the Others&#8221; gemaakt.

In seizoen 5 gaan ze tijdreizen. Tijdens seizoen 1 en 2 hebben de schrijvers heel vaak gezegd dat ze _niet gingen tijdreizen_ en dat alles _een rationele, wetenschappelijke verklaring had_. Nog erger: er gebeuren dingen in seizoen 1 t/m 4 die niet kloppen met het hele tijdreisverhaal. Waarom? Omdat ze toentertijd nog niet wisten dat ze gingen tijdreizen. (Het wordt nog erger als in seizoen 6 werkelijk alles wordt verklaard met magie en fantasy elementen. Dat was _precies_ hetgeen beloofden nooit te doen.)

<p style="padding-left: 30px;">
  Nog erger: het hele tijdreisplot is vergelijkbaar met zeggen dat &#8220;het allemaal een droom was&#8221;. Als de karakters slagen, en de tijdlijn weten te veranderen, zijn al die gebeurtenissen uit seizoen 1 t/m 4 in één klap <em>uitgewist</em>. Het is dus allemaal niet echt geweest en niet gebeurt. Ze hadden dan net zo goed na seizoen 4 kunnen eindigen met &#8220;het was allemaal een droom in het hoofd van Jack&#8221; of &#8220;ze waren allemaal dood, al die tijd&#8221;. Daardoor hoop je eigenlijk in seizoen 5 dat de personages <em>niet slagen</em> en dat hun hele plan <em>mislukt</em>, wat helemaal raar is.
</p>

<p style="padding-left: 30px;">
  Laten we nog een stapje verder doen. In seizoen 6 krijgen we de &#8220;flash sideways&#8221;, waarvan uiteindelijk blijkt dat deze gebeurtenissen plaatsvonden in een soort &#8220;purgatory&#8221; (een plek tussen hemel en aarde). Alles wat je zag, was dus niet echt gebeurt, terwijl je het hele seizoen gelooft dat het wél zo is. Wederom heb je een heel seizoen tijd in iets geïnvesteerd wat uiteindelijk niet echt was (en ook geen invloed had op de andere verhaallijn).
</p>

Uiteindelijk verklaren ze alles met &#8220;_Jacob_ is de beschermer van het eiland en heeft alles in de serie in gang gezet&#8221;. Dat had best kunnen werken &#8230; ware het niet dat Jacob een onlogische klootzak is :p Hij heeft verschrikkelijke dingen laten gebeuren die hij had kunnen voorkomen. Hij heeft onlogische dingen gedaan of is onnodig vaag geweest, wat ook weer vervelende gevolgen had. Hij kan toveren! Hij heeft krachten! Hij kent het eiland als geen ander! Maar nee, hij was 5 seizoenen lang nergens te bekennen. Als ze vanaf het begin wisten dat het hier ging eindigen, had het verhaal er echt heel anders uitgezien.

Om eerlijk te zijn: ik heb door mijn onderzoek een gigantische hekel gekregen aan de schrijvers :p Al die jaren lang hebben ze iedereen glashard voorgelogen. Als iemand een vraag stelde, was hun antwoord altijd &#8220;dat zal beantwoord worden&#8221;, of &#8220;dat moet je maar zien&#8221;, of &#8220;sommige dingen kun je beter open laten&#8221;. Uiteindelijk bleek dat ze er niks mee deden en geen plan hadden. Het wordt soms zelfs nog erger. Bij sommige fouten hebben ze een heel verhaal _verzonnen_ over waarom hun _acteurs_ de fout hadden gecreeërd.

(Bijvoorbeeld, de leeftijd en herkomst van Charlotte is inconsistent. Hun verklaring? Charlotte eiste dat ze een jongere leeftijd kreeg, want ze wilde geen iets oudere vrouw spelen! Daar bleek niks van waar. Hun reactie? Oh sorry, dit hele verhaal was verzonnen. Nee, onze &#8220;continuïteit expert&#8221; heeft de fout gemaakt!)

Zoek interviews, lees artikelen, en je zult zien dat de schrijvers geen idee hadden en alles ter plekke bedachten. Ik vind het zelfs ongelofelijk respectloos om zo met een serie en haar fans om te gaan. Fans hebben véél meer tijd gestoken in het eiland en de bijbehorende wereld/mythologie dan de schrijvers zelf.

## The Bigger Picture

Als je een serie kijkt, dan geef je jezelf over aan een &#8220;idee&#8221;. Als kijker wil je meegenomen worden in een bepaald wereld en samen een avontuur beleven. De serie is de reis, het algehele idee (en het einde) de bestemming. Mensen noemen dit ook wel de _rode draad_ of het _moraal van het verhaal_. De ene serie gaat over &#8220;opgroeien&#8221;, de ander over &#8220;oorlog is verschrikkelijk&#8221;, en weer een ander over &#8220;liefde&#8221;.

Als ik zelf iets schrijf, heb ik ook altijd zo&#8217;n rode draad. Ik heb een _reden_ dat ik iets wil schrijven. Er is een boodschap, een gevoel, een thema dat ik wil bespreken en behandelen door middel van een spannend en interessant verhaal. Want dat is waarom we verhalen vertellen. Leuke personages en interessante werelden vertellen ons uiteindelijk iets over onszelf, over het leven, over liefde en vriendschap, etc.

Het is veel leuker om via een magische wereld te leren over vriendschap, dan als je ouders tegen je zeggen &#8220;vriendschap is belangrijk &#8211; doe er wat mee&#8221;

Ik haal mijn schouders op als een vriend tegen mij zegt: &#8220;Tiamo, zoek nou eens een vriendin!&#8221; Maar als ik een goed verhaal over liefde zie, of over een gezin opbouwen, dan kan dat behoorlijk inspelen op mijn gevoelens en gedachten.

De vraag is dan ook: _wat is het moraal van dit verhaal?_ Wat is de rode draad van LOST, het idee erachter?

Na veel onderzoek (en denkwerk) heb ik enkele kandidaten. Deze zijn gerangschikt op volgorde van hoe sterk/waarschijnlijk ik hen acht:

  * &#8220;Good&#8221; versus &#8220;Evil&#8221; (of iets met hemel/hel)
  * &#8220;Man of science&#8221; versus &#8220;Man of faith&#8221;
  * &#8220;Lost&#8221; in de figuurlijke zin

Hieronder ga ik veel kritiek leveren, dus ik wil van tevoren even zeggen dat ik het knap en prijzenswaardig vind dat de show zo groots en ambitieus probeerde te zijn. Deze show is de reden dat we nu meer gewaagde TV series hebben, waarin wordt gespeeld met tijd, waarin steeds meer mogelijk is, waarin men een grootse rode draad probeert toe te voegen.

(Bijvoorbeeld, _The Good Place_ is een zeer recente sitcom die tegelijkertijd vragen over goed/kwaad behandelt. De hoofdpersoon wordt wakker op een plek en krijgt te horen dat ze in de hemel is (&#8220;the good place&#8221;), maar &#8230; ze is allesbehalve een goed persoon geweest in haar leven. De schrijver hiervan heeft letterlijk de schrijvers van LOST benaderd over hoe je zoiets ambitieus moet aanpakken.)

(Dezelfde schrijver heeft na LOST een tweede serie geschreven: The Leftovers. Ook dit was ambitieus, groots, complex, en naar het schijnt had hij geleerd van zijn fouten en wist het nu wél goed uit te werken.)

Als je LOST vergelijkt met andere series uit zijn tijd, zie je meteen dat de kwaliteit van het beeld en de effecten vele malen hoger ligt dan voorheen. De serie krijgt van mij heel veel punten voor deze gewaagde aanpak en de grote ambitie.

Met dat uit de weg, kan ik uitleggen waarom ze er niet helemaal in zijn geslaagd :p

### Goed versus kwaad

Gedurende de serie wordt vaak gezegd &#8220;we&#8217;re the good guys&#8221;. Er wordt gehint naar een strijd tussen goed en kwaad. Er is iets kwaads op het eiland (het monster, een andere groepering, een mystieke kracht, zoiets) en Jacob (en the Others) helpen om dat tegen te houden.

Ook wordt dit andersom geredeneerd: er zijn kwade krachten _buiten het eiland_, en men moet voorkomen dat ze het eiland vinden of er de controle over krijgen.

Pas in seizoen 6 krijgen we het hele verhaal van Jacob, waarbij hij zegt dat hij probeert te voorkomen dat &#8220;puur kwaad&#8221; het eiland weet te verlaten en de hele wereld &#8220;slecht&#8221; maakt. Mijn gedachten dreven meteen naar &#8220;Jacob = God&#8221; en &#8220;zijn broer = Duivel&#8221;. Dit had ik nog best een leuke verklaring gevonden: het eiland is waar God en de Duivel wonen en constant in tweestrijd zijn. De Duivel wil het eiland verlaten en de wereld slecht maken, God houdt hem tegen.

Je kunt deze vergelijking nog veel verder trekken. Misschien is het eiland een tussenstation, tussen het echte leven en de hemel. Men moet zichzelf &#8220;bewijzen&#8221;. Hun ziel wordt gewogen. Zowel de Duivel als God probeert aan ze te trekken, en waar ze naartoe gaan hangt ervan af welke kant ze kiezen.

Jammer genoeg is dit ook de meest voor de hand liggende verklaring. De schrijvers voelden zich verplicht om eromheen te werken. Daardoor komt de symboliek van &#8220;goed tegen kwaad&#8221; _totaal_ niet uit de verf. Uiteindelijk zijn het twee broers die ruzie maken en vaag zijn, en alle andere personages worden er onvrijwillig in meegenomen. Sommige personages hebben echt verschrikkelijke dingen gedaan &#8211; ze komen ermee weg. Andere personages zijn heel goed &#8211; ze gaan dood. Er worden geen levensvragen gesteld, geen filosofische kwesties opgeworpen, en daarom vind ik dit geen sterk moraal van het verhaal.

Na het kijken van de serie is mijn enige conclusie: Jacob (het God-karakter) is een domme en wrede idioot, maar zijn broer mocht van mij het eiland eigenlijk wel verlaten. Sympathieke gozer. Maar ik heb geen discussie over goed en kwaad gezien.

### Man of science, man of faith

Als ik een &#8220;goederik&#8221; en &#8220;slechterik&#8221; moet aanwijzen gedurende de hele serie, dan zouden het _Jack_ en _John Locke_ zijn. Ze zijn constant in discussie met elkaar, want eerstgenoemde is een dokter en gaat niet af op blind geloof, terwijl de ander juist vind dat men moet geloven en vertrouwen.

Deze vraag wordt constant opgeworpen in de serie. Het eiland doet rare dingen, onbetrouwbare mensen beloven dingen, moeten we dat geloven? Of puur afgaan op logica? Moeten we zelf de controle houden en zelfstandig zijn, of geloven in andere mensen en hen ook verantwoordelijkheden geven? Moeten we eindeloos antwoorden zoeken in ons leven, of simpelweg geloven dat het goed is zo? Moeten we alles proberen te &#8220;fiksen&#8221;, of accepteren dat er een reden is? Wat is belangrijker in je leven?

Gedurende de serie verandert Jack langzaam naar een _man of faith_. Hij gelooft in het eiland, hij gelooft in &#8220;destiny&#8221; en dat het zijn &#8220;purpose&#8221; is om naar het eiland te gaan en daar iets belangrijks te doen. Daarom wil hij ook terug naar het eiland in latere seizoenen.

Daarnaast is John Locke een van de sterkste en meest tragische karakters die ik ooit heb gezien. Het briefje dat hij achterlaat voor Jack waarin hij zegt &#8220;I wish you&#8217;d believed me&#8221; is hartverscheurend, evenals zijn laatste gedachten voordat hij sterft &#8211; &#8220;I don&#8217;t understand&#8221;. Hij was een man of faith, maar het heeft hem ook niet alles gebracht wat hij wilde.

Deze parallelen en vraagstukken zijn heel goed &#8230; maar de schrijvers gooien het weer uit het raam in de latere seizoenen. John Locke sterft en ze besluiten om &#8220;het monster&#8221; (of &#8220;het kwaad&#8221;) zijn lichaam in te laten nemen. Het gevolg is dat alles wat het personage van Locke goed en interessant maakte verdwijnt, maar hij wel nog steeds in de serie zit om dit zorgvuldig opgebouwde thema kapot te maken.

Het gekste is dat, voor een show die &#8220;vragen wil stellen&#8221; en alles &#8220;open wil laten&#8221;, het deze vraag daadwerkelijk beantwoord. Jack heeft faith, daardoor redt hij uiteindelijk het eiland. Hij leert om de controle los te laten en geen leider te willen zijn &#8211; hij heeft faith in Hurley en maakt hem de nieuwe beschermengel van het eiland.

Uiteindelijk eindigt de hele serie in een kerk &#8211; _faith_ is overduidelijk het juiste antwoord.

(Dat doet me denken aan een leuke vergelijking van iemand anders. Wat als de serie had besloten dat &#8220;wetenschap/logica&#8221; het juiste antwoord was? Was de serie dan geëindigd in een laboratorium met alle personages die formules opschrijven en logische uitspraken doen? :p)

Dit thema had ik zeer sterk gevonden als het van begin tot eind helemaal was uitgewerkt. Maar het mocht niet zo zijn.

### LOST

Het laatste seizoen van de serie spenderen we alle &#8220;flashbacks&#8221; (of &#8220;flash sideways&#8221;, zoals Lost fans het noemen) in een alternatieve realiteit. Het vliegtuig is niet gecrasht, maar is netjes geland en alle karakters hebben een ander leven.

Uiteindelijk blijkt dit &#8220;purgatory&#8221; te zijn: de karakters zijn in een gebied tussen leven en dood. Gedurende het seizoen worden alle oorspronkelijke hoofdpersonages weer verzameld, en stuk voor stuk herinneren ze hun tijd op het eiland. In veel gevallen betekent dit een reünie tussen geliefden waarvan één (of allebei) zijn gestorven. Ze waren elkaar kwijt, maar als ze elkaar spreken/aanraken, herinneren ze hoe hun tijd samen was en zijn weer helemaal gelukkig.

De serie eindigt dan ook met Jack die sterft (op het eiland) en naar diezelfde plek gaat. In de kerk ontmoet hij iedereen waarmee hij al die tijd op het eiland heeft doorgebracht. Er wordt gelachen, gezoend, geknuffeld, en nog meer zoete dingen. Uiteindelijk wordt er gezegd dat ze nu klaar zijn om &#8220;door te gaan&#8221; (&#8220;to move on&#8221;). Waarnaartoe is niet helemaal duidelijk, maar we gaan ervan uit dat ze gezamenlijk naar de hemel gaan.

Ik ben in tweestrijd over dit einde.

Enerzijds is het goed en emotioneel. Na die zes seizoenen van onduidelijkheid en onopgeloste mysteries was dit misschien wel het best denkbare einde. De gebeurtenissen op het eiland zijn echt gebeurt. Sommige karakters hebben het overleefd, andere niet, maar uiteindelijk komen ze allemaal weer samen. Die tijd op het eiland was achteraf de beste en meest intense tijd van hun leven, en ze kunnen dus pas verdergaan (naar de hemel?) als ze elkaar weer hebben ontmoet.

Dit hangt mooi samen met het woord &#8220;LOST&#8221;. Als je dit figuurlijk opvat, zijn die mensen (of hun zielen) _verdwaald_ en zonder richting. Het eiland gaf hen die richting en die plek. Daar gaat de serie over, en als ze allemaal hun tijd op het eiland hebben gehad en zijn overleden, komen ze weer samen. Ze zijn niet meer verdwaald, maar gaan als groep verder naar het volgende station (wat dat dan ook moge zijn).

Anderzijds vind ik de finale heel erg slecht. Een finale moet passen bij de show. Het moet die rode draad afsluiten (en eventueel extra toelichten/duidelijk maken). Ik was vooral in verwarring na het einde en voelde niet dat het passend was voor de hele show.

Waarom? Omdat het thema van &#8220;verdwaald&#8221; niet consistent was toegepast. De personages hebben fouten gemaakt in hun leven, en sommige waren op een slechte plek toen ze crashten op het eiland, maar slechts enkele van hen zou ik bestempelen als &#8220;verdwaald&#8221;. En als ze al verdwaald waren, dan heeft het eiland ze niet perse geholpen om richting te vinden. Het nam vaak juist de grond onder iemands voeten vandaan.

Ik heb het gevoel dat dit de rode draad van de show was. Het gaat over de personages, zoals de schrijvers en alle fans ook zeggen, en uiteindelijk wilde de show laten zien hoe &#8220;verdwaalde mensen&#8221; uiteindelijk door het eiland hun &#8220;plek vonden in het leven&#8221;.

Als ze dit helemaal hadden uitgewerkt, had ik dat enorm sterk gevonden. Elk personage in de serie had verdwaald moeten zijn om een andere reden; gedurende de show vind iedereen stuk voor stuk hun plek.

De een is nog jong en weet niet wat ze moet met haar leven. De ander denkt dat hij een slechte vader is en weet niet of hij wel bij zijn kinderen moet blijven. Weer een ander is oud en weet niet of het nog waard is om verder te leven (met al zijn pijn/gebreken). Ze zijn verdwaald, op een punt van stilstand en onzekerheid in hun leven. Als ze hun plek hebben gevonden, sterven ze, of gaan van het eiland, of iets dergelijks.

Dat kan ik niet zeggen van de personages die we uiteindelijk kregen. Ja, Jack had een moeilijke tijd na de scheiding met zijn vrouw, maar hij was een succesvolle dokter, met goede gezondheid en een goede baan/salaris, en geen enkele onzekerheid of onduidelijkheid in zijn leven. Hurley had het idee dat zijn leven vervloekt was en dat hem altijd slechte dingen overkwamen, maar was hij verdwaald? Nee, er gebeurden oprecht rare dingen in zijn leven waar hij geen controle over had. (En die nooit verklaard worden, maar goed.)

Maar ja. De schrijvers hadden geen plan, dus dit hebben ze ook niet gedaan. Ze hadden heel goed uitgewerkte personages en urenlange backstories, maar konden geen duidelijke rode draad door hun levens weven. Het feit dat er moeilijk een &#8220;idee&#8221; of &#8220;moraal&#8221; achter deze serie te vinden is, maakt hem voor mij (achteraf gezien) een heel stuk minder. De reis was best spannend en interessant, maar de bestemming maakt me zelfs een beetje boos :p

## Hoe ik het graag had gezien

Ik schrijf veel verhalen. Daarom ben ik zo enorm geïnteresseerd in deze serie en heb ik tijdens het kijken continu nagedacht over oplossingen voor problemen die ik zag. Hieronder zal ik mijn gedachten uitleggen en hopelijk mijn kritiek wat kracht bijzetten.

### Probleempunten vinden

Dit zijn een aantal concrete, tastbare problemen met de huidige serie:

  * Het algehele idee of doel is niet duidelijk. 
      * Er zijn wel degelijk een aantal goede ideeën of doelen in de serie, maar ik ga ze proberen aan elkaar te smeden tot één geheel.
  * Er is weinig samenhang. 
      * De samenhang die er wél is, is goed en kan worden uitgebreid. Bijvoorbeeld, het einde van de serie is een parallel met het begin van de serie. De serie begint met Jack die op zijn rug ligt, tussen het bamboe, zijn ogen opent, en een hond voorbij ziet komen. De serie eindigt met Jack op dezelfde plek, op z&#8217;n rug, met de hond naast hem, terwijl hij zijn ogen sluit. Mensen _houden ervan_ om patronen en parallellen te zien in hun verhalen.
  * De &#8220;show versus tell&#8221; verhouding is niet helemaal lekker. 
      * Heel vaak wordt iets letterlijk gezegd in de serie. &#8220;Wat is dit?&#8221; \*iemand anders geeft een direct antwoord\* &#8220;Wat gebeurt er als ik dit doe?&#8221; \*iemand anders legt precies uit wat er gebeurt\*
      * In plaats daarvan wil je laten _zien_ wat er gebeurt. Je wilt het uitwerken. Je wilt de kijker het echt laten voelen/meemaken.
      * Bijvoorbeeld: in het laatste seizoen zegt men de hele tijd dat &#8220;als het monster het eiland verlaat &#8230; dan is dat het einde van de wereld! Apocalyps! Verschrikkelijk!&#8221; Maar je krijgt nergens het gevoel dat het zo is, omdat die &#8220;man in black&#8221; nog redelijk sympathiek en rustig overkomt. Ze hadden juist moeten laten zien wat er gebeurt als het monster loskomt. Ze hadden een voorproefje moeten geven.
  * De serie wordt veel te snel &#8220;normaal&#8221; en &#8220;veilig&#8221;. 
      * Al vrij snel hoeft men geen zorgen meer te maken over eten, drinken, een veilige slaapplek. Men vindt de spullen en gebouwen van de _Dharma Initiative_ en leeft eigenlijk op het eiland alsof ze in een normale stad leven. Men vindt vrij snel een grote verzameling pistolen, wat voor mij de spanning en beleving grotendeels weghaalt. (Ineens is iedereen even capabel in aanvallen en verdedigen en ineens kan je uit het niets worden neergeschoten.)
  * &#8220;the Others&#8221; zijn een goed idee en waren heel veelbelovend &#8230; maar vielen uiteindelijk zwaar tegen.

Daarnaast zijn er natuurlijk de problemen die ik hiervoor uitvoerig heb behandeld: personages krijgen richting het einde geen ontwikkeling meer, teveel irrelevante of onopgeloste mysteries, etc.

Hieronder geef ik een samenvatting van mijn idee, waarbij ik probeer zoveel mogelijk delen van de echte serie erin te laten zitten.

### Mijn idee

#### De rode draad

Het grote idee van de show is inderdaad gebaseerd op het woord &#8220;LOST&#8221;. Alle karakters die we volgen waren &#8220;verdwaald&#8221; in hun leven, op het moment dat ze in het vliegtuig stapten. Ze dachten dat ze er alleen voor stonden, dat wat ze deden niks uitmaakte, en ze wisten niet hoe hun leven verder moest.

Gedurende de serie komen we erachter dat de personages met elkaar verbonden zijn. Wat ze hebben gedaan maakt _wel_ uit. Ze staan er niet alleen voor. Misschien heeft personage A wel (onbewust) gezorgd dat personage B de liefde van zijn leven vond, en personage B was de persoon die het kind van personage C heeft gered, etc. Alles wat ze deden had invloed op het leven van een ander personage.

Stuk voor stuk leren de personages hun plek te vinden. Ze komen erachter dat ze niet alleen zijn, maar verbonden, en ze vinden hun plek in de wereld. Ze zijn niet meer verdwaald. Elke keer als dat gebeurt, verdwijnt die persoon uit de serie. (Dit is een &#8220;geheim&#8221; wat de kijkers zelf moeten ontrafelen.) De persoon kan sterven, van het eiland gaan, in z&#8217;n eentje de jungle in, whatever.

De serie eindigt met het moment dat de allerlaatste personages &#8220;hun plek vinden&#8221;. Als dat is gebeurt, kunnen we zelfs overschakelen naar het officiële einde van LOST. Deze personages hebben allemaal samen hun plek gevonden op het eiland, en na hun dood wachten ze op elkaar, om gezamenlijk hun plek in de hemel op te zoeken.

#### Structuur

Net als in de echte serie, focust elke aflevering op één personage. We zien flashbacks met diens backstory, terwijl die persoon ook belangrijke dingen doet op het eiland.

Na drie seizoenen veranderen de flashbacks in flashforwards. (Ik ga er even vanuit dat ook mijn zelfbedachte serie weer 6 seizoenen telt.) We weten hoe alle personages in het verleden verbonden zijn geraakt, vanaf nu gaan we van achter naar voor werken. De flashforwards beginnen in de verre toekomst, maar komen steeds dichterbij de huidige tijd.

Verder wijken we nooit van deze structuur af. Geen tijdreizen, geen afleveringen die flashbacks van vier verschillende personages hebben, etc. En die &#8220;flash sideways&#8221; gaan we zeker niet doen. Alles wat je ziet in deze serie is echt gebeurd en er wordt niet vals gespeeld met tijd/realiteit/etc.

#### Doel & Antagonist

Vanaf het allereerste moment zijn de personages bezig met _overleven_ op het eiland. De serie moet echt focussen op dat overlevingsaspect.

Het liefst is het realistisch en leerzaam. Kijkers leren gaandeweg hoe je moet handelen in zo&#8217;n situatie en hoe je kunt overleven zonder moderne apparatuur. De personages moeten voedsel vinden, water vinden, slaapplekken maken. Gaandeweg breidt hun kolonie steeds verder uit: ze gaan plantages bouwen, hun eigen wapens of verdediging bouwen, hun eigen medicijnen brouwen, etc.

Hier ontstaat de eerste breuk tussen de personages. Sommige willen niet meer van het eiland &#8211; ze hebben toch niks om naartoe terug te gaan. Sommige willen de leiding nemen, anderen willen geen moeite doen, etc. Ze moeten echt leren samenwerken en leren om te overleven; door die spanning/discussies/levensvragen leer je mensen heel goed kennen :p

Dit is ook het moment waarop het eerste subthema kan worden opgestart: &#8220;man of science, man of faith&#8221;. De groep splitst ongeveer in tweeën, gebaseerd op die filosofie.

Gaandeweg ontdekken ze dat er dingen met het eiland aan de hand zijn. Ze kunnen geen contact krijgen met de buitenwereld en worden niet gered. Ze horen vreemde geluiden. Er lopen beesten rond op het eiland die je niet zou verwachten. Ze vinden gebouwen/plekken/voorwerpen die suggereren dat er andere mensen rondlopen.

Gedurende de serie ontdekt men langzaam wat er aan de hand is op het eiland: er is een constante oorlog tussen drie verschillende groeperingen!

  * De eerste groep hoort bij &#8220;het monster&#8221;. Ze helpen het monster, proberen deze te bevrijden, proberen het eiland te controleren, etc.
  * De tweede groep probeert het monster juist tegen te houden.
  * De derde groep zit er tussenin (het zijn een beetje de &#8220;vagabonds&#8221;). Ze willen gewoon een vredig leven leiden en geen kant kiezen. Misschien willen ze wel van het eiland af.

Hier begint het tweede subthema: &#8220;goed versus kwaad&#8221;.

Alle mysteries die gebeuren hebben een simpele verklaring via deze groepen. Waarom zijn deze personen naar het eiland gekomen? De groep van &#8220;het monster&#8221; heeft hen gelokt. De personages zijn verdwaald en daardoor makkelijk te beïnvloeden door &#8220;de slechteriken&#8221;. Diezelfde groep zorgt er ook voor dat ze niet van het eiland kunnen en niet worden gered.

Gedurende de serie ontdekken de personages steeds meer over de historie van het eiland en de constante oorlog die er woedt. Ze ontdekken hoe het monster tot stand kwam en waarom het misschien wel &#8220;goed&#8221; is om het monster los te laten. Hoe meer ze ontdekken, hoe meer de tweedeling wordt verergerd: de ene groep heeft _faith_, de ander _science_. De eerste groep gelooft in de mythologie en de magische krachten van het eiland, de tweede groep ziet alleen een angstaanjagend monster en doet alles om deze te doden. Kunnen ze de mensen wel vertrouwen? Zijn ze wie ze zeggen dat ze zijn?

(Dit doet me denken aan die scenes in seizoen 2 waarbij ze Ben Linus gevangen hebben. Hij roept en schreeuwt dat hij onschuldig is, de personages weten niet of ze hem moeten vertrouwen. Misschien wel een van mijn meest favoriete delen van de serie, omdat je als kijker helemaal meeleeft in de onzekerheid en het soort &#8220;detective&#8221; verhaal.)

_Belangrijke opmerking:_ ik heb natuurlijk geen tijd genomen om dit helemaal uit te denken. Er moeten in ieder geval interessante locaties zijn op het eiland, die onze hoofdpersonages gaandeweg ontdekken. Misschien is er wel een grote muur waar ze eerst niet langs kunnen. Ook moeten er interessante vragen over goed en kwaad worden gesteld, terwijl het een grijs gebied blijft. Het ene personage kiest het kant van het monster, het andere personage kiest het kant van de eilandbeschermers. Wie heeft gelijk? Gaan ze elkaar nog vinden? Of gaan deze vrienden, aan het einde van de serie, tegen over elkaar staan en elkaar vermoorden?

Het _doel_ van de hele serie is om dit conflict op het eiland op te lossen. De antagonist (het obstakel) is derhalve het conflict en de groepen die het in stand houden.

Elke groep (en elk personage) heeft ook een duidelijk individueel _doel_. Ten eerste zijn ze dus &#8220;verdwaald&#8221; en zoeken hun plek in het leven. Daarnaast wil het ene personage op het eiland blijven wonen, terwijl het andere personage gered wil worden.

De hele serie lang moet men blijven ontdekken, blijven vechten om te overleven, nieuwe manieren vinden om van het eiland te ontsnappen, etc. Op geen enkel moment wil ik dat ze een paar huisjes vinden en een oneindige voorraad pistolen, voedsel, slaapplekken, etc. hebben.

#### Plot en Achtergrond

Het zou mij weken kosten om een samenvatting te bedenken (en schrijven) van het plot en de achterliggende mythologie voor de serie. Dat ga ik dus niet doen, sorry. Het stuk hierboven geeft een heel duidelijk idee van wat ik met de serie had gedaan. Het zorgt voor een _moraal van het verhaal_, het zorgt voor _interessante personages met een interessante ontwikkeling_, het zorgt voor _spanning_ (want ze moeten overleven en groot kwaad voorkomen), en het zorgt voor een _mysterie dat daadwerkelijk een oplossing/reden heeft_.

Ik laat het aan jou om hier invulling aan te geven, als je wilt.

Mijn gedachten leunen initieel naar een &#8220;goddelijke verklaring&#8221;. Misschien was het monster vroeger wel een God. Maar, hij maakte één foutje, en meteen werd hij verbannen tot een leven als monster. Opgesloten op een eiland. Dan kun je interessante vragen stellen: wat was die fout? Kunnen we wel verwachten dat mensen/goden perfect zijn? Wat gebeurt er als je het monster loslaat of zijn oude vorm teruggeeft? Is het dan weer een genadevolle God, of is deze persoon over tijd verandert in een wraakzuchtige moordenaar? Waarom is hij opgesloten op dit eiland?

Ook kun je je afvragen wat de krachten waren van die God. Misschien waren dit wel hele goede dingen, zoals &#8220;mensen terughalen uit de dood&#8221; of iets vaags als &#8220;liefde brengen!&#8221;. (Je kunt het nog een kritiek op de maatschappij maken: &#8220;sinds dit monster is opgesloten, is er minder liefde/verbondenheid op de wereld&#8221;) Dat geeft personages een goede reden om het monster te helpen en terug te brengen. In de laatste seizoenen kan het monster dan eindelijk worden &#8220;losgelaten&#8221;, en dan zien we daadwerkelijk hoe erg het is.

Ik weet zeker dat je hier hele interessante dingen mee kunt als je er even over nadenkt.

Als je er geen fantasy (of science fiction) verhaal van wilt maken, dan hoeft dat ook niet. Het monster kan simpelweg een angstaanjagend dier zijn, of een mens die verschrikkelijke dingen heeft gedaan, of een metafoor. Er is geen monster &#8211; de personages die opgesloten zijn op het eiland _zijn de_ _monsters_. Hoe het vliegtuig op het eiland kwam (en andere toevalligheden) kan je ook wel op een rationele manier verklaren.

Eindeloze mogelijkheden! Allemaal beter dan wat de serie ons uiteindelijk voorschotelde!

## Conclusie

LOST doet een aantal dingen heel goed en een aantal dingen heel fout. Ik hoop dat dit artikel je veel heeft geleerd over verhalen schrijven en uitwerken. Met mijn praktijkvoorbeeld hoop ik te laten zien dat een betere, meer samenhangende serie echt niet zo&#8217;n moeilijke taak was. Anderzijds hoop ik dat je het tenminste leuk vond om te lezen en begrijpt waarom ik mijn twijfels heb over deze serie.

&nbsp;

 [1]: http://nietdathetuitmaakt.nl/rare-recensies/serierecensie-lost-2004-2010/