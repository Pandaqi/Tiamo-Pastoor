---
title: Piraat Raadselbaard
author: hetisdepanda
type: page
date: 2022-08-10T10:39:00+00:00

---
<div class="wp-block-image">
  <figure class="alignright size-full is-resized"><img decoding="async" loading="lazy" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2023/03/piraat_raadselbaard-header.webp" alt="" class="wp-image-15200" width="378" height="530" /></figure>
</div>

**Piraat Raadselbaard** is een interactief kinderboek. Het is een spannend piratenverhaal, waarin je Temata volgt die probeert een schat terug te stelen en haar ouders terug te vinden.

Maar tijdens het lezen krijg je hints over bijzondere locaties: een schat, de legendarische Piratenraad, en nog meer. Gebruik de kaart, en je gezonde verstand, om de juiste plekken sneller te vinden dan Temata!

Het is te lezen (en spelen) vanaf ongeveer acht jaar. Het boek heeft **A5 formaat**, met **250 pagina&#8217;s**, en kost **17,95 euro**.

Het is te koop in vrijwel alle (online) boekenwinkels. Of gebruik de knop hieronder:

<p class="buy-link">
  <a href="https://www.bruna.nl/boeken/piraat-raadselbaard-9789403674223">Piraat Raadselbaard (Bruna)</a>
</p>

<p class="buy-link">
  <a href="https://www.mijnbestseller.nl/books/307397">Piraat Raadselbaard (MijnBestseller)</a>
</p>

<p class="buy-link">
  <a href="https://www.bol.com/nl/nl/p/piraat-raadselbaard/9300000147575684/">Piraat Raadselbaard (Bol.com)</a>
</p>

**Onzeker of het iets is voor je kind?** De meeste winkels hebben de mogelijkheid om de eerste 10-20 pagina&#8217;s te bekijken.

**Wie is deze Tiamo en kan ik hem vertrouwen?** Ik heb vele <a href="https://nietdathetuitmaakt.nl/boeken/" data-type="page" data-id="9754">boeken</a> uitgegeven en houd natuurlijk dit blog bij. Ook doe ik veel ander werk (zoals vormgeving en spellen ontwikkelen) dat je altijd kunt vinden op mijn [portfolio][1].

**Wil je de kaarten los downloaden?** Ze zijn **[hier][2]** gratis te vinden. Deze kaarten zijn volledig in _kleur_! In het boek zijn de kaarten in grijstinten (om de prijs laag te houden).

## Interactief? {#interactief}

Dit boek is een roman. Het vertelt een verhaal van begin tot eind, met unieke personages, spannende scènes, magie en mysteries.

Maar daar _bovenop_ is het interactief. Aan het begin van het boek krijg je een grote kaart van de wereld, opgedeeld in gebieden. 

Gedurende het boek verschijnen hints die sommige gebieden laten afvallen. Sommige zijn makkelijk (&#8220;de schat ligt niet in een bosgebied&#8221;), andere zijn lastiger of moet je beter naar zoeken.

Als je goed oplet en goed nadenkt, kan je dus zelf de plek van de schat vinden terwijl je leest, voordat de hoofdpersoon erachter komt!

## Over dit boek {#over-dit-boek}

Dit boek is ontstaan door een bundel _bordspellen_ die ik zelf ontwikkelde (<a href="https://nietdathetuitmaakt.nl/gewoon-een-gedachte/pirate-riddlebeard/" data-type="post" data-id="13229">Pirate Riddlebeard</a>, <a href="https://nietdathetuitmaakt.nl/bijzondere-bordspellen/pirate-drawingbeard/" data-type="post" data-id="13552">Pirate Drawingbeard</a>). In die spellen is een schat verstopt op één vakje van de kaart. Iedereen krijgt andere _hints_ over waar de schat wel of niet kan zijn. De persoon die als eerste de hints van de rest kan raden, weet als eerste precies waar de schat is en wint!

Tijdens het maken dacht ik: zou het niet leuk zijn om dit element te verbinden aan een verhaal? Een avontuurlijk boek over piraten en schatzoeken waarbij je daadwerkelijk meespeelt en meedenkt? (Aan de hand van een kaart en hints.)

Voor ik het wist had ik al de eerste paar hoofdstukken, de eerste hints, een deel van de kaart.

Het feit dat elk hoofdstuk iets van een logische hint moest bevatten, hielp hierbij juist enorm. Het gaf richting en maakte het verhaal zelf _beter_. Je wilt constant blijven lezen, want om de paar pagina&#8217;s gebeurt weer iets belangrijks!

En zo ontstond dit bijzondere boek.

Wil je meer weten (met véél spoilers)? Lees het uitgebreide <a href="https://nietdathetuitmaakt.nl/boeken/piraat-raadselbaard/dagboek-piraat-raadselbaard/" data-type="page" data-id="13978">dagboek</a> over het schrijfproces.

Wil je meer weten over het tekenen van de wereldkaart? Lees mijn artikel die uitlegt [hoe ik de kaart ontwierp][3] (mijn eerste poging tot een wereldkaart bij een boek stoppen).

## Muziek {#muziek}

Mijn hoofd bedenkt constant muziek, zeker als ik schrijf of creatief bezig ben. Dus ook Piraat Raadselbaard heeft een eigen _theme song_ en melodieën die horen bij belangrijke onderdelen (zoals een personage of een plek). 

Ik zie niet helemaal hoe ik de muziek anders kan delen, dus ik heb het maar als conceptalbum op Spotify gezet: [Piraat Raadselbaard (op Spotify)][4]

<p class="remark">
  het staat ook op zo&#8217;n beetje alle andere muziekstreamingsdiensten. Zoek op &#8220;Piraat Raadselbaard: Soundtrack&#8221;.
</p>

## In het wild {#in-het-wild}

Hieronder staan plaatjes van een fysiek exemplaar (mijn eigen proefdruk). De pagina&#8217;s in het boek zijn compleet willekeurig uitgezocht. Als je de kaarten wilt zien, raad ik dus de link bovenaan de pagina aan waar je de kleurenexemplaren kan downloaden.

<div class="wp-block-jetpack-tiled-gallery aligncenter is-style-rectangular">
  <div class="tiled-gallery__gallery">
    <div class="tiled-gallery__row">
      <div class="tiled-gallery__col" style="flex-basis:34.72013%">
        <figure class="tiled-gallery__item"><img decoding="async" srcset="https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_back.webp?strip=info&#038;w=600&#038;ssl=1 600w,https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_back.webp?strip=info&#038;w=900&#038;ssl=1 900w,https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_back.webp?strip=info&#038;w=1139&#038;ssl=1 1139w" alt="" data-height="1518" data-id="14470" data-link="https://nietdathetuitmaakt.nl/boeken/piraat-raadselbaard/attachment/piraat_raadselbaard_back/" data-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_back.webp" data-width="1139" src="https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_back.webp?ssl=1" data-amp-layout="responsive" /></figure>
      </div>
      
      <div class="tiled-gallery__col" style="flex-basis:30.55305%">
        <figure class="tiled-gallery__item"><img decoding="async" srcset="https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_binnenkant_1.webp?strip=info&#038;w=600&#038;ssl=1 600w,https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_binnenkant_1.webp?strip=info&#038;w=900&#038;ssl=1 900w,https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_binnenkant_1.webp?strip=info&#038;w=1200&#038;ssl=1 1200w,https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_binnenkant_1.webp?strip=info&#038;w=1500&#038;ssl=1 1500w,https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_binnenkant_1.webp?strip=info&#038;w=1610&#038;ssl=1 1610w" alt="" data-height="1207" data-id="14471" data-link="https://nietdathetuitmaakt.nl/boeken/piraat-raadselbaard/attachment/piraat_raadselbaard_binnenkant_1/" data-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_binnenkant_1.webp" data-width="1610" src="https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_binnenkant_1.webp?ssl=1" data-amp-layout="responsive" /></figure><figure class="tiled-gallery__item"><img decoding="async" srcset="https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_binnenkant_2.webp?strip=info&#038;w=600&#038;ssl=1 600w,https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_binnenkant_2.webp?strip=info&#038;w=900&#038;ssl=1 900w,https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_binnenkant_2.webp?strip=info&#038;w=1200&#038;ssl=1 1200w,https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_binnenkant_2.webp?strip=info&#038;w=1500&#038;ssl=1 1500w,https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_binnenkant_2.webp?strip=info&#038;w=1577&#038;ssl=1 1577w" alt="" data-height="1183" data-id="14472" data-link="https://nietdathetuitmaakt.nl/boeken/piraat-raadselbaard/attachment/piraat_raadselbaard_binnenkant_2/" data-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_binnenkant_2.webp" data-width="1577" src="https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_binnenkant_2.webp?ssl=1" data-amp-layout="responsive" /></figure>
      </div>
      
      <div class="tiled-gallery__col" style="flex-basis:34.72682%">
        <figure class="tiled-gallery__item"><img decoding="async" srcset="https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_cover.webp?strip=info&#038;w=600&#038;ssl=1 600w,https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_cover.webp?strip=info&#038;w=900&#038;ssl=1 900w,https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_cover.webp?strip=info&#038;w=1185&#038;ssl=1 1185w" alt="" data-height="1579" data-id="14473" data-link="https://nietdathetuitmaakt.nl/boeken/piraat-raadselbaard/attachment/piraat_raadselbaard_cover/" data-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_cover.webp" data-width="1185" src="https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2022/09/piraat_raadselbaard_cover.webp?ssl=1" data-amp-layout="responsive" /></figure>
      </div>
    </div>
  </div>
</div>

 [1]: https://rodepanda.com
 [2]: https://drive.google.com/drive/folders/1Oj2Rf24PV0ZjEhm5d4SScvUt7JjUjKMA?usp=sharing
 [3]: https://nietdathetuitmaakt.nl/gewoon-een-gedachte/piraat-raadselbaard-mijn-eerste-poging-tot-fantasy-kaarten/
 [4]: https://open.spotify.com/album/3gi7DfgDJXM1E2cqZu2aal