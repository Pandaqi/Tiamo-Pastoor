---
title: Bird of Sand
author: hetisdepanda
type: page
date: 2023-04-01T09:29:00+00:00

---
**Bird of Sand** is the third book of the [Trilogy of Neverold][1]. An ambitious space mission ends with a man who has to survive, alone and broken, on a hostile sand planet. Al his efforts to build a rocket, crumble before his eyes. Until he meets a little girl, as lonely as he is, who changes everything.

Buy the book here: @TODO (Link)

## What&#8217;s the idea?

After finding the Space Diamond, humans left in search of other planets. But Fargi&#8217;s mission failed and stranded him on a sand planet, alone and without supplies. Each day he builds a bird on which to fly away—each day it crumbles back to dust. He gives up. Until something changes his life and might help him flee. The only thing standing in his way, is himself and his past.

## More information

Want to know more about me (the author)? Take a look at my [book page][2] (although many are in Dutch), or [my portfolio][3] (all projects, all English!). Or Google my name and see what happens.

Want to know more about the story? About how I wrote it, why I made certain decisions, etcetera? Read my **[Diary] Bird of Sand**. @TODO (Link)

 [1]: https://nietdathetuitmaakt.nl/boeken/trilogy-of-neverold/
 [2]: https://nietdathetuitmaakt.nl/boeken/
 [3]: https://rodepanda.com