---
title: De Kat van Sinterklaas
author: hetisdepanda
type: page
date: 2018-10-04T13:14:11+00:00

---
<div class="wp-block-image">
  <figure class="alignright size-large is-resized"><a href="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/kat-van-sint-1_result-scaled.webp"><img decoding="async" loading="lazy" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/kat-van-sint-1_result-scaled.webp" alt="" width="261" height="368" /></a></figure>
</div>

**De Kat van Sinterklaas** is een geïllustreerd keuzeverhaal, door mij uitgegeven in eigen beheer.

Het boek bestaat uit **46 full-color A4 pagina&#8217;s**, waaroverheen een **(rijmend) keuzeverhaal** is geschreven.

Het is leesbaar voor ieder kind met een basiskennis Nederlands; jongere kinderen zullen voorgelezen moeten worden (en vooral genieten van de plaatjes).

Koop hier het boek: 

<p class="buy-button">
  <a href="http://www.bravenewbooks.nl/books/144364"><strong>Kat van Sinterklaas (Brave New Books)</strong></a>
</p>

<p class="buy-button">
  <strong><a href="https://www.bol.com/nl/nl/p/de-kat-van-sinterklaas/9200000100616996/">Kat van Sinterklaas (Bol.com)</a></strong>
</p>

## Waar gaat het over? {#waar-gaat-het-over}

Sisi leeft vreedzaam in het bos, samen met haar vader, maar op een donkere nacht gebeurt het ondenkbare: rare geluiden vullen het bos en plotsklaps wordt haar vader weggetrokken! 

Volg haar reis door heel Europa, op zoek naar haar vader. Wat is er met hem gebeurd? Hoe komt Sisi weer bij hem? En wat heeft Sinterklaas hiermee te maken?

Ik heb dit boek oorspronkelijk getekend voor mijn zusje, voor Sinterklaas, maar vond het uiteindelijk zo goed dat ik het besloot uit te geven.

## Voorbeeldprenten {#voorbeeldprenten}

Hieronder laat ik zes willekeurig gekozen pagina&#8217;s zien uit het boek. (Online laat hij namelijk alleen de eerste pagina&#8217;s zien in het inkijkexemplaar, maar die bevatten vooral uitleg over hoe het keuzeverhaal werkt. Dus dat helpt niemand echt.)<figure class="is-layout-flex wp-block-gallery-1 wp-block-gallery has-nested-images columns-3 is-cropped"> <figure class="wp-block-image size-large">

[<img decoding="async" loading="lazy" width="2552" height="3580" data-id="7895"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/08/KatOfTheSint01-04_result.webp" alt="" class="wp-image-7895" />][1]</figure> <figure class="wp-block-image size-large">[<img decoding="async" loading="lazy" width="2552" height="3580" data-id="7900"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/08/KatOfTheSint01-06_result.webp" alt="" class="wp-image-7900" />][2]</figure> <figure class="wp-block-image size-large">[<img decoding="async" loading="lazy" width="2552" height="3580" data-id="7896"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/08/KatOfTheSint02-02_result.webp" alt="" class="wp-image-7896" />][3]</figure> <figure class="wp-block-image size-large">[<img decoding="async" loading="lazy" width="2552" height="3580" data-id="7897"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/08/KatOfTheSint05-03_result.webp" alt="" class="wp-image-7897" />][4]</figure> <figure class="wp-block-image size-large">[<img decoding="async" loading="lazy" width="2552" height="3580" data-id="7898"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/08/KatOfTheSint07-01_result.webp" alt="" class="wp-image-7898" />][5]</figure> <figure class="wp-block-image size-large">[<img decoding="async" loading="lazy" width="2552" height="3580" data-id="7899"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/08/KatOfTheSint09-02_result.webp" alt="" class="wp-image-7899" />][6]</figure> </figure> 

## Veelgestelde vragen {#veelgestelde-vragen}

**Wat is een&nbsp;_keuzeverhaal_?&nbsp;**Dat betekent dat de lezer aan het eind van elk hoofdstuk zelf mag kiezen hoe het verhaal verder gaat. (Als je optie A kiest, lees je verder vanaf een andere pagina dan als je optie B kiest.) Op die manier is het boek meerdere keren te lezen.

**Hoe heb je het zelf uitgegeven?&nbsp;**De &#8220;zelf-uitgever&#8221; die ik gebruik is Brave New Books. Mijn uitgave bij hen was een experiment, en ik moet zeggen dat er zeker voordelen zitten aan zelf uitgeven, maar ook vele nadelen. Mijn complete artikel hierover is hier te lezen: [Brave New Books][7]

**Is de (druk)kwaliteit wel goed?** Daarover maakte ik me inderdaad zorgen, maar nadat ik een proefdruk heb besteld en bestudeerd ben ik wel tevreden. De kleuren zien er mooi uit, alles zit goed op zijn plek, het boek voelt goed en professioneel. (Hieronder staan enkele snelle foto&#8217;s van mijn proefexemplaar in het wild :p)

De enige opmerking die ik heb is dat soms ietwat onnauwkeurig afgesneden wordt. Waarschijnlijk is dat voor lezers niet te merken, maar ik weet bijvoorbeeld bij sommige plaatjes dat ze eigenlijk iets meer ruimte aan de zijkant over hebben die nu ineens is weggesneden. Ik heb alles dubbel gecheckt, maar aan mijn aangeleverde manuscript ligt het niet. Dus ik heb het opgelost door zelf extra zorgvuldig zijn met plaatsing van belangrijke tekst en dergelijke.<figure class="is-layout-flex wp-block-gallery-3 wp-block-gallery has-nested-images columns-3 is-cropped"> <figure class="wp-block-image size-large">

[<img decoding="async" loading="lazy" width="1600" height="897" data-id="8008"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/10/index_result.webp" alt="" class="wp-image-8008" />][8]</figure> <figure class="wp-block-image size-large">[<img decoding="async" loading="lazy" width="1600" height="897" data-id="8009"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/10/index2_result.webp" alt="" class="wp-image-8009" />][9]</figure> <figure class="wp-block-image size-large">[<img decoding="async" loading="lazy" width="1600" height="897" data-id="8010"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/10/index3_result.webp" alt="" class="wp-image-8010" />][10]</figure> <figure class="wp-block-image size-large">[<img decoding="async" loading="lazy" width="1600" height="897" data-id="8011"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/10/index4_result.webp" alt="" class="wp-image-8011" />][11]</figure> <figure class="wp-block-image size-large">[<img decoding="async" loading="lazy" width="897" height="1600" data-id="8012"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2018/10/index5_result.webp" alt="" class="wp-image-8012" />][12]</figure> </figure>

 [1]: https://nietdathetuitmaakt.nl/boeken/de-kat-van-sinterklaas/attachment/katofthesint01-04_result/
 [2]: https://nietdathetuitmaakt.nl/boeken/de-kat-van-sinterklaas/attachment/katofthesint01-06_result/
 [3]: https://nietdathetuitmaakt.nl/boeken/de-kat-van-sinterklaas/attachment/katofthesint02-02_result/
 [4]: https://nietdathetuitmaakt.nl/boeken/de-kat-van-sinterklaas/attachment/katofthesint05-03_result/
 [5]: https://nietdathetuitmaakt.nl/boeken/de-kat-van-sinterklaas/attachment/katofthesint07-01_result/
 [6]: https://nietdathetuitmaakt.nl/boeken/de-kat-van-sinterklaas/attachment/katofthesint09-02_result/
 [7]: http://nietdathetuitmaakt.nl/gewoon-een-gedachte/brave-new-books/
 [8]: https://nietdathetuitmaakt.nl/boeken/de-kat-van-sinterklaas/attachment/index_result/
 [9]: https://nietdathetuitmaakt.nl/boeken/de-kat-van-sinterklaas/attachment/index2_result/
 [10]: https://nietdathetuitmaakt.nl/boeken/de-kat-van-sinterklaas/attachment/index3_result/
 [11]: https://nietdathetuitmaakt.nl/boeken/de-kat-van-sinterklaas/attachment/index4_result/
 [12]: https://nietdathetuitmaakt.nl/boeken/de-kat-van-sinterklaas/attachment/index5_result/