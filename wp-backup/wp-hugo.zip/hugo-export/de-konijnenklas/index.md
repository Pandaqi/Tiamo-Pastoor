---
title: De Konijnenklas
author: hetisdepanda
type: page
date: 2021-01-02T12:00:01+00:00

---
<div class="wp-block-image">
  <figure class="alignright size-large is-resized"><a href="https://nietdathetuitmaakt.nl/wp-content/uploads/2020/12/Voorkant-jpg_result.webp"><img decoding="async" loading="lazy" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2020/12/Voorkant-jpg_result.webp" alt="" width="-315" height="-446" /></a></figure>
</div>

**De Konijnenklas** (subtitel: _Meester Od en de zoektocht naar de passievrucht_) is een prentenboek, geschreven en getekend door mij (_Tiamo Pastoor_) en uitgegeven in eigen beheer.

Het verhaal bestaat uit 20 volledige geïllustreerde (full-color) pagina&#8217;s, met een verhaal op rijm. Ook kent het 18 pagina&#8217;s bonusinhoud. (Zoals een kaart van de wereld waarin het verhaal zich afspeelt, spelletjes gerelateerd aan het verhaal, maar vooral een grote geheime bonus &#8230;)

Koop hier het boek:

<p class="buy-button">
  <a href="https://www.bol.com/nl/p/de-konijnenklas/9300000021610761/"><strong>De Konijnenklas (Prentenboek; Bol.com)</strong></a>
</p>

<p class="buy-button">
  <a href="https://www.mijnbestseller.nl/books/248166/"><strong>De Konijnenklas (Prentenboek; MijnBestseller)</strong></a>
</p>

## Waar gaat het over? {#waar-gaat-het-over}

Meester Od is zijn passie voor lesgeven kwijt en zijn klas hun passie voor leren. Waarvoor hebben ze al die sommetjes toch nodig? En die saaie taalregeltjes?

Maar dan vertelt iemand over de&nbsp;_passievrucht_!

Enthousiast gaat de klas op avontuur — langs bossen, ravijnen, bergen, rivieren, en nog meer —&nbsp;op zoek naar deze magische vrucht.

Onderweg ontdekken ze steeds meer hoe _handig_&nbsp;die geleerde kennis is, terwijl ze van het ene gevaar in het andere storten.&nbsp;Maar langzamerhand ontdekken ze ook iets anders &#8230;

## Voorbeeldprenten {#voorbeeldprenten}

De automatische &#8220;inkijkexemplaren&#8221; van webwinkels zijn niet echt toereikend voor prentenboeken, omdat ze dan slechts de eerste paar pagina&#8217;s laten zien, die dikwijls de titel bevatten en verder leeg zijn. Dus hieronder vind je een paar pagina&#8217;s uit het boek (die zo min mogelijk van het verhaal weggeven).<figure class="is-layout-flex wp-block-gallery-5 wp-block-gallery has-nested-images columns-default is-cropped"> <figure class="wp-block-image size-large">

[<img decoding="async" loading="lazy" width="1749" height="2481" data-id="11098"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/konijnenklas-1_result.webp" alt="" class="wp-image-11098" />][1]</figure> <figure class="wp-block-image size-large">[<img decoding="async" loading="lazy" width="1749" height="2481" data-id="11099"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/konijnenklas-2_result.webp" alt="" class="wp-image-11099" />][2]</figure> <figure class="wp-block-image size-large">[<img decoding="async" loading="lazy" width="1749" height="2481" data-id="11100"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/konijnenklas-3_result.webp" alt="" class="wp-image-11100" />][3]</figure> <figure class="wp-block-image size-large">[<img decoding="async" loading="lazy" width="1749" height="2481" data-id="11101"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/konijnenklas-4_result.webp" alt="" class="wp-image-11101" />][4]</figure> <figure class="wp-block-image size-large">[<img decoding="async" loading="lazy" width="1749" height="2481" data-id="11102"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/konijnenklas-5_result.webp" alt="" class="wp-image-11102" />][5]</figure> </figure> 

## Veelgestelde vragen {#veelgestelde-vragen}

**Hoe heb je het zelf uitgegeven?** Ik heb een diepgaand artikel geschreven over dit proces. Die vind je hier:&nbsp;[**MijnBesteller (review en ervaringen)**][6]

**Hoe heb je dit gemaakt?**&nbsp;Ook hierover heb ik een diepgaand artikel:&nbsp;[**Hoe maak je een prentenboek?**][7]

**Hoe heb je geleerd om prentenboeken te maken?** Door het jarenlang te proberen en te doen. Ik heb geen kunststudie gedaan, ik heb vooral een harde schijf vol verhalen en tekeningen. Zodoende heb ik ook véél geleerd van dit hele proces! Je raadt het nooit: ik heb hier een artikel over geschreven. Zie&nbsp;**[Wat ik leerde van het maken van De Konijnenklas][8]**

**Waarom heb je het zelf uitgegeven?**&nbsp;Ik ben er trots op en kreeg hele goede reacties (onder andere van mijn zus die het voorlas aan haar eigen klas) &#8230; maar ik schat de kans klein dat uitgeverijen het zouden accepteren.

Dit heeft twee redenen.

<p class="indented">
  <em>Reden 1:</em> het is &#8220;pas&#8221; mijn tweede (afgemaakte) prentenboek. Dus ik heb geen grote bekendheid of connecties om hen te overtuigen. En ja, dat is véél belangrijker dan je denkt. (Mijn eerste prentenboek was&nbsp;<a href="https://nietdathetuitmaakt.nl/boeken/de-kat-van-sinterklaas"><strong>De Kat van Sinterklaas</strong></a>)
</p>

<p class="indented">
  <em>Reden 2:</em> Het is &#8220;anders&#8221; dan andere boeken op vele manieren. Het heeft een groter verhaal, plaatjes die de hele pagina vullen, en ik probeer het altijd&nbsp;<em>betekenisvol</em> te maken (met een thema, iets om over na te denken, een dubbele laag). Dit komt mede doordat ik meer ervaring heb als&nbsp;<em>schrijver</em> dan als&nbsp;<em>tekenaar</em>.
</p>

Uitgeverijen moeten ook winst maken en proberen hun risico te verkleinen, en dit boek is simpelweg een groot risico voor hen.

**Mag ik feedback geven?** Graag zelfs! Als je het hebt gelezen, laat me weten wat je vond, negatief of positief. De kans dat een boek wordt gekocht is véél groter als het online recensies heeft en mensen erover praten. Bovendien helpt het mij natuurlijk om te groeien als kunstenaar en mijn volgende boeken nóg beter te maken.

**Wie ben jij?** Ik ben een freelance kunstenaar die van alles door elkaar doet (schrijven, tekenen, muziek maken, spelletjes ontwerpen, &#8230;) Kijk gerust rond op mijn blog, of portfolio, of spellenwebsite, of andere plekken waar ik ineens verschijn met projecten.

## De Konijnenklas &#8230; in het wild! {#de-konijnenklas-in-het-wild}

Ik vind het altijd fijn om een paar snelle foto&#8217;s te geven van het fysieke boekje &#8220;in het wild&#8221;. Hieronder zie je dat het een vrij dun boek is (zeker als hij naast de stapel papieren ligt), maar dat is te verwachten bij een _paperback prentenboek_. Ook zie je dat pagina&#8217;s behoorlijk vol staan, iets dat ik bespreek in de artikelen hierboven. (En concludeer dat ik de volgende keer grotere pagina&#8217;s en méér pagina&#8217;s neem, ondanks de bijkomende kosten voor de koper.)<figure class="is-layout-flex wp-block-gallery-7 wp-block-gallery has-nested-images columns-default is-cropped"> <figure class="wp-block-image size-large">

[<img decoding="async" loading="lazy" width="897" height="1600" data-id="11104"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/konijnenklas-6_result.webp" alt="" class="wp-image-11104" />][9]</figure> <figure class="wp-block-image size-large">[<img decoding="async" loading="lazy" width="897" height="1600" data-id="11105"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/konijnenklas-7_result.webp" alt="" class="wp-image-11105" />][10]</figure> <figure class="wp-block-image size-large">[<img decoding="async" loading="lazy" width="897" height="1600" data-id="11106"  src="https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/konijnenklas-8_result.webp" alt="" class="wp-image-11106" />][11]</figure> </figure>

 [1]: https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/konijnenklas-1_result.webp
 [2]: https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/konijnenklas-2_result.webp
 [3]: https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/konijnenklas-3_result.webp
 [4]: https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/konijnenklas-4_result.webp
 [5]: https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/konijnenklas-5_result.webp
 [6]: https://nietdathetuitmaakt.nl/gewoon-een-gedachte/mijn-bestseller
 [7]: https://nietdathetuitmaakt.nl/gewoon-een-gedachte/hoe-maak-je-een-prentenboek
 [8]: https://nietdathetuitmaakt.nl/gewoon-een-gedachte/wat-ik-leerde-van-mijn-tweede-prentenboek
 [9]: https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/konijnenklas-6_result.webp
 [10]: https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/konijnenklas-7_result.webp
 [11]: https://nietdathetuitmaakt.nl/wp-content/uploads/2021/09/konijnenklas-8_result.webp