---
title: De Levenssaga
author: hetisdepanda
type: page
date: 2022-07-23T17:40:37+00:00
featured_image: https://nietdathetuitmaakt.nl/wp-content/uploads/2022/10/levenssaga_website_header-1.webp

---
**De Levenssaga** is een reeks korte verhalen die zich afspelen in dezelfde wereld. Het vertelt moderne supersprookjes die—met magie, spanning, en omwegen—uitleggen hoe leven op aarde ontstond.

Maar je hoeft niet alles te lezen, of op volgorde, want het is een _raamvertelling_! 

Alle verhalen staan helemaal op zichzelf. Maar ze spelen af in dezelfde wereld en refereren soms naar elkaar. Wie alles leest, echter, zal een groter beeld krijgen van een gigantische wereld vol &#8230; leven.

De verhalen zijn zelfstandig te lezen vanaf ongeveer acht jaar. Maar ze zijn universeel geschreven zodat elke leeftijdsgroep ervan kan genieten.

<p class="buy-button">
  <a href="https://delevenssaga.nl">Bezoek de website</a>
</p>

Lees de &#8220;over&#8221; pagina van de website voor alle informatie. Deze bevat ook links naar artikelen waarin ik veel meer uitleg over het proces van verhalen schrijven en de bijzondere website ontwikkelen.

## Het online experiment {#het-online-experiment}

Dit project doet iets bijzonders: het boek _is een website_. 

**Deze website is openbaar en compleet gratis.** Geen account, geen verborgen functionaliteit, de website is exact wat ik achter de schermen gebruik om de levenssaga te schrijven.

_Waarom doe je dit?_ Meerdere redenen. 

  * **Het is handig voor mij** ( = de schrijver). De website is een soort Wikipedia waarmee ik makkelijk alles kan controleren en opzoeken uit de vele verhalen. En andere mensen dus ook.
  * **Het is handig voor de lezer.** Een website, leesbaar op elk apparaat, helemaal ingericht op zo fijn mogelijk lezen. Daarnaast wil ik lezers niet dwingen om _alles_ te kopen en bij te houden. Als alle oude verhalen gratis online staan, kan een lezer makkelijk stukjes opzoeken of bijlezen als nodig.
  * Het is een experiment qua **verhalen vertellen in het digitale tijdperk**. Zeker nu kinderen ook vooral achter beeldschermen zitten.
  * De verhalen zijn kort en universeel, maar ze refereren vaak naar elkaar. Dat maakt ze sowieso perfect voor webpagina&#8217;s die kunnen **linken**. En knoppen geven om naar het volgende/vorige hoofdstuk/verhaal te gaan.
  * Ik heb het systeem zo opgezet dat ik de website makkelijk kan **omzetten in een PDF** om er een fysiek boek van te maken.

Mijn doel met de Levenssaga is _toegankelijkheid_: met _simpele verhalen_ alsnog één groot _diepgaand verhaal_ vertellen. Zo is het voor alle leeftijden. Zo wordt het makkelijker om mensen weg te trekken van bijvoorbeeld films en weer eens een verhaal te laten lezen.

Mijn hoop is dat de website meer mensen aantrekt en verblijdt. Mensen die, als ze mij kunnen en willen steunen, de betaalde versies kopen en zo de levenssaga levend houden.

Maar er is één spelregel: **de allernieuwste bundel staat _niet_ op de website.**

Dus de laatste paar verhalen zijn alleen te koop, totdat de _volgende_ verhalen uitkomen en ze dus niet meer de laatste zijn.

## Waar is het te koop? {#waar-is-het-te-koop}

**UPDATE: Voor nu zijn de verhalen nog niet te koop. Ik ben dit proces nog goed aan het opzetten.**

De boeken zijn _fysiek_ (paperback) en _digitaal_ (ebook) te koop in vrijwel alle (bekende) winkels. 

Elk deel is een bundel met twee korte verhalen uit een ander tijdperk, die optellen tot ongeveer 100 pagina&#8217;s. Er zijn tien tijdperken: om de vijf bundels heb je ze dus allemaal één keer gezien.

Je hoeft dus niet bij het begin te beginnen. Maar het is wel aan te raden 😉

Dit zijn de links naar de bundels op de website: <TO DO: Links>

## Achtergrond {#achtergrond}

### Het begin

Lang geleden (begin middelbare school) begon ik korte verhaaltjes te schrijven. Om te oefenen. Om eindelijk iets _af_ te maken in de weinige vrije tijd die ik had. (School neemt veel tijd in, maar daarnaast was ik chronisch ziek en had ik vele andere interesses.)

Het leek me leuk om die allemaal in dezelfde wereld te laten afspelen. Zodra ik dan twintig, dertig, vijftig korte verhalen had, zou je een geweldig beeld hebben van deze _bijzondere wereld_ waarin je eindeloos veel hebt meegemaakt! 

Al deze sprookjes samen zouden ongeveer het ontstaan van _leven op aarde_ vertellen. Maar dan op een manier die spannend was en die kinderen begrijpen. Vol magie, pratende dieren, grappige situaties, en leerzame momenten.

Ik schreef een sterk plan (met de verschillende tijdperken, hoe de wereld werkt, eventuele verhalen om te schrijven) en ging aan de slag.

### De tegenslag

Maar dit was mijn eerste serieuze project. Dus toen het af was en ik feedback vroeg, zag ik al snel dat er véél te verbeteren viel. (Ik had de neiging zinnen véél te lang te maken. Verhalen waren inconsistent met zichzelf. De typische beginnersfouten van een schrijver.)

Ik liet de verhalen jarenlang liggen. Totdat ik inmiddels meerdere boeken had geschreven en dus meer zelfvertrouwen had. Ik las alles terug en verbeterde het drastisch, soms zelfs tot het originele verhaal onherkenbaar was.

Maar toen besefte ik pas de realiteit: dit project is moeilijk te verkopen.

Jammer genoeg is er weinig geld te verdienen met korte moderne sprookjes voor kinderen in een verzonnen wereld. En als je alle _acht verhalen_ die ik toen had bundelt, krijg je een boek met maar liefst _500 pagina&#8217;s!_ Een deurstopper die zelfs 99% van de volwassenen laat liggen.

Ik verlegde mijn aandacht naar andere projecten met meer zekerheid. De levenssaga bleef opnieuw een paar jaar liggen.

### De doorbraak

Maar het bleef aan me knagen, zoals de dieren in de verhalen. (Dit is een hele slechte grap, maar ik laat hem toch staan.) Het was té goed om niks mee te doen. Ik had er zoveel tijd in zitten en zag mezelf nog mijn hele leven extra delen schrijven.

Dus ik reserveerde tijd om het af te maken en officieel uit te geven, dan maar in eigen beheer.

Ik had acht verhalen. De wereld heeft tien tijdperken. Ik besloot twee extra verhalen te schrijven en het op te delen in _vijf bundels_, met _twee verhalen per keer_. Dat paste op alle manieren het beste!

(Hier is een uitdaging: als je de eerste cyclus hebt gelezen, probeer te raden welke verhalen van mijn schooltijd zijn en welke recent geschreven :p)

Wanneer volgende delen verschijnen is dus niet te voorspellen. Het hangt af van, tja, hoe het leven verloopt: het succes van de reeks, mijn magere inkomen als kunstenaar, enzovoort. Wel is een groot deel van de saga al uitgedacht en kan ik nieuwe verhalen relatief snel schrijven.

Maar hopelijk zijn lezers een tijdje zoet met deze _tien_ verhalen 🙂

### Dagboeken

Ik schrijf meestal een soort dagboeken terwijl ik aan een project werk. Hierin leg ik uit wat ik probeerde, welke problemen ik tegenkwam, waarom ik bepaalde keuzes maakte, wat interessant was aan een verhaal, etcetera.

Deze kan je hier lezen:

  * <a href="https://nietdathetuitmaakt.nl/boeken/de-levenssaga/dagboek-levenssaga-cyclus-1/" data-type="page" data-id="13663">Dagboek 0</a> (deze gaat over de _oude_ verhalen, maar die bestaan dus grotendeels niet meer, dus kan je overslaan)
  * <a href="https://nietdathetuitmaakt.nl/boeken/de-levenssaga/dagboek-levenssaga-cyclus-1-2/" data-type="page" data-id="14382">Dagboek 1</a> (over de eerste cyclus en vele problemen/stappen bij het opzetten van dit project)
  * <a href="https://nietdathetuitmaakt.nl/boeken/de-levenssaga/dagboek-levenssaga-cyclus-2/" data-type="page" data-id="14947">Dagboek 2</a> (over de tweede cyclus; vanaf nu gaan dagboeken simpelweg over de cyclus waarbij ze horen en weinig anders)