---
title: Epic Medics
author: hetisdepanda
type: page
date: 2020-03-22T20:06:52+00:00
featured_image: https://nietdathetuitmaakt.nl/wp-content/uploads/2020/05/Epic-Medics-NameLogo_result.webp

---
Oh nee! Een virus heeft Nederland in zijn greep! Speel jij de heroïsche artsen &#8230; of speel jij het virus?

Epic Medics is een &#8220;one-against-many&#8221; spel. Eén iemand speelt het virus, alle andere spelers proberen _samen_ het virus te verslaan. Dit spel &#8230;

  * Is voor alle leeftijden
  * Heeft een gemiddelde complexiteit
  * Is voor 2-7 spelers.
  * Duurt 90-120 minuten.
  * Heeft spelregels in het Engels, maar het spel zelf is taalonafhankelijk. (Zolang één persoon adequaat Engels kan is dit geen probleem.)

Ik kan met trots zeggen dat dit het meest ingenieuze spel is dat ik ooit heb gemaakt! (Tot nog toe, in ieder geval.)

Het spel kent een enorme strategische laag, aangezien het virus _stiekem_ kan bewegen en infecteren en de artsen alle zeilen moeten bijzetten om hem te vinden en te stoppen. Maar de regels zijn simpel gebleven, niet meer dan 3 pagina&#8217;s (inclusief plaatjes en voorbeelden) voor je eerste potje.

Daarnaast is het een verrassend realistische weergave van hoe een virus zich verspreid en hoe je dat kunt tegenhouden. (Niet helemaal, natuurlijk, het blijft een spel.)

Bezoek de officiële spelpagina voor complete informatie: [Epic Medics (on Pandaqi)][1]

## Downloaden

Je kunt alle bestanden hier downloaden: [**Epic Medics**][2]

  * **Files:** deze folder bevat speelkaarten voor het spel. Elke speelkaart is een A4. Je hoeft er maar één te printen per potje.
  * **Rules**: deze spelregels voor het spel. Voor een eerste potje hoef je alleen de eerste 3 pagina&#8217;s te hebben.

## Developer Diary

Ik heb een (lang) &#8220;ontwikkelaarsdagboek&#8221; geschreven over dit spel. Het was één van mijn moeilijkste ideeën ooit, waardoor ik minstens acht versies heb gehad voordat het spel goed in elkaar stak. Maar daardoor heb ik veel geleerd en veel te vertellen 🙂

Dit is de link: [**[Ontwikkelingsproces] Epic Medics**][3]

 [1]: https://pandaqi.com/epic-medics/
 [2]: https://drive.google.com/open?id=1bZ0z3L63sfoK-iMKIQFG8yPzU5Efe9b-
 [3]: https://nietdathetuitmaakt.nl/bordspellen/epic-medics/ontwikkelingsproces-epic-medics/