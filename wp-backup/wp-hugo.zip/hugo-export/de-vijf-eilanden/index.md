---
title: De Vijf Eilanden
author: hetisdepanda
type: page
date: 2023-03-04T11:27:18+00:00

---
<div class="wp-block-image">
  <figure class="alignright size-full is-resized"><img decoding="async" loading="lazy" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden-header.webp" alt="" class="wp-image-15206" width="420" height="613" /></figure>
</div>

Op Titjana&#8217;s eiland worden baby&#8217;s geboren met alle kennis van de wereld. Men denkt dat ze zelfs de toekomst kunnen zien.

Maar het zijn baby&#8217;s, dus ze kunnen het niet communiceren. En zodra je ouder wordt, verlies je snel alles dat je wist.

Tot een piepjonge baby zegt: &#8220;Alles kapot.&#8221;

Vijf compleet verschillende, magische eilanden ontdekken dat er iets aankomt. Iets verwoestends. Iets verschrikkelijks.

Maar de mysterieuze magie maakt eilanden verlaten lastig—en andere eilanden vinden misschien nog gevaarlijker.

## Koop het boek!

De volledige titel van dit boek is: **De Vijf Eilanden (en andere rekenfouten).** Het is te koop in alle boekenwinkels, of met de knoppen hieronder. 

<p class="buy-button">
  <a href="https://www.bruna.nl/boeken/de-vijf-eilanden-en-andere-rekenfouten-9789403692418">De Vijf Eilanden bij Bruna</a>
</p>

<p class="buy-button">
  <a href="https://www.bol.com/nl/nl/p/de-vijf-eilanden/9300000146602969/">De Vijf Eilanden bij Bol.com</a>
</p>

<p class="buy-button">
  <strong><a href="https://www.mijnbestseller.nl/shop/index.php/catalog/product/view/id/730636/s/de-vijf-eilanden-en-andere-rekenfouten-292135-www-mijnbestseller-nl/">De Vijf Eilanden bij MijnBestseller</a></strong>
</p>

<p class="remark">
  gelieve <strong>niet</strong> bij Bol.com te kopen. Ze eisen zoveel geld dat een schrijver bij hen maar een paar cent per boek verdient, tegenover een euro op andere plekken. Het boek is overal exact even duur, dankzij de Wet van de Vaste Boekenprijs.
</p>

## In het wild

Hieronder enkele foto&#8217;s van mijn eigen (proef)exemplaar van het boek. Het boek is in eigen beheer uitgegeven, en ik heb gemerkt dat mensen dan graag &#8220;bewijs&#8221; zien van hoe het boek eruitziet!

<div class="wp-block-jetpack-tiled-gallery aligncenter is-style-rectangular">
  <div class="tiled-gallery__gallery">
    <div class="tiled-gallery__row">
      <div class="tiled-gallery__col" style="flex-basis:50.00000%">
        <figure class="tiled-gallery__item"><img decoding="async" srcset="https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_voorkant.webp?strip=info&#038;w=600&#038;ssl=1 600w,https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_voorkant.webp?strip=info&#038;w=900&#038;ssl=1 900w,https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_voorkant.webp?strip=info&#038;w=1200&#038;ssl=1 1200w,https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_voorkant.webp?strip=info&#038;w=1500&#038;ssl=1 1500w,https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_voorkant.webp?strip=info&#038;w=1800&#038;ssl=1 1800w,https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_voorkant.webp?strip=info&#038;w=2000&#038;ssl=1 2000w" alt="" data-height="4000" data-id="15227" data-link="https://nietdathetuitmaakt.nl/boeken/de-vijf-eilanden/attachment/de_vijf_eilanden_voorkant/" data-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_voorkant.webp" data-width="3000" src="https://i1.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_voorkant.webp?ssl=1" data-amp-layout="responsive" /></figure>
      </div>
      
      <div class="tiled-gallery__col" style="flex-basis:50.00000%">
        <figure class="tiled-gallery__item"><img decoding="async" srcset="https://i2.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_achterkant.webp?strip=info&#038;w=600&#038;ssl=1 600w,https://i2.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_achterkant.webp?strip=info&#038;w=900&#038;ssl=1 900w,https://i2.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_achterkant.webp?strip=info&#038;w=1200&#038;ssl=1 1200w,https://i2.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_achterkant.webp?strip=info&#038;w=1500&#038;ssl=1 1500w,https://i2.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_achterkant.webp?strip=info&#038;w=1800&#038;ssl=1 1800w,https://i2.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_achterkant.webp?strip=info&#038;w=2000&#038;ssl=1 2000w" alt="" data-height="4000" data-id="15223" data-link="https://nietdathetuitmaakt.nl/boeken/de-vijf-eilanden/attachment/de_vijf_eilanden_achterkant/" data-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_achterkant.webp" data-width="3000" src="https://i2.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_achterkant.webp?ssl=1" data-amp-layout="responsive" /></figure>
      </div>
    </div>
    
    <div class="tiled-gallery__row">
      <div class="tiled-gallery__col" style="flex-basis:66.77402%">
        <figure class="tiled-gallery__item"><img decoding="async" srcset="https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_bijzondere_plaatjes_hoofdstukken.webp?strip=info&#038;w=600&#038;ssl=1 600w,https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_bijzondere_plaatjes_hoofdstukken.webp?strip=info&#038;w=900&#038;ssl=1 900w,https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_bijzondere_plaatjes_hoofdstukken.webp?strip=info&#038;w=1200&#038;ssl=1 1200w,https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_bijzondere_plaatjes_hoofdstukken.webp?strip=info&#038;w=1500&#038;ssl=1 1500w,https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_bijzondere_plaatjes_hoofdstukken.webp?strip=info&#038;w=1800&#038;ssl=1 1800w,https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_bijzondere_plaatjes_hoofdstukken.webp?strip=info&#038;w=2000&#038;ssl=1 2000w" alt="" data-height="3000" data-id="15224" data-link="https://nietdathetuitmaakt.nl/boeken/de-vijf-eilanden/attachment/de_vijf_eilanden_bijzondere_plaatjes_hoofdstukken/" data-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_bijzondere_plaatjes_hoofdstukken.webp" data-width="4000" src="https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_bijzondere_plaatjes_hoofdstukken.webp?ssl=1" data-amp-layout="responsive" /></figure>
      </div>
      
      <div class="tiled-gallery__col" style="flex-basis:33.22598%">
        <figure class="tiled-gallery__item"><img decoding="async" srcset="https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_binnenkant.webp?strip=info&#038;w=600&#038;ssl=1 600w,https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_binnenkant.webp?strip=info&#038;w=900&#038;ssl=1 900w,https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_binnenkant.webp?strip=info&#038;w=1200&#038;ssl=1 1200w,https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_binnenkant.webp?strip=info&#038;w=1500&#038;ssl=1 1500w,https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_binnenkant.webp?strip=info&#038;w=1800&#038;ssl=1 1800w,https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_binnenkant.webp?strip=info&#038;w=2000&#038;ssl=1 2000w" alt="" data-height="3000" data-id="15225" data-link="https://nietdathetuitmaakt.nl/boeken/de-vijf-eilanden/attachment/de_vijf_eilanden_binnenkant/" data-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_binnenkant.webp" data-width="4000" src="https://i0.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_binnenkant.webp?ssl=1" data-amp-layout="responsive" /></figure><figure class="tiled-gallery__item"><img decoding="async" srcset="https://i2.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_binnenkant_2.webp?strip=info&#038;w=600&#038;ssl=1 600w,https://i2.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_binnenkant_2.webp?strip=info&#038;w=900&#038;ssl=1 900w,https://i2.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_binnenkant_2.webp?strip=info&#038;w=1200&#038;ssl=1 1200w,https://i2.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_binnenkant_2.webp?strip=info&#038;w=1500&#038;ssl=1 1500w,https://i2.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_binnenkant_2.webp?strip=info&#038;w=1800&#038;ssl=1 1800w,https://i2.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_binnenkant_2.webp?strip=info&#038;w=2000&#038;ssl=1 2000w" alt="" data-height="3000" data-id="15226" data-link="https://nietdathetuitmaakt.nl/boeken/de-vijf-eilanden/attachment/de_vijf_eilanden_binnenkant_2/" data-url="https://nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_binnenkant_2.webp" data-width="4000" src="https://i2.wp.com/nietdathetuitmaakt.nl/wp-content/uploads/2023/03/de_vijf_eilanden_binnenkant_2.webp?ssl=1" data-amp-layout="responsive" /></figure>
      </div>
    </div>
  </div>
</div>