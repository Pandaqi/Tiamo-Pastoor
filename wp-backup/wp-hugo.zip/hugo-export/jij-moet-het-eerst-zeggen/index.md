---
title: Jij moet het eerst zeggen
author: hetisdepanda
type: page
date: 2023-03-06T19:46:42+00:00

---
<div class="wp-block-image">
  <figure class="alignright size-full is-resized"><img decoding="async" loading="lazy" src="https://nietdathetuitmaakt.nl/wp-content/uploads/2023/03/jmhez_voorkant.webp" alt="" class="wp-image-15334" width="396" height="621" /></figure>
</div>

Een jongen en een meisje—vreemdelingen—komen elkaar tegen. 

Een half uur later zijn ze samen weggelopen. Weg van huis, weg van hun leven.

Drie dagen later komt maar één van hen thuis.

Een **jongerenroman** over dood, spijt, twijfel, en vooral de grote vraag: _wat gebeurde er in die drie dagen dat James en Ginty samen wegliepen?_

Gebaseerd op een waargebeurd verhaal uit mijn eigen leven. Het plotse overlijden van mijn broer liet in het echt net zoveel vraagtekens achter als het begin van dit boek.

Het boek heeft **230 pagina&#8217;s** en kost **11,99 euro** (print) of **4,99 euro** (ebook). Het is te koop in vrijwel alle (online) boekenwinkels. 

Of gebruik deze knoppen:

<p class="buy-button">
  <a href="https://books2read.com/u/4AAaEe">Overzichtspagina van uitgeverij (alles)</a>
</p>

<p class="buy-button">
  <a href="https://www.amazon.nl/dp/B0C75PX2HM/">Jij moet het eerst zeggen (Amazon; Kindle)</a>
</p>

<p class="buy-link">
  <a href="https://www.bol.com/nl/nl/p/jij-moet-het-eerst-zeggen/9300000151985814/">Jij moet het eerst zeggen (op Bol.com)</a>
</p>

## Waargebeurd?

Natuurlijk is dit verhaal niet 100% waargebeurd. Grotendeels niet, zelfs. Maar het is gebaseerd op wat ik meemaakte toen mijn broer plots overleed.

Hij ging een tochtje fietsen, zoals zo vaak. Een uur later stond de politie aan de deur om te vertellen dat hij er niet meer was. Waaraan stierf hij? Wat was het laatste dat hij meemaakte? Waarom fietste hij een andere route dan normaal? Kunnen we zijn mobiel kraken en daarop antwoorden vinden?

Dit boek vertelt dat verhaal zo goed als ik kan. Met extra personages en spannende verhaallijnen om de titel kracht bij te zetten: &#8220;Jij moet het eerst zeggen&#8221;

## Nog meer bijzonderheden?

Ik schreef dit verhaal eerst als _musical_. Ik ben een veel betere muzikant dan schrijver. Maar ja, musicals zijn al helemáál niet te verkopen! Hoe krijg je dat op de planken? Hoe verdien je er geld aan? Hoe neem je de muziek professioneel op? Meer vragen dan antwoorden. Dus schreef ik het om tot boek.

Elk hoofdstuk begint met een plaatje. Waarom dat is &#8230; zal je snel merken wanneer je leest.

En ten derde is dit boek uitgegeven bij een nieuwe uitgever. Dus mocht er iets mis gaan in de levering, of iets anders aan de hand zijn, laat het weten!

Voor meer informatie, lees het (gedetailleerde) [dagboek over het hele schrijfproces][1]

Ik heb ook een leuk artikel over [hoe ik de voorkant van het boek ontwierp][2].

 [1]: https://nietdathetuitmaakt.nl/boeken/jij-moet-het-eerst-zeggen/dagboek-jij-moet-het-eerst-zeggen
 [2]: https://nietdathetuitmaakt.nl/visuele-fratsen/over-de-voorkant-van-jmhez